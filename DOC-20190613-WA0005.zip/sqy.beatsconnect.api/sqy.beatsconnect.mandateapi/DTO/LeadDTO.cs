﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.mandateapi.DTO
{
    public class GetMyLeadsRequestDTO
    {
        [Required]
        public string MandateCode { get; set; }
        [Required]
        public int CurrentUser { get; set; }
    }

    public class GetMyLeadsResponseDTO
    {
        public string MandateLeadID { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string AssignedTo { get; set; }
        public string AssignedToType { get; set; }
        public string Remarks { get; set; }
    }
}
