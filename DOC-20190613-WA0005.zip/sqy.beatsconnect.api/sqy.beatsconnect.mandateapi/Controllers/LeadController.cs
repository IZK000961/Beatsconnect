﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;

namespace sqy.beatsconnect.mandateapi.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class LeadController : ControllerBase
    {
        [HttpPost]
        [Route("GetMyLeads")]
        public IActionResult GetMyLeads()
        {
            MySqlConnection con = new MySqlConnection("server=125.63.93.173;port=3306;database=sqybeatsdb;user=localadmin;password=Sqyrd@5432");
            MySqlCommand com = con.CreateCommand();
            try
            {
                com.CommandText = "SELECT * FROM mandatelead";

                // com.Connection.Open();
                // MySqlDataReader reader = com.ExecuteReader();

                MySqlDataAdapter da = new MySqlDataAdapter(com.CommandText, con);

                DataSet ds = new DataSet();
                da.Fill(ds);
                // DataTable table = new DataTable();
                // table.Load(reader);
                // com.Connection.Close();
                return Ok(new
                {
                    Data = ds.Tables[0]
                });
            }
            catch (Exception ex)
            {
                // com.Connection.Close();
                return Ok(new
                {
                    Message = ex.Message
                });
            }
        }
    }
}
