﻿using AutoMapper;
using MySql.Data.MySqlClient;
using sqy.Redis.WrapperCore;
using System;
using System.Collections.Generic;
using System.Data;
using sqy.beatsconnect.Helper;
using System.Threading.Tasks;

namespace sqy.beatsconnect.DBHelper
{
    public class BeatsMySqlHelper
    {
        public string connectionString { get; set; }
        public BeatsMySqlHelper(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public List<TEntity> GetList<TEntity>(string strProcedureName, List<MySqlParameter> mySqlParamsList)
        {
            //try
            //{
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(strProcedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    for (int i = 0; i < mySqlParamsList.Count; i++)
                    {
                        cmd.Parameters.AddWithValue(mySqlParamsList[i].ParameterName.ToString(), mySqlParamsList[i].Value);
                    }
                    con.Open();
                    var reader = cmd.ExecuteReader();
                    var properties = typeof(TEntity).GetProperties();
                    List<TEntity> data = new List<TEntity>();
                    List<string> columnNames = new List<string>();
                    if (reader.HasRows)
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            columnNames.Add(reader.GetName(i).ToLower());
                        }
                        while (reader.Read())
                        {
                            var item = Activator.CreateInstance<TEntity>();
                            foreach (var property in properties)
                            {
                                if (columnNames.Contains(property.Name.ToLower()) && !reader.IsDBNull(reader.GetOrdinal(property.Name)))
                                {
                                    Type convertTo = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                    property.SetValue(item, Convert.ChangeType(reader[property.Name], convertTo), null);
                                }
                            }
                           data.Add(item);
                        }
                    }
                    con.Close();
                    return data;
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
            //    return data;
            //}
        }

        public async Task<List<TEntity>> GetListAsync<TEntity>(string strProcedureName, List<MySqlParameter> mySqlParamsList)
        {
            //try
            //{
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(strProcedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    for (int i = 0; i < mySqlParamsList.Count; i++)
                    {
                        cmd.Parameters.AddWithValue(mySqlParamsList[i].ParameterName.ToString(), mySqlParamsList[i].Value);
                    }
                    con.Open();
                    var reader = await cmd.ExecuteReaderAsync();
                    var properties = typeof(TEntity).GetProperties();
                    List<TEntity> data = new List<TEntity>();
                    List<string> columnNames = new List<string>();
                    if (reader.HasRows)
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            columnNames.Add(reader.GetName(i).ToLower());
                        }
                        while (reader.Read())
                        {
                            var item = Activator.CreateInstance<TEntity>();
                            foreach (var property in properties)
                            {
                                if (columnNames.Contains(property.Name.ToLower()) && !reader.IsDBNull(reader.GetOrdinal(property.Name)))
                                {
                                    Type convertTo = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                    property.SetValue(item, Convert.ChangeType(reader[property.Name], convertTo), null);
                                }
                            }
                            data.Add(item);
                        }
                    }
                    con.Close();
                    return data;
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
            //    return data;
            //}
        }

        public List<List<TEntity>> GetLists<TEntity>(string strProcedureName, List<MySqlParameter> mySqlParamsList)
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(strProcedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;

                    for (int i = 0; i < mySqlParamsList.Count; i++)
                    {
                        cmd.Parameters.AddWithValue(mySqlParamsList[i].ParameterName.ToString(), mySqlParamsList[i].Value);
                    }

                    con.Open();
                    var reader = cmd.ExecuteReader();
                    var properties = typeof(TEntity).GetProperties();
                    List<List<TEntity>> data = new List<List<TEntity>>();
                    List<TEntity> data1 = new List<TEntity>();
                    List<string> columnNames = new List<string>();
                    if (reader.HasRows)
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            columnNames.Add(reader.GetName(i));
                        }
                        while (reader.Read())
                        {
                            var item = Activator.CreateInstance<TEntity>();
                            foreach (var property in properties)
                            {
                                if (columnNames.Contains(property.Name) && !reader.IsDBNull(reader.GetOrdinal(property.Name)))
                                {
                                    Type convertTo = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                    property.SetValue(item, Convert.ChangeType(reader[property.Name], convertTo), null);
                                }
                            }
                            data1.Add(item);
                        }
                    }
                    data.Add(data1);
                    while (reader.NextResult())
                    {
                        data1 = new List<TEntity>();
                        if (reader.HasRows)
                        {
                            columnNames = new List<string>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                columnNames.Add(reader.GetName(i));
                            }
                            while (reader.Read())
                            {
                                var item = Activator.CreateInstance<TEntity>();
                                foreach (var property in properties)
                                {
                                    if (columnNames.Contains(property.Name) && !reader.IsDBNull(reader.GetOrdinal(property.Name)))
                                    {
                                        Type convertTo = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                        property.SetValue(item, Convert.ChangeType(reader[property.Name], convertTo), null);
                                    }
                                }
                                data1.Add(item);
                            }
                        }
                        data.Add(data1);
                    }
                    con.Close();
                    return data;
                }
            }
        }

        public void SetParameters(List<MySqlParameter> paramList, string mySqlParam, MySqlDbType mySqlDbType, object value)
        {
            MySqlParameter mySqlParameter = new MySqlParameter(mySqlParam, mySqlDbType)
            {
                Value = value
            };
            paramList.Add(mySqlParameter);
        }

        #region"Redis"
        public List<TEntity> GetList<TEntity>(string strProcedureName, List<MySqlParameter> mySqlParamsList, CacheParameters cacheparam = null)
        {
            int _IsCachingEnabled = AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).IsCachingEnabled;
            if (cacheparam != null && cacheparam.CacheRequired && _IsCachingEnabled == 1)
            {
                RedisCache cache = new RedisCache();
                string key = string.Empty;
                string paramString = ConvertCommandParamatersToLiteralValues(strProcedureName, mySqlParamsList);

                if (string.IsNullOrWhiteSpace(cacheparam.AdditionalKey))
                    key = $"API_{cacheparam.Prefix.ToString()}_{MD5Hash.GenerateHash(paramString)}";
                else
                    key = $"API_{cacheparam.Prefix.ToString()}_{cacheparam.AdditionalKey}_{MD5Hash.GenerateHash(paramString)}";

                if (cache.IsKeyExist(key))
                {
                    List<TEntity> Tlist = cache.TryGet<List<TEntity>>(key, cacheparam.TTL);
                    return Tlist;
                }
                else
                {
                    List<TEntity> Tlist = GetList<TEntity>(strProcedureName, mySqlParamsList);
                    cache.SetValue(key, Tlist, cacheparam.TTL);
                    return Tlist;
                }
            }
            else
            {
                return  GetList<TEntity>(strProcedureName, mySqlParamsList);
            }

        }

        private static string ConvertCommandParamatersToLiteralValues(string ProcName, List<MySqlParameter> sqlParams)
        {
            //format
            // Key = ProcedureName_Param1_val~Param2_val2
            string query = ProcName;
            string key = string.Empty;
            key = ProcName;

            foreach (MySqlParameter prm in sqlParams)
            {
                switch (prm.MySqlDbType)
                {
                    case MySqlDbType.Bit:
                        int boolToInt = (bool)prm.Value ? 1 : 0;
                        //query = query.Replace(prm.ParameterName, string.Format("{0}", (bool)prm.Value ? 1 : 0));
                        key = key + $"{prm.ParameterName}_{((bool)prm.Value ? 1 : 0)}~";
                        break;
                    case MySqlDbType.Int16:
                    case MySqlDbType.Int24:
                    case MySqlDbType.Int32:
                    case MySqlDbType.Int64:
                    case MySqlDbType.Decimal:
                    case MySqlDbType.Double:
                        //query = query.Replace(prm.ParameterName, string.Format("{0}", prm.Value));
                        key = key + $"{prm.ParameterName}_{prm.Value}~";
                        break;
                    case MySqlDbType.VarChar:
                        //query = query.Replace(prm.ParameterName, string.Format("'{0}'", prm.Value));
                        key = key + $"{prm.ParameterName}_{prm.Value}~";
                        break;
                    case MySqlDbType.DateTime:
                    case MySqlDbType.Date:
                        //query = query.Replace(prm.ParameterName, string.Format("'{0}'", prm.Value));
                        key = key + $"{prm.ParameterName}_{prm.Value}~";
                        break;
                    default:
                        //query = query.Replace(prm.ParameterName, string.Format("'{0}'", prm.Value));
                        key = key + $"{prm.ParameterName}_{prm.Value}~";
                        break;
                }
            }

            return key.TrimEnd('~');
        }
        #endregion
    }
}
