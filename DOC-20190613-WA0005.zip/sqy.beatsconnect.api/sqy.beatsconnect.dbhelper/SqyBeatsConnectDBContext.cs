﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DBHelper
{
    public class SqyBeatsConnectDBContext
    {
        public MySqlConnection Connection { get; set; }
        private string connectionString { get; set; }
        public SqyBeatsConnectDBContext(string connectionString)
        { 
            this.connectionString = connectionString;
            Connection = new MySqlConnection(connectionString);
        }
        public MySqlConnection GetConnection()
        {
            return new MySqlConnection(this.connectionString);
        }
    }
}
