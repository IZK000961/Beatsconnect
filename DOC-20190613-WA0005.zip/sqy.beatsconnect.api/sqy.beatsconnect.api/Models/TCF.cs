﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Data.Common;
using System.Data;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations;

namespace sqy.beatsconnect.api.Models
{
    public class GetTCFRequestDTO
    {
        [Required]
        public int dateType { get; set; } = 3;
        public string FromDate { get; set; } = DateTime.Now.AddMonths(-3).ToString("yyyy-MM-dd");
        public string ToDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public string status { get; set; } = "-1";
        public int developer { get; set; } = -1;
        public int project { get; set; } = -1;
        public int cityId { get; set; } = -1;
        public int pnlId { get; set; } = -1;
        public int empId { get; set; } = -1;
        public string _prefixText { get; set; } = "%%";
        public string PrefixText
        {
            get { return string.Concat("%", _prefixText, "%"); }
            set { _prefixText = value; }
        }
        public int currentUser { get; set; } = -1;
        public string TCFStatus { get; set; } = "DRAFT";
        public bool IncludeTeam { get; set; }
        public bool IsShareHolder { get; set; }
        public int isAdmin { get; set; } = 0;
        public string tCFIDs { get; set; } = "-1";
        public int pnLHeadID { get; set; } = -1;
        public string deletedRemarks { get; set; } = "-1";
        public int cpId { get; set; } = -1;
        public string dealNo { get; set; } = "";
        public int rfStatusId { get; set; } = -1;
        public int segmentId { get; set; } = -1;
        public int limit { get; set; } = 10;
        public int pageNo { get; set; } = 1;
        public int Key { get; set; } = 1;
        public string mobile { get; set; } = "-1";
        public string email { get; set; } = "-1";
        public int ProductTypeID { get; set; } = -1;
    }
    public enum TCFReportStatus
    {
        DRAFT, PREAPPROVAL, LOANAPPROVAL, HOLD, RESUBMIT, ALLY2BL, LOANPENDING, NOTCOUNTED, SOS,
        COUNTED, DELETED, CANCELLED, COLLECTED, CLIENTACK,
        BUSINESSALERT, SHARETRANSFER, TPL_PENDING, RESUBMIT_CRM, RESUBMIT_LOAN, RESUBMIT_OPS, CANCELLED_DATE
    }
    public class TCFResponseDTO
    {
        public int TCFId { get; set; }
        public string TCFRefrenceId { get; set; }
        public string Status { get; set; }
        public string Month { get; set; }
        public string NetRevenueINR { get; set; }
        public string ShareHolder { get; set; }
        public string SharePercentage { get; set; }
        public string CustomerName { get; set; }
        public string Builder { get; set; }
        public string ProductName { get; set; }
        public string rstatus { get; set; }
        public string UnitNumber { get; set; }

    }
    public class TCFDetailsResponseDTO
    {
        public int tcfId { get; set; }
        public string TCFRefrenceId { get; set; }
        public string TCFStatus { get; set; }
        public string RFStatus { get; set; }
        public string Project { get; set; }
        public string ClientName { get; set; }
        public string SubmittedOn { get; set; }
        public string SubmittedBy { get; set; }
        public string NR { get; set; }
        public string ShareHolder { get; set; }
        public string PnLName { get; set; }
        public string SharePercentage { get; set; }
        public string T2 { get; set; }
        public string PnL { get; set; }
        public string PnLRegion { get; set; }
        public string Remarks { get; set; }
        public string TAT { get; set; }
        //public int MaxNumberOfPages { get; set; }
        //public int CurrentPage { get; set; }
    }
    public class GetTCFResponseDTO
    {
        public int MaxNumberOfPages { get; set; }
        public int CurrentPage { get; set; }
        public List<TCFDetailsResponseDTO> filterRes { get; set; }
    }

    public class GetTCFDTO
    {
        public int TCFID { get; set; }
        public string TCFRefrenceId { get; set; }
        public string ProductName { get; set; }
        public DateTime TCFCreationDate { get; set; }
        public string Name { get; set; }
    }
    
    public class GetTCF
    {
        public int CurrentPage { get; set; }
        public int maxPages { get; set; }
        public List<GetTCFDTO> draftedTCF { get; set; }
    }
}
