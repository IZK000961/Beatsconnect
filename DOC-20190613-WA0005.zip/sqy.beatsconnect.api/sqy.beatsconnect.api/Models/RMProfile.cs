﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Models
{
    public class UpdateProfileRequestDTO
    {
        [Required(ErrorMessage = "Highest Education is required")]
        public int HighestEducationId { get; set; }
        [Required]
        public int CareerStartingMonth { get; set; }
        [Required]
        public int CareerStartingYear { get; set; }

        public int NativeCityId { get; set; }
        public int NativeStateId { get; set; }
        public int NativeCountryId { get; set; }

        public int[] InterestIds { get; set; }

        public string NoOfDependents { get; set; }
        public string NoOfDependentKids { get; set; }

        public List<UpdateProfileLanguageRequestDTO> Languages { get; set; }
        public string AboutYourself { get; set; }
    }

    public class UpdateProfileLanguageRequestDTO
    {
        public int LanguageId { get; set; }
        public string LanguageLevel { get; set; }
    }
    public class GetLocationsRequestDTO
    {
        public int LocationId { get; set; } = 0;
    }
}
