﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api
{
    public class apiResponse
    {
        public virtual int status { get; set; }
        public virtual string message { get; set; } = string.Empty;
    }
    public class apiResponse<T> : apiResponse
    {
        public virtual T response { get; set; }
    }
    public class apiResponse<T, TD> : apiResponse
    {
        public virtual TD otherDetails { get; set; }
        public virtual T response { get; set; }
    }
}
