﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Models
{
    public class URLLIST
    {
        public List<CacheUrl> Urls { get; set; }
    }

    public class CacheUrl
    {
        public string UrlEndpoint { get; set; }
        public int TTL { get; set; } = 30;
        public int Enabled { get; set; } = 1;
    }

}
