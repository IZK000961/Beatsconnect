﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Models
{
    public class GetProductsRequestDTO
    {
        [Required(ErrorMessage = "prefixText is required")]
        public string PrefixText { get; set; }
        public int Limit { get; set; } = 20;
        public bool MktCollateral { get; set; } = false;
    }

    public class GetProductsProductDTO
    {
        public int ProductId { get; set; }
        public string DisplayName { get; set; }
        public bool MktCollateral { get; set; }
        public int ProjectId { get; set; }
    }
}
