﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.api.ViewModels;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Models
{
    public class DABeatsConnect
    {
        //private readonly mysqlhelper _mysqlhelper;
        //public DABeatsConnect(SqyBeatsConnectDBContext dbcontext)
        //{
        //    _mysqlhelper = new mysqlhelper(dbcontext.Connection);
        //}
       
        public List<MySqlParameter> getConnectdata(leadFilter leadFilter,mysqlhelper _mysqlhelper)
        {
            string query = string.Format("Select UserTypeId from users where apiAccessToken = '{0}'", leadFilter.apiAccessCode);
            //var read = _mysqlhelper.ExecuteReaderSqy(query);
            //while(read.Read())
            //{
            //    object val = read[0];
            //}
            int CurrentUser = Convert.ToInt32(_mysqlhelper.ExecuteScalarSqy(query));
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            paramList.Add(new MySqlParameter("_Callvalue", leadFilter.callValue));
            paramList.Add(new MySqlParameter("_PageNo", leadFilter.pageNo));
            paramList.Add(new MySqlParameter("_CurrentUser", CurrentUser));
            paramList.Add(new MySqlParameter("_FirstName", leadFilter.firstName));
            paramList.Add(new MySqlParameter("_Contact", leadFilter.contact));
            paramList.Add(new MySqlParameter("_Developer", leadFilter.developer));
            paramList.Add(new MySqlParameter("_AssignedTo", leadFilter.assignedTo));
            paramList.Add(new MySqlParameter("_LeadStatus", leadFilter.leadStatus));
            paramList.Add(new MySqlParameter("_PnLID", leadFilter.pnlId));
            paramList.Add(new MySqlParameter("_Project", leadFilter.project));
            paramList.Add(new MySqlParameter("_SegmentID", leadFilter.segmentId));
            paramList.Add(new MySqlParameter("_SharedWith", leadFilter.sharedWith));
            paramList.Add(new MySqlParameter("_Source", leadFilter.source));
            paramList.Add(new MySqlParameter("_CPID", leadFilter.cpId));
            paramList.Add(new MySqlParameter("_T2oPnL", leadFilter.t2oPnL));
            paramList.Add(new MySqlParameter("_DateType", leadFilter.dateType));
            paramList.Add(new MySqlParameter("_FromDate", leadFilter.fromDate));
            paramList.Add(new MySqlParameter("_ToDate", leadFilter.toDate));
            paramList.Add(new MySqlParameter("_LeadID", leadFilter.leadId));
            paramList.Add(new MySqlParameter("_Key", leadFilter.key));
            paramList.Add(new MySqlParameter("_LocationType", leadFilter.locationType));
            paramList.Add(new MySqlParameter("_ParentId", leadFilter.parentId));
            return paramList;
          
        }
    }
}
