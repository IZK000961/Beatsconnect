﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Models
{
    public class SaveColdCallDetailsRequestDTO
    {
        public int callActivityId { get; set; } = 0;
        [Required]
        public string empCode { get; set; }
        [Required]
        public int CalledBy { get; set; }
        public string CountryCode { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Required]
        public int CallDuration { get; set; } =0;
        [Required]
        public int RingDuration { get; set; } = 0;
        public string CallType { get; set; }
        //public string CalledAt { get; set; }

        public string DispositionStatus { get; set; } = "Not_Connected";
        public string CustomerName { get; set; }
        public string Project { get; set; }
        public string Comments { get; set; }

        public int EventDetailId { get; set; } = 0;
        public string Email { get; set; } = null;
        public string City { get; set; }

        public string NextActivityText { get; set; }
        public string NextInteractionDate { get; set; }

        public int ActivityType { get; set; } = 1;
        public int OtpRequestId { get; set; } = 0;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }

    public class GetNumbersForCampaignRequestDTO
    {
        public string CampaignType { get; set; }
        public string CampaignDate { get; set; }
    }

    public class DNDCheckRequestDTO
    {
        [Required(ErrorMessage = "Country code is required")]
        public string CountryCode { get; set; }
        [Required(ErrorMessage = "Phone Number is required")]
        public string PhoneNumber { get; set; }
        public bool SendOtp { get; set; }
    }
    public class DNDGetRequestDTO
    {
        [Required(ErrorMessage = "Phone Number is required")]
        public string PhoneNumber { get; set; }
    }

    public class SendOTPRequestDTO
    {
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public int RequestId { get; set; } = 0;
        public int CurrentUser { get; set; } = 0;
    }

    public class VerifyOTPRequestDTO
    {
        [Required]
        public int RequestId { get; set; }
        [Required]
        public int CurrentUser { get; set; }
        [Required]
        public int OTP { get; set; }
    }
}
