﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
namespace sqy.beatsconnect.api.Models
{
    public class LoginRequestDTO
    {
        [Required]
        public string Username {get;set;}
        [Required]
        public string Password { get; set; }
        [Required]
        public string DeviceID { get; set; }
        [Required]
        public string DeviceType { get; set; }
    }

    public class WebLoginRequestDTO
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
    }

    public class UpdateDeviceTokenDTO
    {
        [Required]
        public string DeviceID { get; set; }
        [Required]
        public string DeviceType { get; set; }
    }
    public class LoginResponseDTO
    {
        public int[] UserRole { get; set; }
        public string PnlName { get; set; }
        public string EmpCode { get; set; }
        public string EmpLocation { get; set; }
        public string EmpEmail { get; set; }
        public string EmpName { get; set; }
        public string PnlHeadName { get; set; }
        public string EmpProfileImage { get; set; }
        public string EmpDepartment { get; set; }
        public string EmpDesignation { get; set; }
        public string EmpPhone { get; set; }
        public string EmpApiAccessToken { get; set; }
        public string Expiration { get; set; }
        public bool IsProfileUpdated { get; set; }
        public string LoginType { get; set; }
        public int EmpId { get; set; }
        public string EmpLevel { get; set; }
    }

    public class RegisterRequestDTO
    {
        public string Name { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string OrganizationName { get; set; }
        public string City { get; set; }
    }

    public class ForgotPasswordRequestDTO
    {
        public string Email { get; set; }
    }
}
