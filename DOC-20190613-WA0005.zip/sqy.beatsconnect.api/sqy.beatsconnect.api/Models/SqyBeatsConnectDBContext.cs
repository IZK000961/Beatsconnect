﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
namespace sqy.beatsconnect.api.Models
{
    public class SqyBeatsConnectDBContext:IDisposable
    {
        
        public MySqlConnection Connection;

        public SqyBeatsConnectDBContext(string _connectionString){
            Connection = new MySqlConnection(_connectionString);
        }

        public void Dispose()
        {
            Connection.Close();
        }

    }
}
