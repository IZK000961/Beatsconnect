﻿using Microsoft.Extensions.Logging;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Models
{
    public class SendMail
    {

        public static void f_sendMailFromCRM(string mailto, string mailcc, string mailbcc, string replyTo, string mailbody, string mailsubject, List<Attachment> attachments = null)
        {
            Collection<Attachment> attachmentsColl = new Collection<Attachment>();
            if (attachments != null)
            {
                foreach (var item in attachments)
                {
                    attachmentsColl.Add(item);
                }
            }
            sendEmail(mailto, mailbody, mailsubject, mailcc, mailbcc, replyTo, attachmentsColl, MailType.AWS, EmailFrom.CRM);
        }

        public static void f_sendMailCommon(string mailto, string mailcc, string mailbcc, string replyTo, string mailbody, string mailsubject, MailType mailService, EmailFrom fromMail, List<Attachment> attachments = null)
        {
            Collection<Attachment> attachmentsColl = new Collection<Attachment>();
            if (attachments != null)
            {
                foreach (var item in attachments)
                {
                    attachmentsColl.Add(item);
                }
            }
            sendEmail(mailto, mailbody, mailsubject, mailcc, mailbcc, replyTo, attachmentsColl, mailService, fromMail);
        }

        public static void sendEmail(string mailto, string mailbody, string mailsubject, string mailcc, string mailbcc, string replyTo,
          Collection<Attachment> attachments, MailType mailService, EmailFrom fromMail)
        {
            // Logger.Error("Inside sendEmail " + DateTime.Now.ToString());
            try
            {
                if (string.IsNullOrEmpty(mailbody)) return;

                var mailKeys = AppSettingsConf.EMailKeySettings();
                //var mailClient = mailKeys.MailClient.Where(x => x.Client == mailService.ToString()).FirstOrDefault();
                var mailMeta = AppSettingsConf.EMailMetaSettings(fromMail); 
                var mailClient = AppSettingsConf.GetMailSettings(mailService);

                MailMessage mailmesage = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient(  mailClient.SMTP);

                mailmesage.From = new MailAddress(mailMeta.Address, mailMeta.DisplayName);

                if (!string.IsNullOrEmpty(replyTo))
                    mailmesage.ReplyToList.Add(replyTo);
                else
                    mailmesage.ReplyToList.Add(mailMeta.Address);

                mailto = cleanEmailIds(mailto);
                mailcc = cleanEmailIds(mailcc);
                mailbcc = cleanEmailIds(mailbcc);

                if (mailKeys.Testing == 1)
                {
                    mailmesage.To.Add(mailKeys.TestMailTo);
                    mailbody = string.Concat(mailbody, "<br/>To: ", mailto, "<br/>CC: ", mailcc, "<br/>BCC: ", mailbcc, "<br/>BCC fixed: " + mailMeta.MailBCC);
                }
                else
                {
                    mailmesage.To.Add(mailto);

                    if (!string.IsNullOrEmpty(mailcc))
                        mailmesage.CC.Add(mailcc);

                    if (!string.IsNullOrEmpty(mailbcc))
                        mailmesage.Bcc.Add(mailbcc);

                    if (!string.IsNullOrEmpty(mailMeta.MailBCC))
                        mailmesage.Bcc.Add(mailMeta.MailBCC);
                }

                mailmesage.Subject = mailsubject;
                mailmesage.Body = mailbody;
                mailmesage.IsBodyHtml = true;

                if (attachments != null)
                {
                    foreach (var item in attachments)
                    {
                        mailmesage.Attachments.Add(item);
                    }
                }

                SmtpServer.Port = int.Parse(mailClient.SMTPPort);
                SmtpServer.Credentials = new NetworkCredential(mailClient.UserName, mailClient.Password);
                SmtpServer.EnableSsl = true;

                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

                // Logger.Error("before smtp send " + DateTime.Now.ToString() + "\n" + string.Join(",", mailmesage.To.Select(t => t.Address)));
                // Logger.Error("before smtp send " + DateTime.Now.ToString());
                SmtpServer.Send(mailmesage);
                mailmesage.Attachments.Dispose();
                // Logger.Error("after smtp send " + DateTime.Now.ToString());
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
               // Logger.Error("EmailLogs: " + DateTime.Now.ToString() + "- Mail Sending Failed.\nSubject: " + mailsubject + "\n\n" + ex);
            }
        }

        //public class EmailKeys
        //{
        //    public int Testing { get; set; }
        
        //}
        //public enum EmailService
        //{
        //    AWS, GMail
        //}
        //public enum EmailFrom
        //{
        //    CRM
        //}

        public static string cleanEmailIds(string emails)
        {
            if (emails != null)
            {
                List<string> emailList = emails.Split(',').ToList().Where(x => x.Trim() != "").ToList();
                return emailList.Count == 0 ? "" : string.Join(",", emailList);
            }
            else return emails;
        }
    }
}
