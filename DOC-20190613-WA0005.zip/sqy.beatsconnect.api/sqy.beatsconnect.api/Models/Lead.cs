﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Data.Common;
using System.Data;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations;

namespace sqy.beatsconnect.api.Models
{
    public class GetMyLeadsRequestDTO
    {
        public int PageNo { get; set; } = 1;
        public string SearchKey { get; set; }
        public string Developer { get; set; } = "All";
        public int AssignedTo { get; set; } = 0;
        public int LeadStatus { get; set; } = -1;
        public int PnLId { get; set; } = -1;
        public string Project { get; set; } = "All";
        public int SegmentID { get; set; } = -1;
        public int SharedWith { get; set; } = -1;
        public string Source { get; set; } = "All";
        public int CPID { get; set; } = -1;
        [Required]
        public int DateType { get; set; } = -1;
        public string FromDate { get; set; } // = DateTime.Now.AddMonths(-3).ToString("yyyy-MM-dd");
        public string ToDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public int T2oPnL { get; set; } = -1;
        public string LeadSection { get; set; }

        public int NotificationId { get; set; } = 0;
    }

    public class GetMyLeadsResponseDTO
    {
        public int MaxNumberOfPages { get; set; }
        public int CurrentPage { get; set; }
        public string FilterInfo { get; set; }
        public List<GetMyLeadsLeadResponseDTO> filterRes { get; set; }
    }

    public class GetMyLeadsLeadResponseDTO
    {
        public int LeadID { get; set; }
        public string Project { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
       // public string Email { get; set; }
        public string LeadDate { get; set; }
        public string AssignedTo { get; set; }
        public string Status { get; set; }
       // public int SharedWith { get; set; }
        public string SharedWith { get; set; }
        public int activityId { get; set; }
        public bool updateEnabled { get; set; }
        //  public string Developer { get; set; }
        // public string Budget { get; set; }
        // public string CountryCode { get; set; }
        // public string Segment { get; set; }

    }


    public class GetInteractionDetailsResponseDTO
    {
        public int MaxNumberOfPages { get; set; }
        public int CurrentPage { get; set; }
        public string TimeZone { get; set; }
        public List<GetInteractionDetailResponseDTO> interactionDetails { get; set; }
    }

    public class GetInteractionDetailResponseDTO
    {
        public int LeadID { get; set; }
        public string LeadStatus { get; set; }
        public string PhoneNumber { get; set; }
        //   public string Email { get; set; }
        //  public string Segment { get; set; }
        public string FirstName { get; set; }
        public string NextInteractionDate { get; set; }
        public string NextActivity { get; set; }
        public string date { get; set; }
        public string isPlanned { get; set; }

    }

    public class UpdateActivityRequestDTO
    {
        [Required]
        public int LeadID { get; set; }
        [Required]
        public int CurrentActivityID { get; set; }
        //public string Developer { get; set; }
        //public string InteractionDate { get; set; }
        public double Latitude { get; set; }
        [Required]
        public int LeadStatusID { get; set; }
        public double Longitude { get; set; }
        public int NextActivityID { get; set; }
        public string NextInteractionDate { get; set; }
        //public string Project { get; set; }
        public string Reason { get; set; }
        public string SubReason { get; set; }
        public string Comments { get; set; }
        public int CallActivityID { get; set; }
        //public int BudgetID { get; set; }
        public string Location { get; set; }

        public int LeadActivityId { get; set; } = 0;
        public List<UpdateActivityRequestProductDTO> Products { get; set; }

        public int EventDetailId { get; set; } = 0;
    }
    public class UpdateActivityRequestProductDTO
    {
        [Required(ErrorMessage = "ProductId is required")]
        public int ProductId { get; set; }
        [Required(ErrorMessage = "DisplayName is required")]
        public string DisplayName { get; set; }
        public string OtherStr { get; set; }
    }

    public class SaveLeadCallDetailsRequestDTO
    {
        public int CallActivityId { get; set; } = 0;
        [Required]
        public int CallDuration { get; set; }
        public int CalledBy { get; set; }
        
        public int LeadID { get; set; } = 0;
        [Required]
        public string PhoneNo { get; set; }
        [Required]
        public int RingingTime { get; set; }
        public int CalledTo { get; set; } = 0;
        public string CallType { get; set; } = "Lead";
    }

    public class UpdateLeadDetailsRequestDTO
    {
        [Required]
        public int LeadID { get; set; }
        // [Required]
        public int BudgetID { get; set; }
        public string BudgetDesc { get; set; }
        [Required]
        public string Developer { get; set; }
        [Required]
        public string Project { get; set; }
        [Required]
        public string City { get; set; }
    }
    public class UpdateLeadBasicInfoRequestDTO
    {
        [Required]
        public int LeadID { get; set; }
        [Required]
        public string LeadName { get; set; }
        public string Salutation { get; set; }
        public string Website { get; set; }
        public string address { get; set; }
        public int City { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public string ZipCode { get; set; }
        public string Industry { get; set; }
        public string CityName { get; set; }
        public string CompanyName { get; set; }
        public string Title { get; set; }
    }

    public class GetBudgetResponseDTO
    {
        public int ddlValue { get; set; }
        public string ddlText { get; set; }
    }

    public class GetLeadActivityresponseDTO
    {
        public int LeadID { get; set; }
        public string LeadName { get; set; }
        public string Leaddate { get; set; }
        public DateTime LeadGenerationDate { get; set; }
        public string LeadReassignmentDate { get; set; }
        public string Project { get; set; }
        public string Source { get; set; }
        public string LeadPhoneNum { get; set; }
        public string LeadAssignedTo { get; set; }
        public string LeadEmailId { get; set; }
        public string LeadStatus { get; set; }
        public string LeadSharedWith { get; set; }
        public string Developer { get; set; }
        public string BudgetDesc { get; set; }
        public string ddlText { get; set; }
        public string City { get; set; }
        public string LeadActivity { get; set; }
        public int SegmentID { get; set; }

        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Website { get; set; }
        public string Industry { get; set; }
        public string Address { get; set; }
        public string ZipCode { get; set; }
        public int CityID { get; set; }
        public int StateID { get; set; }
        public int CountryID { get; set; }
        public string Salutation { get; set; }
        public string CompanyName { get; set; }
        public string Title { get; set; }
    }
    public class GetLeadInfoRequestDTO
    {
        public string PhoneNumber { get; set; }
    }

    public class GetMyLeadInfoByPhoneNumberResponseDTO
    {
        public int LeadID { get; set; }
        public string Project { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        //public string Email { get; set; }
        //public string LeadDate { get; set; }
        public string AssignedTo { get; set; }
        public string Status { get; set; }
        public string SharedWith { get; set; }
        //public int activityId { get; set; }
        //public bool updateEnabled { get; set; }
        //  public string Developer { get; set; }
        // public string Budget { get; set; }
        public string CountryCode { get; set; }
        // public string Segment { get; set; }

    }

    public class InitiateCallRequestDTO
    {
        [Required(ErrorMessage = "Lead Id is required")]
        public int LeadId { get; set; }
    }
  
    public class GetLeadInteractionDetailsRequestDTO
    {
        [Required(ErrorMessage = "Lead Id is required")]
        public int LeadId { get; set; }
    }

    public class UpdateUnclaimedLeadDTO
    {
        [Required(ErrorMessage = "Lead Id is required")]
        public int LeadId { get; set; }
        public string LeadStatus { get; set; }
    }
    public class ResponseDTO {
        [Required(ErrorMessage ="ResponseId is Required")]
        public  int ResponseId { get; set; }
    }

   
}
