﻿using Amazon.Runtime.Internal.Util;
using Microsoft.Extensions.Logging;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace sqy.beatsconnect.api.Helpers
{
    public class SMSHelper
    {
        public enum InternationalVendor
        {
            InfiniInternational = 1,
            Mshastra
        }
        public enum DomesticVendor
        {
            InfiniInternational = 1,
            Mshastra,
        }
        private HttpClient client = new HttpClient();
        private readonly Microsoft.Extensions.Logging.ILogger _logger;

        public SMSHelper(Microsoft.Extensions.Logging.ILogger logger)
        {
            _logger = logger;
        }
        public bool SendMeetingOTPSMS(int requestId,
            string countryCode,
            string mobileNo,
            string happyOtp,
            string uHappyOtp
        )
        {
            string smsurl = "";
            bool vflag = false;
            string msg = "";
            try
            {
                var smsKeys = AppSettingsConf.SMSKeySettings();
                var smsSettings = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                if (smsKeys.Testing == 1)
                    mobileNo = smsKeys.TestMobileNo;
                if (countryCode.Replace("+", "") == "91")
                {
                    msg = smsKeys.DomesticSMS;
                    //msg = happyOtp + " is your Square Connect Mobile App Verification Code";
                    msg = msg.Replace("{HappyOtp}", happyOtp).Replace("{UnHappyOtp}", uHappyOtp); // happyOtp + uHappyOtp + " If you were satisfied with your meeting with our representative please Share OTP Xxxx. For any reason if you were not satisfied please share YYYY.";
                    msg = HttpUtility.UrlEncode(msg);
                    mobileNo = HttpUtility.UrlEncode(mobileNo); //"919716214179"; 
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.DomesticUrl;
                    if (smsurl != null)
                    {
                        smsurl = smsurl.Replace("amp;", "").Replace("{MobileNo}", mobileNo.Trim()).Replace("{Message}", msg.Trim());
                        // _logger.LogInformation("SMS URL {0}", smsurl);
                        _logger.LogInformation("Debugging OTP RequestId: " + requestId + " Url: " + smsurl);
                        HttpResponseMessage response = client.GetAsync(smsurl).Result;
                        _logger.LogInformation("HTTP Response OTP RequestID: " + requestId + " {0}", response);

                        var result = response.Content.ReadAsStringAsync().Result;
                        _logger.LogInformation("Debugging OTP RequestId: " + requestId + " Response Headers: " + response);
                        _logger.LogInformation("Debugging OTP RequestId: " + requestId + " Response: " + result);
                        if (response.IsSuccessStatusCode)
                        {
                            if (response.StatusCode.ToString().ToLower() == "ok")
                                vflag = true;
                        }
                    }
                    else
                        vflag = false;

                }
                else if (countryCode.Replace("+", "") == "971")
                {
                    var gccsms = AppSettingsConf.SMSKeySettings();
                    msg = gccsms.GCCMsg;
                    //msg = happyOtp + " is your Square Connect Mobile App Verification Code";
                    msg = msg.Replace("{HappyOtp}", happyOtp).Replace("{UnHappyOtp}", uHappyOtp); // happyOtp + uHappyOtp + " If you were satisfied with your meeting with our representative please Share OTP Xxxx. For any reason if you were not satisfied please share YYYY.";
                    msg = HttpUtility.UrlEncode(msg);
                    mobileNo = HttpUtility.UrlEncode(mobileNo); //"9716214179"; 
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.GCCUrl;
                    if (smsurl != null)
                    {
                        smsurl = smsurl.Replace("amp;", "")
                            .Replace("{MobileNo}", mobileNo.Trim())
                            .Replace("{Message}", msg.Trim())
                            .Replace("{CountryCode}", countryCode.Replace("+", ""));
                        // _logger.LogInformation("SMS URL {0}", smsurl);
                        _logger.LogInformation("Debugging OTP RecNo: " + requestId + " Url: " + smsurl);
                        HttpResponseMessage response = client.GetAsync(smsurl).Result;
                        _logger.LogInformation("HTTP Response {0}", response);

                        var result = response.Content.ReadAsStringAsync().Result;
                        _logger.LogInformation("Debugging OTP RecNo: " + requestId + " Response Headers: " + response);
                        _logger.LogInformation("Debugging OTP RecNo: " + requestId + " Response: " + result);
                        if (response.IsSuccessStatusCode)
                        {
                            if (response.StatusCode.ToString().ToLower() == "ok")
                                vflag = true;
                        }
                    }
                    else
                        vflag = false;
                }
                else
                {
                    string number = mobileNo;
                    msg = happyOtp;
                    msg = HttpUtility.UrlEncode(msg);
                    number = HttpUtility.UrlEncode(number);
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.GlobalUrl;
                    if (smsurl != null)
                    {
                        var Globalsms = AppSettingsConf.SMSKeySettings();
                        var GlobalHappy = Globalsms.GlobalHappysms;
                        var GlobalUnHappy = Globalsms.GlobalUnHappysms;
                        var Happyurl = smsurl.Replace("{api}", url.Apikey).Replace("{MobileNo}", number.Trim()).Replace("{otp}", happyOtp).Replace("{msgTemplate}", GlobalHappy);

                        var UnHappyurl = smsurl.Replace("{api}", url.Apikey).Replace("{MobileNo}", number.Trim()).Replace("{otp}", uHappyOtp).Replace("{msgTemplate}", GlobalUnHappy);

                        HttpResponseMessage Happyresponse = client.GetAsync(Happyurl).Result;

                        HttpResponseMessage unHappyresponse = client.GetAsync(UnHappyurl).Result;

                        _logger.LogInformation("HTTP HappyResponse {0}", Happyresponse);
                        _logger.LogInformation("GolabalunHappyurl {0}", UnHappyurl);
                        _logger.LogInformation("GolabalHappyurl {0}", Happyurl);
                        _logger.LogInformation("HTTP UnhappyResponse {0}", Happyresponse);
                    }
                    else
                        vflag = false;
                }
            }
            catch (Exception ex)
            {
                string str = ex.Message + "Inner Exception " + ex.InnerException;
                _logger.LogInformation("HTTP Exception {0}", str);
                //while (ex.InnerException != null) ex = ex.InnerException;
                //_logger.LogInformation("HTTP Inner Exception {0}", ex.Message);
                _logger.LogInformation("Debugging OTP RecNo: " + requestId + " Exception" + ex.Message);
            }
            _logger.LogInformation("Debugging OTP RecNo: " + requestId + " Existing sendsms");
            return vflag;
        }
        public bool SendSMS(string countryCode, string mobileNo, string smsText,int responseId)
        {
            string smsurl = "";
            bool vflag = false;
            string msg = "";
            try
            {
                var smsKeys = AppSettingsConf.SMSKeySettings();
                var smsSettings = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                if (smsKeys.Testing == 1)
                    mobileNo = smsKeys.TestMobileNo;
                if (countryCode.Replace("+", "") == "91")
                {
                    msg = HttpUtility.UrlEncode(smsText);
                    mobileNo = HttpUtility.UrlEncode(mobileNo); //"919716214179"; 
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.DomesticUrl;
                    if (smsurl != null)
                    {
                        smsurl = smsurl.Replace("amp;", "").Replace("{MobileNo}", mobileNo.Trim()).Replace("{Message}", msg.Trim());
                        HttpResponseMessage response = client.GetAsync(smsurl).Result;
                        //_logger.LogInformation("HTTP Response SMS URL: " + smsurl + " {0}", response);

                        var result = response.Content.ReadAsStringAsync().Result;
                        _logger.LogInformation("Debugging ResponseID "+responseId+"  SMSUrl: " + smsurl + "  Response Headers: " + response);
                        _logger.LogInformation("Debugging ResponseID " + responseId + "  SMSText: " + smsText + " Response: " + result);
                        if (response.IsSuccessStatusCode)
                        {
                            if (response.StatusCode.ToString().ToLower() == "ok")
                                vflag = true;
                        }
                    }
                    else
                        vflag = false;

                }

            }
            catch (Exception ex)
            {
                string str = ex.Message + "Inner Exception " + ex.InnerException;
                _logger.LogInformation("HTTP Exception {0}", str);
                _logger.LogInformation("Debugging SMSUrl: " + smsurl + " Exception" + ex.Message);
            }
            return vflag;

        }
    }
}
