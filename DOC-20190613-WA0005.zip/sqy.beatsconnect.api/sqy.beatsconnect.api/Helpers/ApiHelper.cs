﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api
{
    public static class ApiHelper
    {
        public static IActionResult CreateErrorResponse(Controller controller, string message)
        {
            var result = new
            {
                Status = 0,
                Message = message,
                Data = new {}
            };
            return controller.Ok(result);
        }

        public static IActionResult CreateSuccessResponse<TEntity>(Controller controller, List<TEntity> data)
        {
            //var status = data.Count == 0 ? 1 : 0;
            var message = data.Count > 0 ? "" : "No record(s) found";
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
                Data = data
            });
        }

        public static IActionResult CreateSuccessResponse<TEntity>(Controller controller, TEntity data, string message = "")
        {
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
                Data = data
            });
        }
        public static IActionResult CreateSuccessResponse<TEntity>(Controller controller, TEntity data, string message, int status)
        {
            return controller.Ok(new
            {
                Status = status,
                Message = message,
                Data = data
            });
        }
        public static IActionResult CreateSuccessResponse(Controller controller, string message)
        {
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
                Data = new {}
            });
        }
        public static IActionResult UpdateSuccessResponse(Controller controller, string message)
        {
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
            });
        }
        public static void ValidateModelState(ModelStateDictionary modelState)
        {
            if(!modelState.IsValid)
            {
                var error = modelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                throw new ApplicationException(error);
            }
        }
    }
}
