﻿using Microsoft.Extensions.Caching.Memory;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Helpers
{
    public static class CacheKeys
    {
        public static string ProductsEntry { get { return "_Products"; } }
        public static string LocationsEntry { get { return "_Locations"; } }
    }
    public class CacheHelper
    {
        private IMemoryCache memoryCache;
        public CacheHelper(IMemoryCache memoryCache)
        {
            this.memoryCache = memoryCache;
        }

        public List<GetProductsProductDTO> CachedProducts
        {
            get
            {
                List<GetProductsProductDTO> products = null;
                if (!memoryCache.TryGetValue<List<GetProductsProductDTO>>(CacheKeys.ProductsEntry, out products))
                {
                    DABCApiProduct da = new DABCApiProduct();
                    DEBCApiProduct de = new DEBCApiProduct()
                    {
                        CallValue = DEBCApiProductCallValues.GetProducts
                    };

                    var datas = da.GetProducts(de);
                    products =
                        datas[0].Select(
                            d => GenericHelper.CopyObject<DEBCApiProductDBResponse, GetProductsProductDTO>(d)).ToList();

                    var cacheEntryOptions = new MemoryCacheEntryOptions()
                        .SetAbsoluteExpiration(TimeSpan.FromHours(1));

                    memoryCache.Set(CacheKeys.ProductsEntry, products, cacheEntryOptions);
                }

                return products;
            }
        }

        public List<LocationVM> CachedLocations
        {
            get
            {
                List<LocationVM> locations = null;
                if (!memoryCache.TryGetValue<List<LocationVM>>(CacheKeys.LocationsEntry, out locations))
                {
                    var da = new DABCApiRMProfile();
                    var de = new DEBCApiRMProfile()
                    {
                        CallValue = DEBCApiRMProfileCallValues.GetLocations
                    };

                    var datas = da.GetLists(de);
                    locations =
                        datas[0].Select(
                            d => GenericHelper.CopyObject<BCApiRMProfileDBResponse, LocationVM>(d)).ToList();

                    var cacheEntryOptions = new MemoryCacheEntryOptions()
                        .SetAbsoluteExpiration(TimeSpan.FromHours(1));

                    memoryCache.Set(CacheKeys.LocationsEntry, locations, cacheEntryOptions);
                }
                return locations;
            }
        }
    }
}
