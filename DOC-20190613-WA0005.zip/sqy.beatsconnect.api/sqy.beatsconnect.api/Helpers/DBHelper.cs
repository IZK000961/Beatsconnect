﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Helpers
{
    public static class DBHelper
    {
        public string ValidateToken { get; set; }
    }
}
