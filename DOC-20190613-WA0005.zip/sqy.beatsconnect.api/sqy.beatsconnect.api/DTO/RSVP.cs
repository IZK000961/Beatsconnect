﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.DTO
{
    public class GetSummaryByChannelPartnerRequestDTO
    {
        public int CpId { get; set; }
    }

    public class GetTCFMCFByChannelPartner
    {
        public int CpId { get; set; }
        public string Type { get; set; }
    }
}
