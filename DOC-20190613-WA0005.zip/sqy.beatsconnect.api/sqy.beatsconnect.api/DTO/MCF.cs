﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.DTO
{
    public class GetMCFRequestDTO
    {

        public int PageNo { get; set; } = 1;
        public int DateType { get; set; } = 2;
        public string FromDate { get; set; } = "2015-12-01";
        public string ToDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public string MCFStatus { get; set; } = "DRAFT";
        public int PnLID { get; set; } = -1;
        public int EmpID { get; set; } = -1;
        public string PrefixText { get; set; } = "%%";
        public int CurrentUser { get; set; }
        public int IsAdmin { get; set; } = 0;
        public string MCFIDs { get; set; } = "";
        public int PnLHeadID { get; set; } = -1;
        public bool IncludeTeam { get; set; }
    }
    public class GetMCFListFilterResponseDTO
    {
        public List<DateRangeResponse> dateRange { get; set; }
        public List<string> mcfStatus { get; set; }
       
    }
    public class GetShareHolderResponseDTO
    {
        public string employeeId { get; set; }
        public string employeeName { get; set; }
    }
    public class GetPlResponseDTO
    {
        public string pnlId { get; set; }
        public string pnlName { get; set; }
    }
    public class GetMCFStatusResponseDTO
    {
        public string statusId { get; set; }
        public string statusName { get; set; }
    }
    public class DateRangeResponse
    {
        public string RangeType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
    public class MCFDetailsResponseDTO
    {
        public int McfId { get; set; }
        public string MCFRefrenceId { get; set; }
        public string MCFStatus { get; set; }
        public string ClientName { get; set; }
        public string LoanAmount { get; set; }
        public string LoanType { get; set; }
        public string SanctionedAmount { get; set; }
        public string SubmittedOn { get; set; }
        public string SubmittedBy { get; set; }
        public string NR { get; set; }
        public string ShareHolder { get; set; }
        public string PnLName { get; set; }
        public string SharePercentage { get; set; }
    }
}
