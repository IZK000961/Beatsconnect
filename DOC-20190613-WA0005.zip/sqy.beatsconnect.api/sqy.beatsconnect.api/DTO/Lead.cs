﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.DTO
{
    public class LeadShareToEmployeeRequestDTO
    {
        [Required(ErrorMessage ="Please Enter Comment")]
        public string Comments { get; set; }   
        public int EmpId { get; set; }
        public int LeadId { get; set; }
    }

    public class UpdateLeadAllowedStatusRequestDTO
    {
        public string EmpId { get; set; }
        public bool Status { get; set; }
    }

    public class LeadMeetingOTPDTO
    {
        public int leadActivityId { get; set; }
        public int OTP { get; set; } =0;
        public int CurrentUser { get; set; } = 0;
       
    }
    public class SendOTPDTO
    {
        public DateTime deliveredTS { get; set; }
        public string status { get; set; }
        public string phoneNo { get; set; }
    }
}
