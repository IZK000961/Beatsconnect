﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.ViewModels
{
    public class leadFilter
    {
        public int callValue { get; set; }
        public string apiAccessCode { get; set; }
        public string contact { get; set; } = "%%";
        public string firstName { get; set; } = "%%";
        public string developer { get; set; } = "-1";
        public int assignedTo { get; set; } = -1;
        public int leadStatus { get; set; } = -1;
        public int pnlId { get; set; } = -1;
        public string project { get; set; } = "-1";
        public int segmentId { get; set; } = -1;
        public int sharedWith { get; set; } = -1;
        public int source { get; set; } = -1;
        public int cpId { get; set; } = -1;
        public int t2oPnL { get; set; } = -1;
        public int pageNo { get; set; } = 1;
        public int leadId { get; set; } = 1;
        public int dateType { get; set; } = -1;
        public int locationType { get; set; } = -1;
        public int parentId { get; set; } = -1;
        public string key { get; set; } = "%%";
        public DateTime fromDate { get; set; }
        public DateTime toDate { get; set; }
    }


}
