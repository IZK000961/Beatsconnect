﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.ViewModels
{
    public class leadVM
    {
        public int leadID { get; set; }
        public bool returnEnabled { get; set; }
        public string project { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string phoneNumber { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
        public string status { get; set; } = string.Empty;
        public string assignedTo { get; set; } = string.Empty;
        public string sharedWith { get; set; } = string.Empty;
       // public int leadSection { get; set; } = 0;
        public string leadSection { get; set; } = string.Empty;
        public DateTime leadDate { get; set; }

    }
}
