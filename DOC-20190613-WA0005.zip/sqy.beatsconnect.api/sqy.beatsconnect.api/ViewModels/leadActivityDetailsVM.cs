﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.ViewModels
{
    public class leadActivityDetailsVM
    {
        public int RecNo { get; set; }
        public int LeadID { get; set; }
        public string Developer { get; set; } = string.Empty;
        public string Project { get; set; } = string.Empty;
        public string Source { get; set; } = string.Empty;
        public string SourceDetails { get; set; } = string.Empty;
        public string LeadStatus { get; set; } = string.Empty;
        public string StatusDesc { get; set; } = string.Empty;
        public DateTime InteractionDate { get; set; }
        public string ActivityID { get; set; } = string.Empty;
        public string Activity { get; set; } = string.Empty;
        public string Assigned { get; set; } = string.Empty;
        public string AssignedTo { get; set; } = string.Empty;
        public DateTime NextInteractionDate { get; set; }
        public string NextActivityID { get; set; } = string.Empty;
        public string NextActivity { get; set; } = string.Empty;
        public string Comments { get; set; } = string.Empty;
        public string Budget { get; set; } = string.Empty;
        public string UpdatedBy { get; set; } = string.Empty;
        
    }
}
