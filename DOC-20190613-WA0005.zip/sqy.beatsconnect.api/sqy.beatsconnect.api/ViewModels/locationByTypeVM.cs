﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.ViewModels
{
    public class locationByTypeVM
    {
        public int locationID { get; set; }
        public string locationName { get; set; } = string.Empty;
        public int parentId { get; set; } 

    }
}
