﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.ViewModels
{
    public class empForReassignmentVM
    {
        public int employeeID { get; set; }
        public string employeeName { get; set; } = string.Empty;
        public string employeeCode { get; set; } = string.Empty;

    }
}
