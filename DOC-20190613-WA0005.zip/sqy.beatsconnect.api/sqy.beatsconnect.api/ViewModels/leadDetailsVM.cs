﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.ViewModels
{
    public class leadDetailsVM
    {
        public int LeadID { get; set; }
        public string SageCRMID { get; set; }
        public string InterestType { get; set; }
        public string Source { get; set; } = string.Empty;
        public string SourceDetails { get; set; } = string.Empty;
        public string Developer { get; set; } = string.Empty;
        public string Project { get; set; } = string.Empty;
        public string Unit { get; set; } = string.Empty;
        public string Budget { get; set; } = string.Empty;
        public string Salutation { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string BudgetDesc { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime LeadDate { get; set; }
        public DateTime LeadGenerationDate { get; set; }
        public string Status { get; set; } = string.Empty;
        public string AssignedTo { get; set; } = string.Empty;
        public string AssignedToCode { get; set; } = string.Empty;
        public string SharedWith { get; set; } = string.Empty;
    }
}
