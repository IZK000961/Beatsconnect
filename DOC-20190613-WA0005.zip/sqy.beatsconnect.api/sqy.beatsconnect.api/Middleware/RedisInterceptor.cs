﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using sqy.Redis.WrapperCore;
using sqy.beatsconnect.Helper;
using System.Linq;
using System.Web;
using Microsoft.Extensions.Primitives;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace sqy.beatsconnect.api.Middleware
{
    public class RedisInterceptor
    {
        #region"Instance Variables"
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;
        #endregion

        #region"ctor"
        public RedisInterceptor(RequestDelegate next, ILogger<RedisInterceptor> logger)
        {
            _next = next;
            _logger = logger;
        }
        #endregion

        #region"Invoke Functions"
        public async Task Invoke(HttpContext context)
        {
            

            var _requestUrl = context.Request.Path;
            int _IsCachedEnabled = AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).IsCachingEnabled;
            string _responseContentType = string.Empty;
            Boolean _urlEnabledForCaching = false;
            Boolean _purgeRequired = false;
            int _UserSpecificKeyRequired = 1; //Default value is enabled, as to give authentic data in case user forget

            int redisTTL = 0;
            (_urlEnabledForCaching, _responseContentType, redisTTL, _UserSpecificKeyRequired) = CheckIfUrlConfiguredForCaching(_requestUrl);
            if (_urlEnabledForCaching == true && (_IsCachedEnabled == 1))
            {
                RedisCache cache = new RedisCache();

                if (!cache.IsRedisAvailable)
                {
                    await _next(context);
                    _logger.LogError("Redis Interceptor: Redis Not available.");
                    return;
                }

                var _RedisKey = await CheckRequest(context.Request, _UserSpecificKeyRequired);
                bool _IsUserValidated = _RedisKey.Item4;

                _purgeRequired = _RedisKey.Item3;

                Boolean _keyEx = cache.IsKeyExist(_RedisKey.Item1);
                context.Request.Body = _RedisKey.Item2.Body;
                string _ContentType = context.Request.ContentType;

                if (_purgeRequired && _keyEx)
                {
                    cache.DeleteItem(_RedisKey.Item1);
                    _keyEx = false;
                }

                if (_keyEx)
                {
                    //Validate User
                    if (_IsUserValidated)
                    {
                        string _response = cache.TryGet<String>(_RedisKey.Item1, redisTTL);
                        context.Response.ContentType = _responseContentType;
                        context.Response.StatusCode = 200;

                        await context.Response.WriteAsync(_response);
                        return;
                    }
                }

                var originalBodyStream = context.Response.Body;

                using (var responseBody = new MemoryStream())
                {
                    context.Response.Body = responseBody;
                    await _next(context);

                    var response = await FormatResponse(context.Response);
                    if (context.Response.StatusCode == 200 && _IsUserValidated)
                    {
                        int noresult = response.IndexOf("No record(s) found");
                        if (noresult == -1)
                            cache.SetValue(_RedisKey.Item1, response, redisTTL);
                    }

                    await responseBody.CopyToAsync(originalBodyStream);
                }
            }
            else
                await _next(context);
          
        }
        #endregion

        #region"Authentication"

        private bool ValidateUser(HttpContext context)
        {
            StringValues authorization;
            if (context.Request.Headers.TryGetValue("Authorization", out authorization))
            {
                authorization = authorization.ToString().Replace("Bearer ", "");

                DABCApiLogin da = new DABCApiLogin();
                DEBCApiLogin de = new DEBCApiLogin()
                {
                    CallValue = DEBCApiLoginCallValues.ValidateToken,
                    Token = authorization
                };

                var validToken = da.ValidateToken(de);
                if (validToken.UserId == 0)
                {
                    return false;
                }

                context.Items["CurrentUserID"] = validToken.UserId.ToString();
                context.Items["CurrentLoginType"] = validToken.LoginType;
                context.Items["CurrentUserData"] = validToken;
                return true;
            }
            return false;
        }

        #endregion

        #region"Functions"
        private async Task<(string, HttpRequest, bool, bool)> CheckRequest(HttpRequest request, int UserSpecificKeyRequired)
        {
            var context = request.HttpContext;
            Boolean IsUserValidated = ValidateUser(context);

            var requestBodyStream = new MemoryStream();
            var originalRequestBody = request.Body;

            await request.Body.CopyToAsync(requestBodyStream);
            requestBodyStream.Seek(0, SeekOrigin.Begin);

            var requestBodyText = await new StreamReader(requestBodyStream).ReadToEndAsync();

            requestBodyStream.Seek(0, SeekOrigin.Begin);
            request.Body = requestBodyStream;

            string _Method = request.Method;
            string _Path = request.Path;

            QueryString _param = request.QueryString;
            bool isPurgeRequired = false;

            if (request.QueryString.HasValue)
            {
                if (!string.IsNullOrWhiteSpace(request.Query["purge"]))
                {
                    string _val = request.Query["purge"];
                    isPurgeRequired = (_val == "1");
                }
            }

            //remove purge key from url before making md5 key
            var _removePurgedQryString = HttpUtility.ParseQueryString(request.QueryString.Value);
            _removePurgedQryString.Remove("purge");

            string _ContentType = request.ContentType;
            string _UserId = string.Empty;

            if (IsUserValidated)
            {
                _UserId = Convert.ToString(context.Items["CurrentUserID"]);
            }

            String _dKey = _Method + "_" + _Path + "_" + (_param.HasValue ? _removePurgedQryString.ToString() : string.Empty)
                                + (_Method == "POST" ? requestBodyText : string.Empty);

            if (UserSpecificKeyRequired == 1)
                _dKey += _UserId;


            string _md5Key = $"APIC_{MD5Hash.GenerateHash(_dKey)}";

            return (_md5Key, request, isPurgeRequired, IsUserValidated);
        }

        private async Task<string> FormatResponse(HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);
            string text = await new StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, SeekOrigin.Begin);
            return text;
        }

        private (bool, string, int, int) CheckIfUrlConfiguredForCaching(string url)
        {
            List<CacheUrl> _urls = new List<CacheUrl>();
            _urls = AppSettingsConf.CacheUrlList();

            int cnt = _urls.Where(x => x.UrlEndpoint == url).Count();
            CacheUrl c = null;
            if (cnt > 0)
            {
                c = _urls.Where(x => x.UrlEndpoint == url).FirstOrDefault();
                return ((c.enabled == 1), c.response_contenType, c.ttl, c.userSpecificKeyEnabled);
            }
            else
                return (false, "application/json", 0, 0);
        }
        #endregion
    }
}
