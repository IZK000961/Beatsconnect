﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api
{
    public class BeatsAuthorizeAttribute : TypeFilterAttribute
    {
        public BeatsAuthorizeAttribute()
             : base(typeof(BeatsAuthorizeAttributeExecutor))
        {

        }

        private class BeatsAuthorizeAttributeExecutor : IAsyncActionFilter
        {
            private readonly IConfiguration _configuration;
            public BeatsAuthorizeAttributeExecutor(IConfiguration configuration)
            {
                _configuration = configuration;
            }
            public async Task OnActionExecutionAsync(ActionExecutingContext context,ActionExecutionDelegate next)
            {
                try
                {
                    
                    var controllerActionDescriptor = context.ActionDescriptor as ControllerActionDescriptor;
                    object[] actionAttributes = new object[] { };
                    if (controllerActionDescriptor != null)
                    {
                        actionAttributes = controllerActionDescriptor.MethodInfo.GetCustomAttributes(inherit: true);
                    }
                    var isAnonymous = actionAttributes.Any(filter => filter is IAllowAnonymous);

                    StringValues authorization;
                    if (context.HttpContext.Request.Headers.TryGetValue("Authorization", out authorization))
                    {
                        authorization = authorization.ToString().Replace("Bearer ", "");

                        DABCApiLogin da = new DABCApiLogin();
                        DEBCApiLogin de = new DEBCApiLogin()
                        {
                            CallValue = DEBCApiLoginCallValues.ValidateToken,
                            Token = authorization
                        };

                        //check if validation is already performed in Redis Interceptor
                        ValidUserData validToken= new ValidUserData();
                        if (context.HttpContext.Items["CurrentUserID"] == null)
                        {
                            validToken = da.ValidateToken(de);
                            validToken.ApiAccessToken = authorization;
                        }
                        else
                        {
                            //validToken.UserId = Convert.ToInt32(context.HttpContext.Items["CurrentUserID"]);
                            //validToken.LoginType = Convert.ToString(context.HttpContext.Items["CurrentLoginType"]);
                            validToken = (ValidUserData)context.HttpContext.Items["CurrentUserData"];
                        }
                        
                        //var validToken = da.ValidateToken(de);
                        if (validToken.UserId == 0)
                        {

                            /*
                            var data = new {

                            };

                            HttpResponseMessage responseMessage = new HttpResponseMessage()
                            {
                                StatusCode = System.Net.HttpStatusCode.OK,
                                Content = new StringContent(JsonConvert.SerializeObject(data))
                            };
                            responseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            */
                            if (!isAnonymous)
                            {
                                context.HttpContext.Response.StatusCode = 200;
                                context.Result = new JsonResult(new
                                {
                                    Status = 2,
                                    Message = "Invalid/Expired token",
                                    Data = new {}
                                });
                                return;
                            }
                        }
                        context.HttpContext.Items["CurrentUserID"] = validToken.UserId.ToString();
                        context.HttpContext.Items["CurrentLoginType"] = validToken.LoginType;
                        context.HttpContext.Items["CurrentUserData"] = validToken;
                    }
                    await next();
                }
                catch (Exception ex)
                {
                    context.Result = new JsonResult(new
                    {
                        Status = 0,
                        Message = ex.Message,
                        Data = new { }
                    });
                    return;
                }
            }
        }
    }
}
