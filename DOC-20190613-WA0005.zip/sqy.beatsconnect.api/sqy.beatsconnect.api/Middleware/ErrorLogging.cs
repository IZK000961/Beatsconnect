﻿using Microsoft.AspNetCore.Http;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api
{
    public class ErrorLogging
    {
        private readonly RequestDelegate _next;

        public ErrorLogging(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                //apiResponse api = new apiResponse();
                //api.status = 0;
                //api.message = ex.Message;
             //   context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                //await context.Response.WriteAsync(ex.Message);
                context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            }
        }


    }
}
