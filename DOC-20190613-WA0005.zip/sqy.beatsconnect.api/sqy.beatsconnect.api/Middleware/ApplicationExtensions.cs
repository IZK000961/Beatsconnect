﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api
{
    public static class ApplicationExtensions
    {
        public static IApplicationBuilder UseBeatsErrorLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ErrorLogging>();
        }
    }
}
