﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Middleware
{
    public class TimeZoneHelper
    {
        public static double getTimeZone(string timezone)
        {
            TimeSpan ts;
            if (timezone.StartsWith("-", StringComparison.OrdinalIgnoreCase))
                ts = -TimeSpan.ParseExact(timezone.Replace("-", ""), "hh\\:mm", System.Globalization.CultureInfo.InvariantCulture);
            else
                ts = TimeSpan.ParseExact(timezone.Replace("+", ""), "hh\\:mm", System.Globalization.CultureInfo.InvariantCulture);
            TimeSpan ourTimeZone = new TimeSpan(5, 30, 0);

            return (ts - ourTimeZone).TotalMinutes;
        }
    }
}
