﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.IdentityModel.Tokens;
using sqy.beatsconnect.api.Helpers;
using sqy.beatsconnect.api.Middleware;
using sqy.beatsconnect.Helper;
using Swashbuckle.AspNetCore.Swagger;
using System.IO;
using System.Text;

namespace sqy.beatsconnect.api
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddJsonFile("CacheURL.json", true, true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();    
            
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMemoryCache();
            //ENABLES JWT AUTHENTICATION
            services.AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = "JwtBearer";
                    options.DefaultChallengeScheme = "JwtBearer";
                }).AddJwtBearer("JwtBearer", jwtBearerOptions =>
                {
                    jwtBearerOptions.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SigningKey"])),

                        ValidateIssuer = true,
                        ValidIssuer = Configuration["Issuer"],

                        ValidateAudience = true,
                        ValidAudience = Configuration["Audience"],

                        ValidateLifetime = true,
                        ValidateActor = true
                    };
                });

            services.AddMvc();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "My API", Version = "v1" });
                var filePath = Path.Combine(PlatformServices.Default.Application.ApplicationBasePath, "sqy.beatsconnect.api.xml");
                c.IncludeXmlComments(filePath);
                c.OperationFilter<AddAuthorizationHeaderParameterOperationFilter>();
            });

            
            
            AppSettingsConf.Configuration = Configuration;

            // services.Add(new ServiceDescriptor(typeof(SqyBeatsConnectDBContext), new SqyBeatsConnectDBContext(Configuration.GetConnectionString("DefaultConnection"))));
            // services.AddTransient<SqyBeatsConnectDBContext>(_ => new SqyBeatsConnectDBContext(Configuration.GetConnectionString("DefaultConnection")));
            //services.AddTransient<ILogger>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            //app.UseBeatsErrorLogging();
            app.UseDeveloperExceptionPage();
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}
            //else
            //{
            //    app.UseExceptionHandler();
            //}
            
            loggerFactory.AddFile("Logs/beatsapicore.log");
            app.UseAuthentication();
            app.UseStaticFiles();
            app.UseMiddleware<RedisInterceptor>();
            // app.UseMvc();
            app.UseMvc(routes => routes.MapRoute("Default", "api/{controller}/{action}"));

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
            });
        }
    }
}
