﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using Microsoft.Extensions.Caching.Memory;
using sqy.beatsconnect.api.Helpers;
using sqy.beatsconnect.api.Models;
using System.IO;
using sqy.beatsconnect.Helper;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class RMProfileController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly ILogger _logger;
        private readonly IMemoryCache _memoryCache;
        public RMProfileController(IHostingEnvironment hostingEnvironment, ILogger<UserController> logger, IMemoryCache memoryCache)
        {
            _hostingEnvironment = hostingEnvironment;
            _logger = logger;
            _memoryCache = memoryCache;
        }

        private ValidUserData currentUserData
        {
            get
            {
                return (ValidUserData)HttpContext.Items["CurrentUserData"];
            }
        }

        /// <summary>
        /// Gets profile of a user
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /GetProfile
        ///     {
        ///		  
        ///		}
        ///		
        /// Sample Response:
        /// 
        ///     GET /GetProfile
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": {
        ///             "employeeId": 1795,
        ///             "highestEducations": [
        ///                 {
        ///                     "id": 1,
        ///                     "displayName": "Primary Education",
        ///                     "selected": false
        ///                 },
        ///                 {
        ///                     "id": 2,
        ///                     "displayName": "Secondary Education",
        ///                     "selected": false
        ///                 }
        ///             ],
        ///             "careerStartingMonth": 9,
        ///             "careerStartingYear": 2011,
        ///             "nativeCityId": 3426,
        ///             "nativeStateId": 739,
        ///             "nativeCountryId": 100,
        ///             "interests": [
        ///                 {
        ///                     "id": 1,
        ///                     "displayName": "Auto Enthusiast",
        ///                     "selected": false
        ///                 },
        ///                 {
        ///                     "id": 2,
        ///                     "displayName": "Avid Investor",
        ///                     "selected": false
        ///                 }
        ///             ],
        ///             "noOfDependents": 2,
        ///             "noOfDependentKids": 1,
        ///             "languages": [
        ///                 {
        ///                     "id": 1,
        ///                     "displayName": "English",
        ///                     "selected": true,
        ///                     "languageLevel": "Proficient"
        ///                 },
        ///                 {
        ///                     "id": 3,
        ///                     "displayName": "Hindi",
        ///                     "selected": true,
        ///                     "languageLevel": "Proficient"
        ///                 }
        ///             ],
        ///             "countries": [
        ///                 {
        ///                     "locationId": 2,
        ///                     "locationName": "Afghanistan",
        ///                     "parentId": 0
        ///                 },
        ///                 {
        ///                     "locationId": 5,
        ///                     "locationName": "Albania",
        ///                     "parentId": 0
        ///                 }
        ///             ],
        ///             "aboutYourself": "..."
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>List of Leads</returns>
        [HttpGet]
        [Route("GetProfile")]
        public IActionResult GetProfile()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var da = new DABCApiRMProfile();
                    var de = new DEBCApiRMProfile()
                    {
                        CallValue = DEBCApiRMProfileCallValues.GetRMProfileDetails,
                        CurrentUserId = currentUserData.UserId
                    };

                    var data = da.GetLists(de);

                    var interests = data[1].Select(d => new {
                        d.Id,
                        d.DisplayName,
                        d.Selected
                    });
                    var highestEducations = data[2].Select(d => new
                    {
                        d.Id,
                        d.DisplayName,
                        d.Selected
                    });
                    var languages = data[3].Select(d => new
                    {
                        d.Id,
                        d.DisplayName,
                        d.Selected,
                        d.LanguageLevel
                    });

                    var cacheHelper = new CacheHelper(_memoryCache);

                    var countries = cacheHelper.CachedLocations
                        .Where(l => l.Type == 0)
                        .Select(l => new {
                            LocationId = l.Id,
                            LocationName = l.DisplayName,
                            ParentId = l.ParentId
                        })
                        .OrderBy(l => l.LocationName)
                        .ToList();

                    var res = data[0].Select(d => new {
                        d.EmployeeId,
                        highestEducations,
                        d.CareerStartingMonth,
                        d.CareerStartingYear,
                        d.NativeCityId,
                        d.NativeStateId,
                        d.NativeCountryId,
                        interests,
                        d.NoOfDependents,
                        d.NoOfDependentKids,
                        languages,
                        countries,
                        d.AboutYourself
                    }).First();

                    return ApiHelper.CreateSuccessResponse(this, res);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Get sub locations by location id
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /GetLocations
        ///     {
        ///         "locationId": 0
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     POST /GetLocations
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": [
        ///             {
        ///                 "id": 732,
        ///                 "displayName": "Andhra Pradesh",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 733,
        ///                 "displayName": "Assam",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 734,
        ///                 "displayName": "Bihar",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 735,
        ///                 "displayName": "Chandigarh",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 736,
        ///                 "displayName": "Chhattisgarh",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 737,
        ///                 "displayName": "Delhi",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 738,
        ///                 "displayName": "Gujarat",
        ///                 "parentId": 100
        ///             },
        ///             {
        ///                 "id": 739,
        ///                 "displayName": "Haryana",
        ///                 "parentId": 100
        ///             }
        ///         ]
        ///     }
        ///     
        /// </remarks>
        /// <returns>Get states in a country</returns>
        [HttpPost]
        [Route("GetLocations")]
        public IActionResult GetLocations([FromBody] GetLocationsRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var cacheHelper = new CacheHelper(_memoryCache);

                    var states = cacheHelper.CachedLocations
                        .Where(l => l.ParentId == req.LocationId)
                        .Select(l => new {
                            LocationId = l.Id,
                            LocationName = l.DisplayName,
                            ParentId = l.ParentId
                        })
                        .OrderBy(l => l.LocationName)
                        .ToList();

                    var res = states;

                    return ApiHelper.CreateSuccessResponse(this, res);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }


        /// <summary>
        /// Updates the profile
        /// </summary>
        /// <param name="req"></param>
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /UpdateProfile
        ///     {
        ///     	"HighestEducationId": 3,
        ///     	"CareerStartingMonth": 9,
        ///     	"CareerStartingYear": 2011,
        ///     	"NativeCityId": 3426,
        ///     	"NativeStateId": 739,
        ///     	"NativeCountryId": 100,
        ///     	"InterestIds": [3, 7],
        ///     	"NoOfDependents": "2",
        ///     	"NoOfDependentKids": "1",
        ///     	"languages": [{
        ///     			"languageId": 1,
        ///     			"languageLevel": "Proficient"
        ///     		}, {
        ///     			"languageId": 2,
        ///     			"languageLevel": "Proficient"
        ///     		}
        ///     	],
        ///     	"AboutYourself": "Test Remarks"
        ///     }
        ///     
        /// Sample Response:
        /// 
        ///     POST /UpdateProfile
        ///     {
        ///         "status": 1,
        ///         "message": "Successfully Updated",
        ///         "data": {}
        ///     }
        /// 
        /// </remarks>
        /// <returns>Returns success message or error</returns>
        [HttpPost]
        [Route("UpdateProfile")]
        public IActionResult UpdateProfile([FromBody] UpdateProfileRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if(req.Languages == null || req.Languages.Count < 1)
                    {
                        throw new ApplicationException("Atleast 1 language is required");
                    }
                    var da = new DABCApiRMProfile();
                    var de = new DEBCApiRMProfile()
                    {
                        CallValue = DEBCApiRMProfileCallValues.UpdateRMProfile,
                        CurrentUserId = currentUserData.UserId,
                        HighestEducationId = req.HighestEducationId,
                        CareerStartingDate = new DateTime(req.CareerStartingYear, req.CareerStartingMonth == 0 ? 1 : req.CareerStartingMonth, 1),
                        NativeCityId = req.NativeCityId,
                        NativeStateId = req.NativeStateId,
                        NativeCountryId = req.NativeCountryId,
                        InterestIds = string.Join(",", req.InterestIds),
                        NoOfDependents = Convert.ToInt32(req.NoOfDependents.Replace("+", "")),
                        NoOfDependentKids = Convert.ToInt32(req.NoOfDependentKids.Replace("+", "")),
                        AboutYourself = req.AboutYourself
                    };

                    da.GetLists(de);

                    foreach(var language in req.Languages)
                    {
                        de.CallValue = DEBCApiRMProfileCallValues.AddLanguage;
                        de.LanguageId = language.LanguageId;
                        de.LanguageLevel = language.LanguageLevel;

                        da.GetLists(de);
                    }
                    return ApiHelper.CreateSuccessResponse(this, "Successfully Updated");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Gets profile summary of a user
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /GetProfileSummary
        ///     {
        ///		  
        ///		}
        ///		
        /// Sample Response:
        /// 
        ///     GET /GetProfileSummary
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": {
        ///             "employeeId": 1795,
        ///             "isProfileUpdated": true,
        ///             "highestEducation": "Graduate",
        ///             "careerStarting": "September, 2011",
        ///             "nativeCity": "Gurugram",
        ///             "nativeState": "Haryana",
        ///             "nativeCountry": "India",
        ///             "noOfDependents": 2,
        ///             "noOfDependentKids": 1,
        ///             "interests": "Comics & Animation Fan, Gamer",
        ///             "languagesKnown": "English, Hindi",
        ///             "aboutYourself": "Test Remarks"
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>Get profile summary</returns>
        [HttpGet]
        [Route("GetProfileSummary")]
        public IActionResult GetProfileSummary()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var da = new DABCApiRMProfile();
                    var de = new DEBCApiRMProfile()
                    {
                        CallValue = DEBCApiRMProfileCallValues.GetRMPRofileSummary,
                        CurrentUserId = currentUserData.UserId
                    };

                    var data = da.GetLists(de);
                    
                    var res = data[0].Select(d => new {
                        d.EmployeeId,
                        d.IsProfileUpdated,
                        d.HighestEducation,
                        d.CareerStarting,
                        d.NativeCity,
                        d.NativeState,
                        d.NativeCountry,
                        d.NoOfDependents,
                        d.NoOfDependentKids,
                        d.Interests,
                        d.LanguagesKnown,
                        d.AboutYourself
                    }).First();

                    return ApiHelper.CreateSuccessResponse(this, res);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Updates user profile pic
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /UpdateProfilePic
        ///     {
        ///		}
        ///		
        /// Sample Response:
        /// 
        ///     POST /UpdateProfilePic
        ///     {
        ///         "status": 1,
        ///         "message": "Profile pic uploaded successfully",
        ///         "data": {
        ///             "profilePicUpdated": true,
        ///             "empProfileImage": "https://s3-ap-southeast-1.amazonaws.com/sqy/testing/SDC1216.jpg"
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>Updates user profile pic</returns>
        [HttpPost]
        [Route("UpdateProfilePic")]
        public IActionResult UpdateProfilePic()
        {
            try
            {
                Console.WriteLine("Debugging RMProfile/UpdateProfilePic/");
                if (!Request.HasFormContentType)
                    throw new ApplicationException("Please use form-data content type");

                var profilePic = Request.Form.Files["profilePic"];
                Console.WriteLine("Debugging RMProfile/UpdateProfilePic/=> profilePic" + profilePic.FileName);
                var profilePicPath = AppSettingsConf.GetAWSKeys().AWSPath_EmployeeProfilePic;
                Console.WriteLine("Debugging RMProfile/UpdateProfilePic/=> profilePicPath" + profilePicPath);
                if (String.IsNullOrEmpty(profilePicPath))
                    throw new ApplicationException(string.Format("Missing app settings key '{0}'", nameof(AWSKeys.AWSPath_EmployeeProfilePic)));

                Console.WriteLine("Debugging RMProfile/UpdateProfilePic/=> currentUserEmployeeCode" + currentUserData.EmployeeCode);
                var fileName = currentUserData.EmployeeCode.ToUpper() + ".jpg";
                Console.WriteLine("Debugging RMProfile/UpdateProfilePic/ => fileName: " + fileName);

                var awsKeys = AmazonS3Helper.AWSKeys;
                using (var memoryStream = new MemoryStream())
                {
                    profilePic.CopyTo(memoryStream);
                    AmazonS3Helper.Upload(memoryStream, awsKeys.AWSPath_EmployeeProfilePic, fileName);
                }

                // update profile pic url in db
                var da = new DABCApiRMProfile();
                var de = new DEBCApiRMProfile()
                {
                    CallValue = DEBCApiRMProfileCallValues.UpdateProfilePic,
                    CurrentUserId = currentUserData.UserId,
                    ProfilePic = fileName
                };
                var data = da.GetLists(de);

                var res = new
                {
                    ProfilePicUpdated = true,
                    EmpProfileImage = AmazonS3Helper.GetFullPath(awsKeys.AWSPath_EmployeeProfilePic, fileName)
                };

                return ApiHelper.CreateSuccessResponse(this, res, "Profile pic uploaded successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: RMProfile/UpdateProfilePic/ =>" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}