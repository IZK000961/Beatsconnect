﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.Helper;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class TCFController : Controller
    {
        /// <summary>
        /// Gets a list of TCF Filter Details
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        ///		
        /// Sample Response:
        /// 
        ///     POST /GetTCFFiltersDetails
        ///		{
        ///		    "status": 1,
        ///		    "message": "",
        ///		    "data": {
        ///		        "dateRange": [
        ///		            {
        ///		                "rangeType": "MTD",
        ///		                "startDate": "2018-01-07T00:00:00",
        ///		                "endDate": "2018-01-17T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "QTD",
        ///		                "startDate": "2018-01-07T00:00:00",
        ///		                "endDate": "2018-01-17T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "YTD",
        ///		                "startDate": "2018-01-07T00:00:00",
        ///		                "endDate": "2018-01-17T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "Last Month",
        ///		                "startDate": "2017-12-07T00:00:00",
        ///		                "endDate": "2018-01-06T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "Last Quarter",
        ///		                "startDate": "2017-10-07T00:00:00",
        ///		                "endDate": "2018-01-06T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "Last Year",
        ///		                "startDate": "2017-01-07T00:00:00",
        ///		                "endDate": "2018-01-06T00:00:00"
        ///		            }
        ///		        ],
        ///		        "tcfStatus": [
        ///		            "DRAFT",
        ///		            "PREAPPROVAL",
        ///		            "LOANAPPROVAL",
        ///		            "HOLD",
        ///		            "RESUBMIT",
        ///		            "ALLY2BL",
        ///		            "LOANPENDING",
        ///		            "NOTCOUNTED",
        ///		            "SOS",
        ///		            "COUNTED",
        ///		            "DELETED",
        ///		            "CANCELLED",
        ///		            "COLLECTED",
        ///		            "CLIENTACK",
        ///		            "BUSINESSALERT",
        ///		            "SHARETRANSFER",
        ///		            "TPL_PENDING",
        ///		            "RESUBMIT_CRM",
        ///		            "RESUBMIT_LOAN",
        ///		            "RESUBMIT_OPS",
        ///		            "CANCELLED_DATE"
        ///		        ]
        ///		    }
        ///		}
        ///     
        /// </remarks>
        /// <returns>List of TCF Filter</returns>
        [HttpGet, Route("GetTCFFiltersDetails")]
        public IActionResult GetTCFFiltersDetails()
        {
            var currentUser = Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiTCF da = new DABCApiTCF();
                    DEBCApiTCF de = new DEBCApiTCF();
                    var response = new GetTCFFilterDetailsResponseDTO();

                    #region GetDateRange
                    response.dateRange = da.GetDateRange<DateRangeResponse>();
                    #endregion

                    #region GetTCFStatus
                    //var tcfst= TCFReportStatus.
                    List<string> TCFStatus = new List<string>();
                    TCFStatus.Add("DRAFT");
                    TCFStatus.Add("PREAPPROVAL");
                    TCFStatus.Add("LOANAPPROVAL" );
                    TCFStatus.Add( "HOLD");
                    TCFStatus.Add( "RESUBMIT");
                    TCFStatus.Add( "ALLY2BL");
                    TCFStatus.Add( "LOANPENDING");
                    TCFStatus.Add( "NOTCOUNTED");
                    TCFStatus.Add( "SOS");
                    TCFStatus.Add( "COUNTED");
                    TCFStatus.Add( "DELETED");
                    TCFStatus.Add( "CANCELLED");

                    TCFStatus.Add( "COLLECTED");
                    TCFStatus.Add( "CLIENTACK");
                    TCFStatus.Add( "BUSINESSALERT");
                    TCFStatus.Add( "SHARETRANSFER");
                    TCFStatus.Add( "TPL_PENDING");
                    TCFStatus.Add( "RESUBMIT_CRM");
                    TCFStatus.Add( "RESUBMIT_LOAN");
                    TCFStatus.Add( "RESUBMIT_OPS");
                    TCFStatus.Add( "CANCELLED_DATE");

                    //TCFStatus.Insert(0, new GetTCFStatusResponse { StatusId = "-1", StatusName = "All" });
                    response.tcfStatus = TCFStatus;
                    #endregion

                    return ApiHelper.CreateSuccessResponse(this, response);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Gets a list of TCF
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///		{
        ///			"fromDate":"2013-09-01",
        ///			"toDate":"2018-01-25",
        ///			"tcfStatus":"DRAFT",
        ///			"includeTeam":false,
        ///			"isShareHolder":false
        ///		}
        ///		
        /// Sample Response:
        /// 
        ///		{
        ///		    "status": 1,
        ///		    "message": "",
        ///		    "data": [
        ///		        {
        ///		            "tcfId": 40599,
        ///		            "tcfRefrenceId": "TCF-20180125-0017",
        ///		            "tcfStatus": "DRAFT",
        ///		            "rfStatus": "",
        ///		            "project": "Godrej 101",
        ///		            "clientName": "",
        ///		            "submittedOn": "",
        ///		            "submittedBy": "Hitesh Singla",
        ///		            "nr": "0.00",
        ///		            "shareHolder": "",
        ///		            "pnLName": "",
        ///		            "sharePercentage": "",
        ///		            "t2": "",
        ///		            "pnL": "",
        ///		            "pnLRegion": "",
        ///		            "remarks": "",
        ///		            "tat": ""
        ///		        },
        ///		        {
        ///		            "tcfId": 39501,
        ///		            "tcfRefrenceId": "TCF-20171223-0003",
        ///		            "tcfStatus": "DRAFT",
        ///		            "rfStatus": "",
        ///		            "project": "Elite City Real Estate",
        ///		            "clientName": "300 Lead Generation ",
        ///		            "submittedOn": "",
        ///		            "submittedBy": "Hitesh Singla",
        ///		            "nr": "0.00",
        ///		            "shareHolder": "",
        ///		            "pnLName": "",
        ///		            "sharePercentage": "",
        ///		            "t2": "",
        ///		            "pnL": "",
        ///		            "pnLRegion": "",
        ///		            "remarks": "",
        ///		            "tat": ""
        ///		        },
        ///		        {
        ///		            "tcfId": 39189,
        ///		            "tcfRefrenceId": "TCF-20171206-0169",
        ///		            "tcfStatus": "DRAFT",
        ///		            "rfStatus": "",
        ///		            "project": "Ozone Urbana Infra Developers Pvt Ltd",
        ///		            "clientName": "",
        ///		            "submittedOn": "",
        ///		            "submittedBy": "Hitesh Singla",
        ///		            "nr": "0.00",
        ///		            "shareHolder": "",
        ///		            "pnLName": "",
        ///		            "sharePercentage": "",
        ///		            "t2": "",
        ///		            "pnL": "",
        ///		            "pnLRegion": "",
        ///		            "remarks": "",
        ///		            "tat": ""
        ///		        }
        ///		    ]
        ///		}
        ///     
        /// </remarks>
        /// <returns>List of Leads</returns>
        [HttpPost, Route("TCFLists")]
        public IActionResult TCFLists([FromBody] GetTCFRequestDTO req)
        {
            var currentUser = Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiTCF da = new DABCApiTCF();
                    DEBCApiTCF de = new DEBCApiTCF()
                    {
                        //CallValue = DEBCApiTCFCallValues.GetTCFList,
                        PageNo = req.pageNo,
                        CurrentUser = currentUser,
                        FromDate = DateTime.ParseExact(req.FromDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                        ToDate = DateTime.ParseExact(req.ToDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                        TCFStatus = req.TCFStatus,
                        IncludeTeam = req.IncludeTeam,
                        IsShareHolder = req.IsShareHolder,
                        offset = req.pageNo,
                        PrefixText = req.PrefixText,
                        PnLHeadID = req.pnLHeadID,
                        ProductTypeID=req.ProductTypeID,
                    };

                    var response = da.GetTCFListDetails<TCFDetailsResponseDTO>(de);
                    return ApiHelper.CreateSuccessResponse(this, response);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}