﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace sqy.beatsconnect.api.Controllers
{
    [Route("api/[controller]")]
    [BeatsAuthorize]
    public class LoginController : Controller
    {
        private IConfiguration _configuration;
        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Login
        /// </summary>
        /// <param name="user"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///      {
	    ///           "Username": "SYME041",
	    ///           "Password": "1",
	    ///           "DeviceType": "iOS",
	    ///           "DeviceID": "test"
        ///      }
        /// 
        /// Sample response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "",
        ///          "data": {
        ///              "userRole": [
        ///                  4,
        ///                  21,
        ///                  3,
        ///                  35
        ///              ],
        ///              "pnlName": "HK IPM",
        ///              "empCode": "SYME041",
        ///              "empLocation": "Hongkong",
        ///              "empEmail": "sonali.gupta@squareyards.hk",
        ///              "empName": "Sonali Gupta",
        ///              "pnlHeadName": "Abhilekh Kumar",
        ///              "empProfileImage": "http://beats.squareyards.com/resources/dist/img/employees/SYME041.jpg",
        ///              "empDepartment": "IPM International",
        ///              "empDesignation": "Associate Area Manager",
        ///              "empPhone": "852-55337562",
        ///              "empApiAccessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYmYiOjE1MTE3NzczNzQsImV4cCI6MTUxNDM2OTM3NCwiaXNzIjoiQmVhdHMgQ29ubmVjdCBBUEkiLCJhdWQiOiJodHRwO///      i8vbG9jYWxob3N0OjU1NTU2In0.CN0JlT71i-_YPrBBiRwoaWO8GGu6nGdviy2WsWgPFI4",
        ///              "expiration": "2017-12-28 06:16:22",
        ///              "isProfileUpdated": true,
        ///              "loginType": "Employee",
        ///              "empId": 29,
        ///              "empLevel": "T0"
        ///          }
        ///      }
        ///      
        /// </remarks>
        [AllowAnonymous]
        [HttpPost]
        public IActionResult Post([FromBody] LoginRequestDTO user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var username = user.Username;
                    var password = Cryptography.Encrypt(user.Password);

                    DABCApiLogin da = new DABCApiLogin();
                    DEBCApiLogin de = new DEBCApiLogin()
                    {
                        CallValue = DEBCApiLoginCallValues.ValidateUser,
                        Username = username,
                        Password = password
                    };
                    
                    var userInfo = da.ValidateUser(de);
                    if (userInfo == null)
                    {
                        throw new ApplicationException("Invalid username or password");
                    }

                    var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, user.Username),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                    };
                    var token = new JwtSecurityToken(
                        issuer: _configuration["Issuer"],
                        audience: _configuration["Audience"],
                        expires: DateTime.Now.AddDays(30),
                        notBefore: DateTime.UtcNow,
                        signingCredentials: new SigningCredentials(
                            new SymmetricSecurityKey(
                                Encoding.UTF8.GetBytes(_configuration["SigningKey"])),
                                SecurityAlgorithms.HmacSha256)
                    );
                    var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

                    de.CallValue = DEBCApiLoginCallValues.UpdateToken;
                    de.Token = tokenString;
                    de.DeviceID = user.DeviceID;
                    de.DeviceType = user.DeviceType;
                    de.UserID = userInfo.UserID;
                    de.LoginType = userInfo.LoginType;
                    da.UpdateToken(de);

                    int[] roles = new int[] { };
                    if (userInfo.UserRoles != "")
                        roles = userInfo.UserRoles.Split(',').Select(s => Convert.ToInt32(s)).ToArray();
                    // var obj = new ;

                    var awsKeys = AmazonS3Helper.AWSKeys;
                    var response = new LoginResponseDTO()
                    {
                        EmpApiAccessToken = tokenString,
                        EmpCode = userInfo.EmployeeCode,
                        EmpDepartment = userInfo.DepartmentName,
                        EmpDesignation = userInfo.DesignationName,
                        EmpEmail = userInfo.EmailIDOfficial,
                        EmpLocation = userInfo.LocationName,
                        EmpName = userInfo.EmployeeName,
                        EmpPhone = userInfo.ContactNo,
                        EmpProfileImage = userInfo.ProfilePictureFileName == "" ? "" : AmazonS3Helper.GetFullPath(awsKeys.AWSPath_EmployeeProfilePic, userInfo.ProfilePictureFileName),
                        PnlHeadName = userInfo.PnlHeadName,
                        PnlName = userInfo.PnlName,
                        UserRole = roles,
                        Expiration = token.ValidTo.ToString("yyyy-MM-dd HH:mm:ss"),
                        IsProfileUpdated = userInfo.IsProfileUpdated,
                        LoginType = userInfo.LoginType,
                        EmpId = userInfo.UserID,
                        EmpLevel = userInfo.Level
                    };
                    return ApiHelper.CreateSuccessResponse(this, response);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Login
        /// </summary>
        /// <param name="user"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///      {
	    ///           "Username": "SYME041",
	    ///           "Password": "1",
        ///      }
        /// 
        /// Sample response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "",
        ///          "data": {
        ///              "authenticated": true
        ///          }
        ///      }
        ///      
        /// </remarks>
        [AllowAnonymous]
        [HttpPost,Route("WebLogin")]
        public IActionResult WebLogin([FromBody] WebLoginRequestDTO user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var username = user.Username;
                    var password = Cryptography.Encrypt(user.Password);

                    DABCApiLogin da = new DABCApiLogin();
                    DEBCApiLogin de = new DEBCApiLogin()
                    {
                        CallValue = DEBCApiLoginCallValues.ValidateUser,
                        Username = username,
                        Password = password
                    };

                    var userInfo = da.ValidateUser(de);
                    if (userInfo == null)
                    {
                        //throw new ApplicationException("Invalid username or password");
                        var response = new
                        {
                            Authenticated = false,
                        };
                        return ApiHelper.CreateSuccessResponse(this, response);
                    }
                    else
                    {
                        var response = new
                        {
                            Authenticated = true,
                        };
                        return ApiHelper.CreateSuccessResponse(this, response);
                    }
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        private int currentUser
        {
            get
            {
                return Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            }
        }
        private string currentLoginType
        {
            get
            {
                return Convert.ToString(HttpContext.Items["CurrentLoginType"]);
            }
        }

        /// <summary>
        /// Update Device Token
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///      {
	    ///          "DeviceId":"xqcdqw",
	    ///          "DeviceType":"Android 2.3.2 Android Android SDK built for x86"
        ///      }
        /// 
        /// Sample response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "Successfully Updated",
        ///          "data": {}
        ///      }
        ///      
        /// </remarks>
        [Route("UpdateDeviceToken")]
        [HttpPost]
        public IActionResult UpdateDeviceToken([FromBody] UpdateDeviceTokenDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var userId = currentUser;
                    DABCApiLogin da = new DABCApiLogin();
                    DEBCApiLogin de = new DEBCApiLogin()
                    {
                        CallValue = DEBCApiLoginCallValues.UpdateDeviceDetails,
                        DeviceID = req.DeviceID,
                        DeviceType = req.DeviceType,
                        UserID = userId,
                        LoginType = currentLoginType
                    };
                    da.UpdateToken(de);
                    return ApiHelper.CreateSuccessResponse(this, "Successfully Updated");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}
