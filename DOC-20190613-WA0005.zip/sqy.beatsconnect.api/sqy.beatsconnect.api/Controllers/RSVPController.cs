﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.Helper;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using sqy.beatsconnect.api.DTO;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class RSVPController : Controller
    {
        private int currentUser
        {
            get
            {
                return Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            }
        }

        /// <summary>
        /// Get ChannelPartner List ByRM
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///         {
        ///         }
        ///		
        /// Sample Response:
        /// 
        ///         {
        ///             "status": 1,
        ///             "message": "",
        ///             "data": {
        ///                 "channelPartner": [
        ///                     {
        ///                         "cpId": 5514,
        ///                         "cpCode": "SQYCS/CP/8199",
        ///                         "name": "Sheetal Khandhar ",
        ///                         "email": "sheetalkhandhar@yahoo.com",
        ///                         "mobileNo": "97155715549",
        ///                         "mcfBussinessAmount": 0,
        ///                         "tcfBussinessAmount": 0
        ///                     },
        ///                     {
        ///                         "cpId": 5569,
        ///                         "cpCode": "SQYCS/CP/8260",
        ///                         "name": "Mohammed Rafi Rahamathulla ",
        ///                         "email": "mra24717@gmail.com",
        ///                         "mobileNo": "97155999890",
        ///                         "mcfBussinessAmount": 0,
        ///                         "tcfBussinessAmount": 0
        ///                     }
        ///                 ]
        ///             }
        ///         }
        ///     
        /// </remarks>
        /// <returns>List of Channel PartnertByRM( </returns>
        [HttpPost]
        [Route("GetChannelPartnerListByRM")]
        public IActionResult GetChannelPartnerListByRM()
        {

            var currentUser = Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiRSVP da = new DABCApiRSVP();
                    DEBCApiRSVP de = new DEBCApiRSVP()
                    {

                        CallValue = DEBCApiRSVPCallValues.GetChannelPartnerListByRM,
                        CurrentUser = currentUser
                    };

                    var data = da.GetList<DEGetChannelPartnerListByRMResponse>(de);
                    var response =
                    new
                    {
                        channelPartner = data
                    };
                    return ApiHelper.CreateSuccessResponse(this, response, response.channelPartner.Count > 0 ? "" : "No record(s) found", response.channelPartner.Count > 0 ? 1 : 0);


                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }

            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }



        /// <summary>
        /// Get Summary By Channel Partner
        /// </summary>
        /// <param name="req"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///      {
        ///			 "cpId": 1
        ///      }
        ///		
        /// Sample Response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "",
        ///          "data": {
        ///              "realEstateCommission": {
        ///                  "cpid": 1,
        ///                  "totalSubmitted": 0,
        ///                  "totalAccrued": 0,
        ///                  "totalConfirmed": 0,
        ///                  "totalCollected": 121968
        ///              },
        ///              "loanCommission": {
        ///                  "accruedAmount": 0,
        ///                  "collectedAmount": 0
        ///              }
        ///          }
        ///      }
        ///     
        /// </remarks>
        /// <returns>CP Summary</returns>
        [HttpPost]
        [Route("GetSummaryByChannelPartner")]
        public IActionResult GetSummaryByChannelPartner([FromBody] GetSummaryByChannelPartnerRequestDTO req)
        {
            try
            {
                DABCApiRSVP da = new DABCApiRSVP();
                DEBCApiRSVP de = new DEBCApiRSVP()
                {
                    CallValue = DEBCApiRSVPCallValues.GetSummaryByChannelPartner,
                    CPID = req.CpId,
                    CurrentUser = currentUser
                };

                var data = da.GetList<DEBCApiRSVPDBResponse>(de);

                var row = data[0];
                var response = new
                {
                    RealEstateCommission = new
                    {
                        row.CPID,
                        row.TotalSubmitted,
                        row.TotalAccrued,
                        row.TotalConfirmed,
                        row.TotalCollected
                    },
                    LoanCommission = new
                    {
                        AccruedAmount = row.LoanAccruedAmount,
                        CollectedAmount = row.LoanCollectedAmount
                    }
                };

                return ApiHelper.CreateSuccessResponse(this, response);
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Get TCF/MCF By Channel Partner
        /// </summary>
        /// <param name="req"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///      {
        ///          "cpId": 29629,
        ///          "type": "TCF"
        ///      }
        ///		
        /// Sample Response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "",
        ///          "data": {
        ///              "type": "TCF",
        ///              "records": [
        ///                  {
        ///                      "cpId": 29629,
        ///                      "tcfId": 34973,
        ///                      "productId": 10741,
        ///                      "tcfCreationDate": "2017-08-30 19:22:52",
        ///                      "status": "LOANAPPROVAL",
        ///                      "amount": 1785000,
        ///                      "projectName": "SPLS Griha Aawas Yojna Phase 2",
        ///                      "projectAddress": "",
        ///                      "bhk": "2 BHK",
        ///                      "clientId": 37721,
        ///                      "clientName": "Dharamveer",
        ///                      "clientContact": "9631949873",
        ///                      "clientEmail": "Dharmveer.prasad@airtel.com"
        ///                  }
        ///              ]
        ///          }
        ///      }
        ///     
        /// </remarks>
        /// <returns>List of TCFs/MCFs</returns>
        [HttpPost]
        [Route("GetTCFMCFByChannelPartner")]
        public IActionResult GetTCFMCFByChannelPartner([FromBody] GetTCFMCFByChannelPartner req)
        {
            try
            {
                DABCApiRSVP da = new DABCApiRSVP();
                DEBCApiRSVP de = new DEBCApiRSVP()
                {
                    CallValue = DEBCApiRSVPCallValues.GetTCFMCFByChannelPartner,
                    CPID = req.CpId,
                    CurrentUser = currentUser,
                    Type = req.Type
                };

                var data = da.GetList<DEBCApiRSVPDBResponse>(de);

                object response;
                if (req.Type == "MCF")
                {
                    response = new
                    {
                        type = req.Type,
                        records = data.Select(row => new
                        {
                            cpId = row.CPID,
                            mcfId = row.MCFID,
                            mcfDate = row.MCFDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            status = row.Status,
                            loanType = row.LoanType,
                            loanAmount = row.LoanAmount,
                            sanctionedAmount = row.SanctionedAmount,
                            disbursementAmount = row.DisbursementAmount,
                            bankName = row.BankName,
                            clientId = row.ClientID,
                            clientName = row.ClientName,
                            clientContact = row.ClientContact,
                            clientEmail = row.ClientEmail
                        })
                    };
                }
                else if (req.Type == "TCF")
                {
                    response = new
                    {
                        type = req.Type,
                        records = data.Select(row => new
                        {
                            cpId = row.CPID,
                            tcfId = row.TCFID,
                            productId = row.ProductID,
                            tcfCreationDate = row.TCFCreationDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            status = row.Status,
                            amount = row.Amount,
                            projectName = row.ProjectName,
                            projectAddress = row.ProjectAddress,
                            bhk = row.BHKName,
                            clientId = row.ClientID,
                            clientName = row.ClientName,
                            clientContact = row.ClientContact,
                            clientEmail = row.ClientEmail
                        })
                    };
                }
                else
                {
                    throw new ApplicationException("Invalid type");
                }

                return ApiHelper.CreateSuccessResponse(this, response );
            }

            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}