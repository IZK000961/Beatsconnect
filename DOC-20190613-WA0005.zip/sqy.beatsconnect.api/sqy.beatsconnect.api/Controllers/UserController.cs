﻿using AutoMapper.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Controllers
{
    [Route("api/[controller]")]
    [BeatsAuthorize]
    [Produces("application/json")]
    public class UserController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly ILogger _logger;
        public UserController(IHostingEnvironment hostingEnvironment, ILogger<UserController> logger)
        {
            _hostingEnvironment = hostingEnvironment;
            _logger = logger;
        }


        /// <summary>
        /// Gets profile summary of a user
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /Register
        ///     
        ///     {
        ///     	"Name": "Pankaj Sharma",
        ///     	"CountryCode": "+91",
        ///     	"PhoneNumber": "9582714494",
        ///     	"Email": "pankaj073@gmail.com",
        ///     	"OrganizationName": "Square Yards",
        ///     	"City": "Delhi"
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     POST /Register
        ///     
        ///     {
        ///         "status": 1,
        ///         "message": "Successfully Registered, please check your email address for login details.",
        ///         "data": {
        ///             "registered": true
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>Get profile summary</returns>
        [AllowAnonymous]
        [HttpPost]
        [Route("Register")]
        public IActionResult Register([FromBody] RegisterRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var password = GenericHelper.GenerateRandomString(8);
                    var encryptedPassword = Cryptography.Encrypt(password);
                    var da = new DABCApiUser();
                    var de = new DEBCApiUser()
                    {
                        CallValue = DEBCApiUserCallValues.RegisterUser,
                        Email = req.Email,
                        PhoneNumber = req.PhoneNumber,
                        CountryCode = Int32.Parse(req.CountryCode.Replace("+", "")),
                        City = req.City,
                        Name = req.Name,
                        OrganizationName = req.OrganizationName,
                        Password = encryptedPassword
                    };

                    var data = da.GetLists(de);
                    
                    if(data.Count > 0)
                    {
                        /* send email */
                        var template = AppSettingsConf.EMailTemplatePath(MailDetails.SignUp);
                        var templatePath = _hostingEnvironment.ContentRootPath + template.TemplateUrl;
                        
                        string mailBody = string.Empty;
                        using (StreamReader reader = new StreamReader(templatePath))
                        {
                            mailBody = reader.ReadToEnd();
                        }
                        var row = data;
                        
                        mailBody = mailBody
                            .Replace("{Username}", data[0][0].Username)
                            .Replace("{Password}", password);

                        var mailTo = data[0][0].ToMail;
                        var mailCc = data[0][0].CcMail;
                        var mailBcc = data[0][0].BccMail;
                        var mailSubject = template.Subject;

                        SendMail.f_sendMailCommon(mailTo, mailCc, mailBcc, "", mailBody, mailSubject, MailType.AWS, EmailFrom.NoReply, null);
                    }
                    var response = new
                    {
                        Registered = true
                    };
                    return ApiHelper.CreateSuccessResponse(this, response, "Successfully Registered, please check your email address for login details.");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Debugging User/Register: Exception" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }


        /// <summary>
        /// Gets profile summary of a user
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /ForgotPassword
        ///     
        ///     {
        ///     	"Email": "pankaj073@gmail.com"
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     POST /ForgotPassword
        ///     
        ///     {
        ///         "status": 1,
        ///         "message": "Login information sent, please check your email address for login details.",
        ///         "data": {
        ///             "passwordSent": true
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>Get profile summary</returns>
        [AllowAnonymous]
        [HttpPost]
        [Route("ForgotPassword")]
        public IActionResult ForgotPassword([FromBody] ForgotPasswordRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var password = GenericHelper.GenerateRandomString(8);
                    var encryptedPassword = Cryptography.Encrypt(password);
                    var da = new DABCApiUser();
                    var de = new DEBCApiUser()
                    {
                        CallValue = DEBCApiUserCallValues.SetPassword,
                        Email = req.Email,
                        Password = encryptedPassword
                    };

                    var data = da.GetLists(de);

                    if (data.Count > 0)
                    {
                        /* send email */
                        var template = AppSettingsConf.EMailTemplatePath(MailDetails.LoginInformation);
                        var templatePath = _hostingEnvironment.ContentRootPath + template.TemplateUrl;

                        string mailBody = string.Empty;
                        using (StreamReader reader = new StreamReader(templatePath))
                        {
                            mailBody = reader.ReadToEnd();
                        }
                        var row = data;

                        mailBody = mailBody
                            .Replace("{Username}", data[0][0].Username)
                            .Replace("{Password}", password);

                        var mailTo = data[0][0].ToMail;
                        var mailCc = data[0][0].CcMail;
                        var mailBcc = data[0][0].BccMail;
                        var mailSubject = template.Subject;

                        SendMail.f_sendMailCommon(mailTo, mailCc, mailBcc, "", mailBody, mailSubject, MailType.AWS, EmailFrom.NoReply, null);
                    }
                    var response = new
                    {
                        PasswordSent = true
                    };
                    return ApiHelper.CreateSuccessResponse(this, response, "Login information sent, please check your email address for login details.");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Debugging User/ForgotPassword: Exception" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}
