﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using sqy.beatsconnect.api.DTO;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using System.Globalization;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class MCFController : Controller
    {

        /// <summary>
        /// Gets a list of MCF Filter Details
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        ///		
        /// Sample Response:
        /// 
        ///     POST /GetMCFListFilters
        ///		{
        ///		    "status": 1,
        ///		    "message": "",
        ///		    "data": {
        ///		        "dateRange": [
        ///		            {
        ///		                "rangeType": "MTD",
        ///		                "startDate": "2018-01-07T00:00:00",
        ///		                "endDate": "2018-01-17T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "QTD",
        ///		                "startDate": "2018-01-07T00:00:00",
        ///		                "endDate": "2018-01-17T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "YTD",
        ///		                "startDate": "2018-01-07T00:00:00",
        ///		                "endDate": "2018-01-17T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "Last Month",
        ///		                "startDate": "2017-12-07T00:00:00",
        ///		                "endDate": "2018-01-06T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "Last Quarter",
        ///		                "startDate": "2017-10-07T00:00:00",
        ///		                "endDate": "2018-01-06T00:00:00"
        ///		            },
        ///		            {
        ///		                "rangeType": "Last Year",
        ///		                "startDate": "2017-01-07T00:00:00",
        ///		                "endDate": "2018-01-06T00:00:00"
        ///		            }
        ///		        ],
        ///		        "mcfStatus": [
        ///		            "DRAFT",
        ///		            "SUBMITTED",
        ///		            "LOGGEDIN",
        ///		            "REVISED",
        ///		            "RESUBMIT",
        ///		            "DISBURSEDCONFIRMED",
        ///		            "DISBURSEDHOLD",
        ///		            "CANCELLED",
        ///		            "COLLECTED",
        ///		            "SANCTIONED",
        ///		            "DISBURSED",
        ///		            "REJECTED",
        ///		            "COUNTED",
        ///		            "CRMAPPROVED",
        ///		        ]
        ///		    }
        ///		}
        ///     
        /// </remarks>
        /// <returns>List of TCF Filter</returns>
        [HttpGet, Route("GetMCFListFilters")]
        public IActionResult GetMCFListFilters()
        {
            var currentUser = Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiMCF da = new DABCApiMCF();
                    //DEBCApiMCF de = new DEBCApiMCF()
                    //{
                    //    CurrentUser=currentUser,
                    //    FromDate = DateTime.ParseExact(req.FromDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                    //    ToDate = DateTime.ParseExact(req.ToDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                    //    MCFStatus = req.MCFStatus,
                    //    IncludeTeam = req.IncludeTeam,
                    //    IsShareHolder = req.IsShareHolder,
                    //    //offset = req.pageNo,
                    //    PrefixText = req.PrefixText,
                    //};
                    var response = new GetMCFFilterResponseDTO();
                    #region GetDateRange
                    response.dateRange = da.GetDateRange<DateRangeResponses>();
                    #endregion

                    #region GetTCFStatus
                    //var tcfst= TCFReportStatus.
                    List<string> MCFStatus = new List<string>();
                    MCFStatus.Add("DRAFT");
                    MCFStatus.Add("SUBMITTED");
                    MCFStatus.Add("LOGGEDIN");
                    MCFStatus.Add("REVISED");
                    MCFStatus.Add("RESUBMIT");
                    MCFStatus.Add("DISBURSEDCONFIRMED");
                    MCFStatus.Add("DISBURSEDHOLD");
                    MCFStatus.Add("CANCELLED");
                    MCFStatus.Add("COLLECTED");
                    MCFStatus.Add("SANCTIONED");
                    MCFStatus.Add("DISBURSED");
                    MCFStatus.Add("REJECTED");

                    MCFStatus.Add("COUNTED");
                    MCFStatus.Add("CRMAPPROVED");
                    //TCFStatus.Insert(0, new GetTCFStatusResponse { StatusId = "-1", StatusName = "All" });
                    response.mcfStatus = MCFStatus;
                    #endregion
                    return ApiHelper.CreateSuccessResponse(this, response);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Gets a list of MCF
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///		{
        ///			"fromDate":"2013-09-01",
        ///			"toDate":"2018-01-25",
        ///			"mcfStatus":"DRAFT",
        ///			"includeTeam":false,
        ///		}
        ///		
        /// Sample Response:
        /// 
        ///		{
        ///		    "status": 1,
        ///		    "message": "",
        ///		    "data": [
        ///		{
        ///		            "mcfId": 26319,
        ///		            "mcfRefrenceId": "MMCF-20170914-0003",
        ///		            "mcfStatus": "DRAFT",
        ///		            "clientName": "Aditya Birla Housing Finance Ltd.",
        ///		            "loanAmount": "10,000,000",
        ///		            "loanType": "Business Loan",
        ///		            "sanctionedAmount": "",
        ///		            "submittedOn": "",
        ///		            "submittedBy": "Hitesh Singla",
        ///		            "nr": "300,000.00",
        ///		            "shareHolder": "Tanuj Shori",
        ///		            "pnLName": "Square Global",
        ///		            "sharePercentage": "100"
        ///		        },
        ///		        {
        ///		            "mcfId": 26311,
        ///		            "mcfRefrenceId": "MMCF-20170914-0001",
        ///		            "mcfStatus": "DRAFT",
        ///		            "clientName": null,
        ///		            "loanAmount": "",
        ///		            "loanType": "Business Loan",
        ///		            "sanctionedAmount": "",
        ///		            "submittedOn": "",
        ///		            "submittedBy": "Hitesh Singla",
        ///		            "nr": "0.00",
        ///		            "shareHolder": "",
        ///		            "pnLName": "",
        ///		            "sharePercentage": ""
        ///		        }
        ///		    ]
        ///		}
        ///     
        /// </remarks>
        /// <returns>List of MCF</returns>
        [HttpPost,Route("GetMCFList")]
        public IActionResult GetMCFList([FromBody] GetMCFRequestDTO req)
        {
            var currentUser = Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiMCF da = new DABCApiMCF();
                    DEBCApiMCF de = new DEBCApiMCF()
                    {
                        CurrentUser = currentUser,
                        FromDate = DateTime.ParseExact(req.FromDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                        ToDate = DateTime.ParseExact(req.ToDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                        MCFStatus = req.MCFStatus,
                        IncludeTeam = req.IncludeTeam,
                        //IsShareHolder = req.IsShareHolder,
                        //offset = req.pageNo,
                        PrefixText = req.PrefixText,
                    };
                    var response = da.GetMCFList<MCFDetailsResponseDTO>(de); //new GetMCFFilterResponseDTO();
                    return ApiHelper.CreateSuccessResponse(this, response);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
                
            }
            
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
        }
}