﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class NotificationController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly ILogger _logger;

        public NotificationController(IHostingEnvironment hostingEnvironment,
            ILogger<LeadController> logger)
        {
            _hostingEnvironment = hostingEnvironment;
            _logger = logger;
        }

        private int currentUser
        {
            get
            {
                return Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            }
        }

        /// <summary>
        /// Get Notifications
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "pageNo": 1
        ///     }
        ///     
        /// Sample Response:
        /// 
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": {
        ///             "maxNoOfPages": 1,
        ///             "currentPage": 1,
        ///             "notifications": [
        ///                 {
        ///                     "notificationID": 17,
        ///                     "sentBy": 921,
        ///                     "sentByName": "Arijeet Ganguli",
        ///                     "sentOn": "2017-09-20T21:19:51",
        ///                     "title": "test",
        ///                     "description": "test",
        ///                     "isRead": true
        ///                 },
        ///                 {
        ///                     "notificationID": 21,
        ///                     "sentBy": 921,
        ///                     "sentByName": "Arijeet Ganguli",
        ///                     "sentOn": "2017-09-20T21:30:34",
        ///                     "title": "test",
        ///                     "description": "test",
        ///                     "isRead": true
        ///                 }
        ///             ]
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>List of Notifications</returns>
        [HttpPost]
        [Route("GetNotifications")]
        public IActionResult GetNotifications([FromBody]GetNotificationsRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var da = new DABCApiNotification();
                    var de = new DEBCApiNotification()
                    {
                        CallValue = DEBCApiNotificationCallValues.GetNotifications,
                        CurrentUser = currentUser,
                        PageNo = req.PageNo
                    };

                    var data = da.Execute(de);
                    
                    var notificationsData = data[0].Select(d => new GetNotificationsResponseDTO()
                    {
                        NotificationID = d.NotificationID,
                        SentBy = d.SentBy,
                        SentByName = d.SentByName,
                        SentOn = d.SentOn,
                        Title = d.Title,
                        IsRead = d.IsRead == 1,
                        Description = d.Description
                    });

                    var maxNoOfPages = data[1][0].MaxNoOfPages;
                    var response = new
                    {
                        MaxNoOfPages = maxNoOfPages,
                        CurrentPage = req.PageNo,
                        Notifications = notificationsData,
                    };

                    return ApiHelper.CreateSuccessResponse(this, response);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Get Location By Type
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "notificationID": 49
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     {
        ///         "status": 1,
        ///         "message": "Read Successfully",
        ///         "data": {}
        ///     }
        ///     
        /// </remarks>
        /// <returns>Mark notification as read</returns>
        [HttpPost]
        [Route("ReadNotification")]
        public IActionResult ReadNotification([FromBody]ReadNotificationRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var da = new DABCApiNotification();
                    var de = new DEBCApiNotification()
                    {
                        CallValue = DEBCApiNotificationCallValues.ReadNotification,
                        CurrentUser = currentUser,
                        NotificationID = req.NotificationID
                    };

                    var data = da.Execute(de);
                    if (data[0].Count > 0)
                    {
                        var notificationsData = data[0].Select(d => new GetNotificationsResponseDTO()
                        {
                            NotificationID = d.NotificationID,
                            SentBy = d.SentBy,
                            SentByName = d.SentByName,
                            SentOn = d.SentOn,
                            Title = d.Title,
                            IsRead = d.IsRead == 1,
                            Description = d.Description
                        });

                        var response = new
                        {
                            Notifications = notificationsData,
                        };

                        return ApiHelper.CreateSuccessResponse(this, response, "Read Successfully", 1);
                    }
                    else
                    {
                        return ApiHelper.CreateSuccessResponse(this, "No Record Found");
                    }
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}
