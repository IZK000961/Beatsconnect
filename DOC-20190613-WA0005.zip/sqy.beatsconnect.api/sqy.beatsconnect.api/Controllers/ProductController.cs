﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using sqy.beatsconnect.api.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.Helper;
using sqy.beatsconnect.api.Helpers;
using Microsoft.Extensions.Caching.Memory;
using sqy.beatsconnect.api.Middleware;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly ILogger _logger;
        private readonly IMemoryCache _memoryCache;
        public ProductController(IHostingEnvironment hostingEnvironment, ILogger<LeadController> logger, IMemoryCache memoryCache)
        {

            _hostingEnvironment = hostingEnvironment;
            _logger = logger;
            _memoryCache = memoryCache;
        }

        private int currentUser
        {
            get
            {
                return Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            }
        }

        /// <summary>
        /// Gets a list of products
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /GetProducts
        ///     {
        ///         "prefixText": "pankaj",
        ///         "limit": 10,
        ///         "mktCollateral": false
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     POST /GetProducts
        ///     {
        ///         "status": 1,
        ///         "message": "List of products",
        ///         "data": {
        ///             "products": [
        ///                 {
        ///                     "productID": 11801,
        ///                     "displayName": "Paradigm Realty - Paradigm El Signora",
        ///                     "mktCollateral": false,
        ///                     "projectId": 1234
        ///                 },
        ///                 {
        ///                     "productID": 11243,
        ///                     "displayName": "Damac properties - Damac  Paramount Villas"
        ///                     "mktCollateral": false,
        ///                     "projectId": 1234
        ///                 },
        ///                 {
        ///                     "productID": 10995,
        ///                     "displayName": "Paranjape Schemes - Paranjape Trident Towers"
        ///                     "mktCollateral": false,
        ///                     "projectId": 1235
        ///                 },
        ///                 {
        ///                     "productID": -1,
        ///                     "displayName": "Other"
        ///                     "mktCollateral": false,
        ///                     "projectId": 1236
        ///                 }
        ///             ]
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>List of Leads</returns>
        [HttpPost]
        [Route("GetProducts")]
        public IActionResult GetProducts([FromBody] GetProductsRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var cacheHelper = new CacheHelper(_memoryCache);
                    var selectedProducts =
                    (
                        from s in cacheHelper.CachedProducts
                        let searchScore = SearchStringScore(s.DisplayName.ToLower(), req.PrefixText.ToLower())
                        where searchScore > 0
                        where req.MktCollateral ? s.MktCollateral : true
                        orderby s.ProductId descending
                        orderby searchScore descending
                        select s
                    ).Take(req.Limit).ToList();

                    if (!req.MktCollateral)
                    {
                        selectedProducts.Add(new GetProductsProductDTO()
                        {
                            ProductId = -1,
                            DisplayName = "Other",
                            MktCollateral = false,
                            ProjectId = 0
                        });
                    }
                    var response = new
                    {
                        Products = selectedProducts
                    };
                    return ApiHelper.CreateSuccessResponse(this, response, "List of products", 1);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        private static int SearchStringScore(string search, string keyword)
        {
            var searchSplits = search.Split();
            var keywordsSplit = keyword.Split();

            var count = 0;
            foreach (var key in keywordsSplit)
            {
                foreach(var split in searchSplits)
                {
                    if (split.Contains(key))
                    {
                        count += 1;
                    }
                }
                /*
                if (searchSplits.Contains(key))
                    count += 1;
                */
            }
            return count;
        }
    }
}
