﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Microsoft.IdentityModel.Tokens;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace sqy.beatsconnect.api.Controllers
{
    [Authorize, BeatsAuthorize]
    [Produces("application/json")]
    [Route("api/LogOut")]
    public class LogOutController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        public LogOutController(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }
        private int currentUser
        {
            get
            {
                return Convert.ToInt32(HttpContext.Items["CurrentUserID"]);
            }
        }
        /// <summary>
        /// LogOut
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// 
        /// Sample response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "Logout Successfully",
        ///      }
        ///      
        /// </remarks>
        /// <returns>LogOut</returns>
        
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Get()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ApiHelper.ValidateModelState(ModelState);
                    StringValues authorization = "";
                    HttpContext.Request.Headers.TryGetValue("authorization", out authorization);
                    var token = authorization.ToString().Replace("Bearer ", "");
                    DABCApiLogin daLogin = new DABCApiLogin();
                    DEBCApiLogin deLogin = new DEBCApiLogin()
                    {
                        CallValue = DEBCApiLoginCallValues.ValidateToken,
                        Token = token
                    };

                    var validToken = daLogin.ValidateToken(deLogin);
                    if (validToken.UserId != 0)
                    {

                        DABCApiLogin da = new DABCApiLogin();
                        DEBCApiLogin de = new DEBCApiLogin()
                        {
                            CallValue = DEBCApiLoginCallValues.LogOutUser,
                            UserID = validToken.UserId,
                            LoginType = validToken.LoginType
                        };

                        var userInfo = da.LogOut(de);
                        if (userInfo == 0)
                        {
                            throw new ApplicationException("Invalid username or password");
                        }
                        else
                            return ApiHelper.UpdateSuccessResponse(this, "Logout Successfully");
                    }
                    else
                        return ApiHelper.UpdateSuccessResponse(this, "Logout Successfully");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}