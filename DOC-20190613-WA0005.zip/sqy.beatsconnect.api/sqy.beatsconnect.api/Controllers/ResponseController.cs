﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using sqy.beatsconnect.api.Models;
using sqy.beatsconnect.DataAccess;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.Helper;
using System.Globalization;
using System.Net;
using sqy.beatsconnect.api.Helpers;
using System.Data;

namespace sqy.beatsconnect.api.Controllers
{
    [BeatsAuthorize]
    [Produces("application/json")]
    [Route("api/Response")]
    public class ResponseController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly ILogger _logger;
        HttpClient client = new HttpClient();
        public ResponseController(IHostingEnvironment hostingEnvironment, ILogger<LeadController> logger)
        {

            _hostingEnvironment = hostingEnvironment;
            _logger = logger;
        }
        

        private ValidUserData currentUserData
        {
            get
            {
                return (ValidUserData)HttpContext.Items["CurrentUserData"];
            }
        }


        /// <summary>
        /// Saves call details
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// <remarks>
        /// ActivityType: 
        ///     1: Call
        ///     2: Meeting
        ///     
        /// DispositionType:
        ///     Lead: 1
        ///     RSVP: 2
        ///     Not_Interested: 3
        ///     Not_Connected: 4
        ///     LeadCumRSVP: 6
        ///     Broker: 7
        /// 
        /// Sample request:
        /// 
        ///     {
        ///         "EmpCode": "SDC0685",
        ///         "callDuration": 27,
        ///         "countryCode": "91",
        ///         "phoneNumber": "+919958112939",
        ///         "ringDuration": 15,
        ///         "project": "Test",
        ///         "customerName": "Manish Kumar",
        ///         "dispositionStatus": "LeadCumRSVP",
        ///         "calledAt": "2018-10-25 15:15:01",
        ///         "comments":"Test",
        ///         "eventDetailId":"1",
        ///         "email":"mkumar9@fmail.com",
        ///         "city":"New Delhi",
        ///         "callType":"Incoming",
        ///         "nextActivityText": "F2F",
        ///         "nextInteractionDate": "2018-10-30 15:15:01",
        ///         "activityType": 1,
        ///         "otpRequestId": 0
        ///         "latitude":123453563.92,
        ///         "longitude":673677828.90
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "Call Details Saved Successfully",
        ///          "data": {
        ///              "responseId": 1
        ///          }
        ///      }
        ///     
        /// </remarks>
        /// <returns>List of call details</returns>
        [HttpPost]
        [Route("SaveResponseCallDetails")]
        [AllowAnonymous]
        
        public async Task<IActionResult> SaveResponseCallDetails([FromBody] SaveColdCallDetailsRequestDTO req)
        {
            try
            {
                // int Ccode = GetCountrycode(req.CountryCode);
                ApiHelper.ValidateModelState(ModelState);
                StringValues authorization = "";
                HttpContext.Request.Headers.TryGetValue("authorization", out authorization);
                var token = authorization.ToString().Replace("Bearer ", "");
                DABCApiLogin daLogin = new DABCApiLogin();
                DEBCApiLogin deLogin = new DEBCApiLogin()
                {
                    CallValue = DEBCApiLoginCallValues.ValidateToken,
                    Token = token
                };

                var  validToken = daLogin.ValidateToken(deLogin);

                var calledBy = req.CalledBy;
                if (validToken.UserId != 0)
                {
                    calledBy = validToken.UserId;
                }
                
                DABCApiResponse da = new DABCApiResponse();
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.SaveResponse,
                    ResponseId = req.callActivityId,
                    EmployeeID = req.empCode,
                    PhoneNumber = req.PhoneNumber,
                    CountryCode = GetCountryCode(req.CountryCode),
                    CallDuration = req.CallDuration,
                    RingDuration = req.RingDuration,
                    DispositionStatus = Enumeration.GetAll<DEDespositionType>().Where(x => x.Value == req.DispositionStatus.ToString().Replace(' ', '_')).SingleOrDefault().Key,
                    CustomerName = req.CustomerName,
                    Project = req.Project,
                    Comments = req.Comments,
                    EventDetailId = req.EventDetailId,
                    Email = req.Email,
                    City = req.City,
                    CallType = req.CallType,
                    NextActivityText = req.NextActivityText,
                    ActivityType = req.ActivityType,
                    OTPRequestId = req.OtpRequestId,
                    Latitude = req.Latitude,
                    Longitude = req.Longitude
                };

                if (String.IsNullOrEmpty(req.NextInteractionDate))
                    de.NextInteractionDate = DateTime.Now.AddDays(1);
                else
                    de.NextInteractionDate = DateTime.ParseExact(req.NextInteractionDate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                int statusCode = 1;
                string message = "Response Details Saved Successfully";

                var responseId = 0;
                if(req.ActivityType == 1)
                {
                //responseId = await da.SaveCallDetailsAsync(de);
                responseId = da.SaveCallDetails(de);
                }
                
                if((req.DispositionStatus == "RSVP" || req.DispositionStatus == "LeadCumRSVP") 
                    && req.EventDetailId != 0)
                {
                    try
                    {
                        CreateRSVP(de);
                    }
                    catch (Exception ex)
                    {
                        statusCode = 3;
                        message = ex.Message;
                    }
                }
                if ((req.DispositionStatus == "Lead" || req.DispositionStatus == "LeadCumRSVP"))
                {
                    try
                    {
                     CreateLead(de);
                    }
                    catch (Exception ex)
                    {
                        statusCode = 3;
                        message = ex.Message;
                    }
                }
                if (req.DispositionStatus == "Broker")
                {
                    try
                    {
                        CreateBroker(de);
                    }
                    catch (Exception ex)
                    {
                        statusCode = 3;
                        message = ex.Message;
                    }
                }
               
                /*
                if (ResponseId == 0)
                    throw new ApplicationException("Unable to fetch ResponseId");
                */
                return  Ok(new
                {
                    Status = statusCode,
                    Message = message,
                    Data = new
                    {
                        callActivityId = responseId,
                    }
                });
                
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
            
        }

        /// <summary>
        /// Get Event List details
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///      {
        ///          "status": 1,
        ///          "message": "Call Details Saved Successfully",
        ///          "data": {
        ///              "eventlist": [
        ///              {
        ///                 "eventDetailId": 858,
        ///                 "eventName": "Alphathum Event - Noida - (23 Sep 2017 - 24 Sep 2017)"
        ///              }
        ///              {
        ///                 "eventDetailId": 906,
        ///                 "eventName": "Damac Event - Dubai - (13 Oct 2017 - 14 Oct 2017)"
        ///              }
        ///            ]
        ///          }
        ///      }
        ///     
        /// </remarks>
        /// <returns>List of Events</returns>
        [HttpGet]
        [Route("EventList")]
        public IActionResult EventList()
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.EventList,
                };
                var data = da.GetEventList(de);
                var response = new
                {
                    Eventlist = data
                };

                return ApiHelper.CreateSuccessResponse(this, response, response.Eventlist.Count > 0 ? "" : "No record(s) found", response.Eventlist.Count > 0 ? 1 : 1);
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        private void CreateRSVP(DEBCApiResponse de)
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                de.CallValue = DEBCApiResponseCallValues.CreateRSVP;
                /*
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.CreateRSVP,
                    ResponseId = req.callActivityId,
                    EmployeeID = req.empCode,
                    PhoneNumber = req.PhoneNumber,
                    CountryCode = GetCountrycode(req.CountryCode),
                    CallDuration = req.CallDuration,
                    RingDuration = req.RingDuration,
                    DispositionStatus = Enumeration.GetAll<DEDespositionType>().Where(x => x.Value == req.DispositionStatus.ToString().Replace(' ', '_')).SingleOrDefault().Key,
                    CustomerName = req.CustomerName,
                    Project = req.Project,
                    Comments = req.Comments,
                    EventDetailId = req.EventDetailId,
                    Email = req.Email,
                    City = req.City
                };
                */
                var data = da.CreateRSVP(de);
                var response = new
                {
                    RsvpSms = data.Select(s => new
                    {
                        s.CountryCode,
                        s.PhoneNumber,
                        s.SmsText,
                        s.SendSms,
                        s.ResponseId
                    }).FirstOrDefault()
                };
                /*** Send SMS on RSVP created ***/
                try
                {
                    if (response.RsvpSms.SendSms)
                    {
                        SMSHelper helper = new SMSHelper(_logger);
                        helper.SendSMS(Convert.ToString(de.CountryCode), response.RsvpSms.PhoneNumber, response.RsvpSms.SmsText,response.RsvpSms.ResponseId);
                    }
                    else
                    {
                        _logger.LogInformation("Debugging SMSText ResponseId: " + response.RsvpSms.ResponseId + " - " + response.RsvpSms.SmsText + " SMS SendSMS is false");
                    }
                    _logger.LogInformation("Debugging SMSText: " + response.RsvpSms.SmsText + " SMS Sent");

                }
                catch (Exception ex)
                {

                    _logger.LogInformation("Debugging SMSUrl: " + response.RsvpSms.SmsText + " Exception" + ex.Message);

                }

            }

            catch (Exception ex)
            {
                throw;
            }
        }
        private void CreateLead(DEBCApiResponse de)
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                de.CallValue = DEBCApiResponseCallValues.CreateLead;
                da.CreateLead(de);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void CreateBroker(DEBCApiResponse de)
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                de.CallValue = DEBCApiResponseCallValues.CreateBroker;
                da.CreateLead(de);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// Get Campaigns List
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///		
        /// Sample Response:
        /// 
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": {
        ///             "campaigns": [
        ///                 {
        ///                     "campaignDate": "1435",
        ///                     "displayDate": "Apne Ghar Diwali Event",
        ///                     "campaignType": "RSVP",
        ///                     "campaignName": "GIC - 09-Aug-2018",
        ///                     "numbersCount": 1,
        ///                     "callEnabled": true,
        ///                     "whatsAppEnabled": true,
        ///                     "whatsAppText": "Test SMS Message"
        ///                 },
        ///                 {
        ///                     "campaignDate": "2018-08-09",
        ///                     "displayDate": "09-Aug-2018",
        ///                     "campaignType": "GIC",
        ///                     "campaignName": "GIC - 09-Aug-2018",
        ///                     "numbersCount": 1,
        ///                     "callEnabled": true,
        ///                     "whatsAppEnabled": false,
        ///                     "whatsAppText": ""
        ///                 },
        ///                 {
        ///                     "campaignDate": "2018-08-08",
        ///                     "displayDate": "08-Aug-2018",
        ///                     "campaignType": "GIC",
        ///                     "campaignName": "GIC - 08-Aug-2018",
        ///                     "numbersCount": 5,
        ///                     "callEnabled": true,
        ///                     "whatsAppEnabled": false,
        ///                     "whatsAppText": ""
        ///                 }
        ///             ]
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>List of Campaigns</returns>
        [HttpGet]
        [Route("GetCampaigns")]
        public IActionResult GetCampaigns()
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.GetCampaigns,
                    CurrentUser = currentUserData.UserId
                };
                var data = da.GetList<BCApiResponseDBResponse>(de);

                var response = new
                {
                    campaigns = data.Select(cg => new
                    {
                        cg.CampaignDate,
                        cg.DisplayDate,
                        cg.CampaignType,
                        cg.CampaignName,
                        cg.NumbersCount,
                        cg.CallEnabled,
                        cg.WhatsAppEnabled,
                        WhatsAppText = WebUtility.UrlDecode(cg.WhatsAppText)
                    }).ToList()
                };
                return ApiHelper.CreateSuccessResponse(this, response, response.campaigns.Count > 0 ? "" : "No record(s) found", response.campaigns.Count > 0 ? 1 : 1);
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Get list of numbers for campaign
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "CampaignType": "GIC",
        ///         "CampaignDate": "2018-08-09"
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": {
        ///             "numbers": [
        ///                 {
        ///                     "responseId": 1,
        ///                     "phoneNumber": "+919582714494",
        ///                     "customerName": "Pankaj Sharma",
        ///                     "countryCode": "+91",
        ///                     "helpText": "23:00:00"
        ///                     "WhatappSent":1
        ///                 }
        ///             ]
        ///         }
        ///     }
        ///     
        /// </remarks>
        /// <returns>List of Events</returns>
        [HttpPost]
        [Route("GetNumbersForCampaign")]
        public IActionResult GetNumbersForCampaign([FromBody] GetNumbersForCampaignRequestDTO req)
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.GetNumbersForCampaign,
                    CampaignType = req.CampaignType,
                    CampaignDate = req.CampaignDate,
                    CurrentUser = currentUserData.UserId
                };
                var data = da.GetList<BCApiResponseDBResponse>(de);

                var response = new
                {
                    numbers = data.Select(cg => new
                    {
                        cg.ResponseId,
                        cg.PhoneNumber,
                        cg.CustomerName,
                        cg.CountryCode,
                        cg.HelpText,
                        cg.IsWhatsappSent
                    }).ToList()
                };
                return ApiHelper.CreateSuccessResponse(this, response, response.numbers.Count > 0 ? "" : "No record(s) found", response.numbers.Count > 0 ? 1 : 1);
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }


        private int GetCountryCode(string countryCode)
        {
            switch (countryCode)
            {
                case "IN":
                    return 91;
                case "US":
                    return 1;
                case "UK":
                    return 44;
                case "SG":
                    return 65;
                case "AE":
                    return 971;
                case "MY":
                    return 60;
                case "NZ":
                    return 64;
                case "ES":
                    return 34;
                case "TH":
                    return 66;
                case "AU":
                    return 61;
                case "HK":
                    return 852;
                case "OM":
                    return 968;
                case "QA":
                    return 974;
                case "SA":
                    return 966;
                case "KW":
                    return 965;
                case "BH":
                    return 973;
                default:
                    return Convert.ToInt32(countryCode);
            };
        }

        /// <summary>
        /// Checks if number is DND
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "countryCode": "+91",
        ///         "phoneNumber": "+919582714494",
        ///         "sendOtp": false
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": true
        ///     }
        ///     
        /// </remarks>
        /// <returns>true/false</returns>
        [HttpPost]
        [Route("DNDCheck")]
        public IActionResult DNDCheck([FromBody] DNDCheckRequestDTO req)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiResponse da = new DABCApiResponse();
                    DEBCApiResponse de = new DEBCApiResponse()
                    {
                        CallValue = DEBCApiResponseCallValues.DNDCheck,
                        PhoneNumber = req.PhoneNumber,
                        CountryCode = Convert.ToInt32(req.CountryCode.Replace("+", "")),
                        CurrentUser = 1
                    };
                    var data = da.GetList<BCApiResponseDBResponse>(de);


                    
                    if (req.SendOtp)
                    {
                        var message = data[0].IsDND ? "DND Number" : "OTP Sent Successfully";

                        var requestId = 0;
                        if (!data[0].IsDND )
                        {
                            requestId = sendOTP(currentUserData.UserId, req.PhoneNumber, req.CountryCode, 0);
                        }

                        var response = new
                        {
                            IsDND = data[0].IsDND,
                            RequestId = requestId
                        };
                        return ApiHelper.CreateSuccessResponse(this, response, message);
                    }
                    else
                    {
                        var message = data[0].IsDND ? "DND Number" : "";
                        var response = data[0].IsDND;
                        return ApiHelper.CreateSuccessResponse(this, response, message);
                    }
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Get if number is DND
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "phoneNumber": "+919582714494",
        ///         "countryCode":"91",
        ///         "SendOtp":"true"
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///     {
        ///         "status": 1,
        ///         "message": "",
        ///         "data": true
        ///     }
        ///     
        /// </remarks>
        /// <returns>true/false</returns>
        [HttpGet]
        [Route("DNDCheck/{PhoneNumber}/{CountryCode}/{SendOtp}")]
        public IActionResult DNDCheck(string phoneNumber, string countryCode, bool SendOtp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    DABCApiResponse da = new DABCApiResponse();
                    DEBCApiResponse de = new DEBCApiResponse()
                    {
                        CallValue = DEBCApiResponseCallValues.DNDCheck,
                        PhoneNumber = phoneNumber,
                        CountryCode = Convert.ToInt32(countryCode.Replace("+", "")),
                        CurrentUser = 1
                    };
                    var data = da.GetList<BCApiResponseDBResponse>(de);



                    if (SendOtp)
                    {
                        var message = data[0].IsDND ? "DND Number" : "OTP Sent Successfully";

                        var requestId = 0;
                        if (!data[0].IsDND)
                        {
                            requestId = sendOTP(currentUserData.UserId, phoneNumber, countryCode, 0);
                        }

                        var response = new
                        {
                            IsDND = data[0].IsDND,
                            RequestId = requestId
                        };
                        return ApiHelper.CreateSuccessResponse(this, response, message);
                    }
                    else
                    {
                        var message = data[0].IsDND ? "DND Number" : "";
                        var response = new
                        {
                            IsDND = data[0].IsDND,
                            RequestId = 0
                        };
                        //var response = data[0].IsDND;
                        return ApiHelper.CreateSuccessResponse(this, response, message);
                    }
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
            //try
            //{
            //    if (ModelState.IsValid)
            //    {
            //        DABCApiResponse da = new DABCApiResponse();
            //        DEBCApiResponse de = new DEBCApiResponse()
            //        {
            //            CallValue = DEBCApiResponseCallValues.GetDNDNumber,
            //            PhoneNumber = phonenumber,
            //            CurrentUser = 1
            //        };
            //        var data = da.GetList<BCApiResponseDBResponse>(de);
            //        var response = new
            //        {
            //            IsDND = data[0].IsDND,
            //        };
            //        return ApiHelper.CreateSuccessResponse(this, response);

            //    }
            //    else
            //    {
            //        var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
            //        throw new ApplicationException(error);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    return ApiHelper.CreateErrorResponse(this, ex.Message);
            //}
        }

        /// <summary>
        /// Get Cold Calling Info
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///    {
        ///        "status": 1,
        ///        "message": "Fetched Data",
        ///        "data": {
        ///            "eventList": [
        ///                {
        ///                    "eventDetailId": 1318,
        ///                    "eventName": "International Property Expo - Sydney - (15 Jul 2018 - 30 Oct 2018)"
        ///                }
        ///            ],
        ///            "activityList": [
        ///                {
        ///                    "activityId": 0,
        ///                    "activityName": "F2F"
        ///                },
        ///                {
        ///                    "activityId": 0,
        ///                    "activityName": "Calls"
        ///                },
        ///                {
        ///                    "activityId": 0,
        ///                    "activityName": "Site Visit"
        ///                },
        ///                {
        ///                    "activityId": 0,
        ///                    "activityName": "Closure Meeting"
        ///                }
        ///            ]
        ///        }
        ///    }
        ///     
        /// </remarks>
        /// <returns>Cold Calling Lead Info</returns>
        [HttpGet]
        [Route("GetCCLeadInfo")]
        public IActionResult GetCCLeadInfo()
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.GetCCLeadInfo,
                    CurrentUser = currentUserData.UserId
                };
                var data = da.GetLists(de);
                if (data.Count < 2)
                    throw new ApplicationException("Unable to fetch data");
                // get events list
                var eventList = data[0].Select(d => new
                {
                    d.EventDetailId,
                    d.EventName
                });
                // get activity list
                var activityList = data[1].Select(d => new
                {
                    d.ActivityId,
                    d.ActivityName
                });

                var response = new
                {
                    EventList = eventList,
                    ActivityList = activityList
                };

                return ApiHelper.CreateSuccessResponse(this, response, "Fetched Data");
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }


        private int sendOTP(int currentUser, string phoneNumber, string countryCode, int requestId)
        {
            DABCApiOTP da = new DABCApiOTP("beatscrm");
            DEBCApiOTP de = new DEBCApiOTP()
            {
                CallValue = DEBCApiOTPCallValues.GenerateOTPRequest,
                CurrentUser = currentUser,
                PhoneNumber = phoneNumber,
                CountryCode = countryCode,
                RequestId = requestId
            };
            var data = da.GetList<DEBCApiOTPDBResponse>(de);

            var sendOTPSMS = data[0].SendOTPSMS;

            if (data.Count > 0)
            {
                var data1 = data[0];
                if (sendOTPSMS)
                {
                    SMSHelper helper = new SMSHelper(_logger);
                    helper.SendMeetingOTPSMS(data1.RequestId, data1.CountryCode, data1.PhoneNumber, Convert.ToString(data1.HappyOTP), Convert.ToString(data1.UnhappyOTP));
                }
                else
                {
                    _logger.LogInformation("Debugging OTP RequestId: " + data1.RequestId + " SMS SendOTPSMS is false");
                }
                _logger.LogInformation("Debugging OTP RequestId: " + data1.RequestId + " SMS Sent");

                return data1.RequestId;
            }
            return 0;
        }
        /// <summary>
        /// Send Otp  
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///    
        ///         {
        ///             "RequestId": 0,
        ///             "CurrentUser": 760,
        ///             "CountryCode": "",
        ///             "PhoneNumber": ""   
        ///         }
        ///		
        /// Sample Response:
        /// 
        ///         {
        ///             "status": 1,
        ///             "message": "Feedback Code Sent successfully.",
        ///             "data": {
        ///                 "requestId": 1234
        ///             }
        ///         }
        ///     
        /// </remarks>
        /// <returns>Send Otp</returns>
        [HttpPost]
        [Route("SendOtp")]
        [AllowAnonymous]
        public IActionResult SendOtp([FromBody] SendOTPRequestDTO req)
        {
            try
            {
                ApiHelper.ValidateModelState(ModelState);
                StringValues authorization = "";
                HttpContext.Request.Headers.TryGetValue("authorization", out authorization);
                var token = authorization.ToString().Replace("Bearer ", "");
                DABCApiLogin daLogin = new DABCApiLogin();
                DEBCApiLogin deLogin = new DEBCApiLogin()
                {
                    CallValue = DEBCApiLoginCallValues.ValidateToken,
                    Token = token
                };

                var validToken = daLogin.ValidateToken(deLogin);
                var calledBy = req.CurrentUser;
                if (validToken.UserId != 0)
                {
                    calledBy = validToken.UserId;
                }

                if (ModelState.IsValid)
                {
                    var requestId = sendOTP(calledBy, req.PhoneNumber, req.CountryCode, req.RequestId);

                    if (requestId != 0)
                    { 
                        var response =  new {
                            RequestId = requestId
                        };
                        return ApiHelper.CreateSuccessResponse(this, response, "Feedback Code sms / mail sent successfully.");
                    }
                    else
                    {
                        return ApiHelper.CreateSuccessResponse(this, "Failed to send OTP");
                    }
                }
                else
                {
                    var modelError = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0];
                    var error = modelError.ErrorMessage == "" ? modelError.Exception.Message : modelError.ErrorMessage;
                    return ApiHelper.CreateErrorResponse(this, error);
                }
            }

            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Verify OTP
        /// </summary>
        /// <param name="req"></param>
        /// <param name="authorization"></param>
        /// /// <remarks>
        /// Sample request:
        /// 
        ///    
        ///     {
        ///         "requestId": 8844060,
        ///         "CurrentUser": 760,
        ///         "OTP": 5555
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///         {
        ///             "status": 1,
        ///             "message": "Feedback Code Matched Succedfully",
        ///             "data": {
        ///                 "requestId": 8844060
        ///             }
        ///         }
        ///     
        /// </remarks>
        /// <returns>Verify Otp</returns>
        [HttpPost]
        [Route("VerifyOTP")]
        [AllowAnonymous]
        public IActionResult VerifyOTP([FromBody] VerifyOTPRequestDTO req)
        {
            try
            {
                ApiHelper.ValidateModelState(ModelState);
                StringValues authorization = "";
                HttpContext.Request.Headers.TryGetValue("authorization", out authorization);
                var token = authorization.ToString().Replace("Bearer ", "");
                DABCApiLogin daLogin = new DABCApiLogin("beatscrm");
                DEBCApiLogin deLogin = new DEBCApiLogin()
                {
                    CallValue = DEBCApiLoginCallValues.ValidateToken,
                    Token = token
                };

                var validToken = daLogin.ValidateToken(deLogin);
                var calledBy = req.CurrentUser;
                if (validToken.UserId != 0)
                {
                    calledBy = validToken.UserId;
                }
                if (ModelState.IsValid)
                {
                    DABCApiOTP da = new DABCApiOTP();
                    DEBCApiOTP de = new DEBCApiOTP()
                    {

                        CallValue = DEBCApiOTPCallValues.VerifyOTPRequest,
                        CurrentUser = calledBy,
                        RequestId = req.RequestId,
                        OTP = req.OTP
                    };
                    var data = da.GetList<DEBCApiOTPDBResponse>(de);
                    var response = new
                    {
                        RequestId = req.RequestId
                    };
                    return ApiHelper.CreateSuccessResponse(this, response, "Feedback Code Matched Succedfully", 1);
                }
                else
                {
                    var modelError = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0];
                    var error = modelError.ErrorMessage == "" ? modelError.Exception.Message : modelError.ErrorMessage;

                    return ApiHelper.CreateErrorResponse(this, error);
                }
            }

            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        /// <summary>
        /// Update WhatAppNumber
        /// </summary>
        /// <param name="req"></param>
        /// <param name="Authorization"></param>
        /// <remarks>
        /// Sample request:
        /// 
        ///    
        ///     {
        ///         "ResponseId": 19239594,
        ///     }
        ///		
        /// Sample Response:
        /// 
        ///         {
        ///             "status": 1,
        ///             "message": "Successfully Updated",
        ///             "data": {
        ///                 "whatsappSent": true
        ///             }
        ///         }
        ///     
        /// </remarks>
        /// <returns></returns>
        [HttpPost]
        [Route("WhatsappSent")]
        public IActionResult WhatsappSent([FromBody] ResponseDTO req)
        {
            try
            {
                DABCApiResponse da = new DABCApiResponse();
                DEBCApiResponse de = new DEBCApiResponse()
                {
                    CallValue = DEBCApiResponseCallValues.UpdateWhatsappSent,
                    ResponseId = req.ResponseId,
                    CurrentUser = currentUserData.UserId
                };
                var data = da.GetList<BCApiResponseDBResponse>(de);
                var response = new
                {
                    whatsappSent=true
                };
                return ApiHelper.CreateSuccessResponse(this, response, "successfully Updated.");
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }

        }
    }
}