﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace sqy.beatsconnect.Helper
{
    public class MailConfigKeys
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string SMTP { get; set; }
        public string SMTPPort { get; set; }
    }
    public enum MailType
    {
        AWS
    }
    public enum SMSType
    {
        SMS
    }
    public enum NotificationType
    {
        Notification
    }
    public enum ReadNotificationType
    {
        ReadNotifications
    }
    public enum EmailFrom
    {
        HR,
        CRM,
        NoReply
    }
    public enum MailDetails
    {
        ShareLead,
        ReassignLead,
        LeadReturnVerification,
        OTP,
        SignUp,
        LoginInformation,
        OTPPWA,
        UnhappyMailToSup
    }

    public enum CacheServer
    {
        BEATSREDIS
    }

    //public enum CacheServers {
    //    BeatsRedis
    //}

    public class EmailKeys
    {
        public int Testing { get; set; }
        public string TestMailTo { get; set; }
    }
    public class SMSConfigKeys
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string vkey { get; set; }
        public string DomesticUrl { get; set; }
        public string GlobalUrl { get; set; }
        public string Apikey { get; set; }
        public string GCCUrl { get; set; }
    }
    public class SMSKeys
    {
        public int Testing { get; set; }
        public string TestMobileNo { get; set; }
        public string DomesticSMS { get; set; }
        public string GlobalHappysms { get; set; }
        public string GlobalUnHappysms { get; set; }
        public string GCCMsg { get; set; }
        public string OTPMsgForPWAUrl { get; set; }
    }
    public class EmailMeta
    {
        public string FromAccount { get; set; }
        public string Address { get; set; }
        public string DisplayName { get; set; }
        public string MailBCC { get; set; }
    }
    public class EmailTemplate
    {
        public string Subject { get; set; }
        public string TemplateUrl { get; set; }
    }
  
    public class CacheKeys
    {
        public string Server { get; set; }
        public string Port { get; set; }
        public string Password { get; set; }
        public string UserName { get; set; }
        public int RedisSyncTimeout { get; set; }
        public int RedisConnectionTimeout { get; set; }
        public int IsCachingEnabled { get; set; }
    }

    public class NotificationConfigKeys
    {
        public string Message { get; set; }
        public string Title { get; set; }
        public string NVWebPushApiUrl { get; set; }
     
    }
    public class APISettings
    {
        public string ApiUrl { get; set; }
        public string ApiKey { get; set; }
    }
    public class ApiKeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }
     }

    public class URLLIST
    {
        public List<CacheUrl> Urls { get; set; }
    }

    public class CacheUrl
    {
        public string UrlEndpoint { get; set; }
        public int ttl { get; set; } = 30;
        public int enabled { get; set; } = 1;
        public string response_contenType { get; set; } = "application/json charset=utf-8";
        public int userSpecificKeyEnabled { get; set; } = 1;
    }
    public class AWSKeys
    {
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }

        public bool TestMode { get; set; }
        public string AWSPath_Testing { get; set; }

        public string AWSPath { get; set; }
        public string AWSPath_EmployeeProfilePic { get; set; }
    }

    public class BeatsApiKeys
    {
        public string api_url { get; set; }
        public string api_key { get; set; }
    }

    public static class AppSettingsConf
    {
        public static IConfiguration Configuration { get; set; }
        
        public static string GetConnectionString(string name)
        {
            return Configuration.GetConnectionString(name);
        }

        public static MailConfigKeys GetMailSettings(MailType mailType)
        {
            MailConfigKeys keys = new MailConfigKeys();
            var section = Configuration.GetSection("MailConfigKeys").GetSection(mailType.ToString());

            keys.UserName = section["Username"];
            keys.Password = section["Password"];
            keys.SMTP = section["SMTP"];
            keys.SMTPPort = section["SMTPPort"];

            return keys;
        }

        public static EmailMeta EMailMetaSettings(EmailFrom mailType)
        {
            EmailMeta keys = new EmailMeta();
            var section = Configuration.GetSection("MailMeta").GetSection(mailType.ToString());

            keys.Address = section["Address"];
            keys.DisplayName = section["DisplayName"];
            keys.FromAccount = section["FromAccount"];
            keys.MailBCC = section["MailBCC"];

            return keys;
        }

        public static EmailKeys EMailKeySettings()
        {
            EmailKeys keys = new EmailKeys();
            var section = Configuration.GetSection("EmailKeys");

            keys.Testing = Convert.ToInt32(section["Testing"]);
            keys.TestMailTo = section["TestMailTo"];

            return keys;
        }

        public static EmailTemplate EMailTemplatePath(MailDetails mailDetails)
        {
            EmailTemplate key = new EmailTemplate();

            if (Configuration.GetSection("MailDetails").GetSection(mailDetails.ToString()) == null)
                throw new ApplicationException("MailDetails not found in config" + mailDetails);
            var section = Configuration.GetSection("MailDetails").GetSection(mailDetails.ToString());
            key.Subject = section["Subject"];
            key.TemplateUrl = section["TemplateUrl"];
            return key;
        }

        public static SMSConfigKeys SendSMSSettings(SMSType smsType)
        {
            SMSConfigKeys keys = new SMSConfigKeys();
            var section = Configuration.GetSection("SMSConfigKeys").GetSection(smsType.ToString());

            keys.UserName = section["Username"];
            keys.Password = section["Password"];
            keys.vkey = section["verification_key"];
            keys.DomesticUrl = section["DomesticUrl"];
            keys.GlobalUrl = section["Globalurl"];
            keys.Apikey = section["Apikey"];
            keys.GCCUrl = section["GCCUrl"];
            return keys;
        }
        public static SMSKeys SMSKeySettings()
        {
            SMSKeys keys = new SMSKeys();
            var section = Configuration.GetSection("SMSKeys");

            keys.Testing = Convert.ToInt32(section["Testing"]);
            keys.TestMobileNo = section["TestMobileNo"];
            keys.DomesticSMS = section["DomesticMsg"];
            keys.GlobalHappysms = section["GlobalHappyOTPTemplate"];
            keys.GlobalUnHappysms = section["GlobalUnHappyOTPTemplate"];
            keys.GCCMsg = section["GCCMsg"];
            keys.OTPMsgForPWAUrl = section["OTPMsgForPWAUrl"];
            
            return keys;
        }
     
        public static CacheKeys CacheSetting(CacheServer cacheServer)
        {
            CacheKeys keys = new CacheKeys();
           
            var section = Configuration.GetSection("CacheKeys").GetSection(cacheServer.ToString());

            keys.Server = section["server"];
            keys.Port = section["port"];
            keys.Password = section["password"];
            keys.RedisSyncTimeout = Convert.ToInt32(section["redisSyncTimeout"]);
            keys.RedisConnectionTimeout = Convert.ToInt32(section["redisConnectionTimeout"]);

            keys.IsCachingEnabled = Convert.ToInt32(section["cachingEnabled"]);

           
            return keys;
        }

        public static List<CacheUrl> CacheUrlList()
        {
            //string val = Configuration.GetValue<string>("TestApi");
            URLLIST uRLLIST = new URLLIST();
            Configuration.GetSection("URL_LIST").Bind(uRLLIST);

            return uRLLIST.Urls;
        }

       
        public static AWSKeys GetAWSKeys()
        {
            var section = Configuration.GetSection("AWSKeys");

            AWSKeys keys = new AWSKeys()
            {
                AccessKey = section.GetSectionValue("AccessKey"),
                SecretKey = section.GetSectionValue("SecretKey"),
                AWSPath = section.GetSectionValue("AWSPath"),
                TestMode = section.GetSectionValue("TestMode") == "1",
                AWSPath_Testing = section.GetSectionValue("AWSPath_Testing"),
                AWSPath_EmployeeProfilePic = section.GetSectionValue("AWSPath_EmployeeProfilePic")
            };
            return keys;
        }


        public static string GetSectionValue(this IConfigurationSection configurationSection, string key)
        {
            if(configurationSection.GetSection(key) == null)
                throw new ApplicationException("$key key does not exist");
            return configurationSection[key];
        }
        public static string GetSectionValue(this IConfiguration configuration, string key)
        {
            if (configuration.GetSection(key) == null)
                throw new ApplicationException("$key key does not exist");
            return configuration[key];
        }
        public static IConfigurationSection GetSectionConfiguration(this IConfiguration configuration, string key)
        {
            if (configuration.GetSection(key) == null)
                throw new ApplicationException("$key key does not exist");
            return configuration.GetSection(key);
        }

        public static bool Testing
        { 
            get
            {
                return Configuration.GetSectionValue(nameof(Testing)) == "1";
            }
        }
        public static NotificationConfigKeys SendNotificationSettings(NotificationType notiType)
        {
            NotificationConfigKeys keys = new NotificationConfigKeys();
            var section = Configuration.GetSection("NotificationConfigKeys").GetSection(notiType.ToString());

            keys.Message = section["Message"];
            keys.Title = section["Title"];
            keys.NVWebPushApiUrl = section["NVWebPushApiUrl"];
            return keys;
        }
        public static APISettings ReadNotificationSettings(ReadNotificationType notiType)
        {
            APISettings keys = new APISettings();
            List<ApiKeyValue> obj = new List<ApiKeyValue>();
            //Dictionary<string, string> dic = new Dictionary<string, string>();
            var section = Configuration.GetSection("APISettings").GetSection(notiType.ToString());
            keys.ApiUrl = section["ApiUrl"];
            Configuration.GetSection("APISettings").GetSection(notiType.ToString()).GetSection("Headers").Bind(obj);
            keys.ApiKey = obj.FirstOrDefault().Value;
            return keys;
        }
       
        public static BeatsApiKeys BeatsApiKeys()        {            BeatsApiKeys objkey = new BeatsApiKeys();            var section = Configuration.GetSection("BeatsApiKeys");            objkey.api_url = section["api_url"];            objkey.api_key = section["api_key"];            return objkey;        }
    }

}
