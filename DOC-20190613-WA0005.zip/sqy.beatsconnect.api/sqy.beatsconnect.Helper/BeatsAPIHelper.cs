﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Text;

namespace sqy.beatsconnect.Helper
{
    public class BeatsAPIHelper
    {
        static string apiUrl = string.Empty;
        static string apikey = string.Empty;
        public static string ReadNotification(int notificationId, string apiAccessToken)
        {
            var path = AppSettingsConf.ReadNotificationSettings(ReadNotificationType.ReadNotifications);
            apiUrl = path.ApiUrl;
            apikey = path.ApiKey;
            ReadNotificationDTO data = new ReadNotificationDTO
            {
                notificationId = notificationId,
                ApiAccessCode = apiAccessToken
            };
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("api_key", apikey);
            string postData = JsonConvert.SerializeObject(data);
            var content = new StringContent(postData, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(apiUrl, content).Result;
            var result = response.Content.ReadAsStringAsync().Result;
            var obj = JObject.Parse(result);
            var msg = Convert.ToString(JObject.Parse(obj.ToString())["message"]);
            var refId = (JObject.Parse(obj.ToString())["refId"]);
            if (msg == "Successful")
                return refId.ToString();
            else
                throw new ApplicationException("Failed to read notification: " + msg);
        }

        public class ReadNotificationDTO
        {
            public int notificationId { get; set; }
            public string ApiAccessCode { get; set; }
        }
    }
}
