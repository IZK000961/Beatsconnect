﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace sqy.beatsconnect.Helper
{
    public static class GenericHelper
    {
        static string apiUrl = string.Empty;
        static string apiUrlNew = string.Empty;
        public static TDestinationEntity CopyObject<TSourceEntity, TDestinationEntity>(TSourceEntity sourceObj)
        {
            var properties = typeof(TDestinationEntity).GetProperties();

            var destinationType = typeof(TDestinationEntity);
            var destinationObj = (TDestinationEntity)Activator.CreateInstance(destinationType);
            Type sourceType = sourceObj.GetType();
            // Type destinationType = destinationObj.GetType();
            foreach (var property in properties)
            {
                if (!property.CanRead)
                {
                    continue;
                }
                PropertyInfo targetProperty = destinationType.GetProperty(property.Name);
                PropertyInfo sourceProperty = sourceType.GetProperty(property.Name);
                if (targetProperty == null || sourceProperty == null)
                {
                    continue;
                }
                targetProperty.SetValue(destinationObj, sourceProperty.GetValue(sourceObj, null), null);
            }
            return destinationObj;
        }

        public static string GenerateRandomString(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            while (0 < length--)
            {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            return res.ToString();
        }
        public static string ShortName(string name)
        {

            // var name = "";
            var splits = name.Split(' ');
            if (splits[0].Length < 3)
                name = splits[splits.Length - 1];
            else
                name = splits[0];
            return name;
        }
      
        public static bool NVWebPushToApi(string title, string message, string pwaUrl, string userId)
        {
            var path = AppSettingsConf.SendNotificationSettings(NotificationType.Notification);
            apiUrl = path.NVWebPushApiUrl;
            apiUrlNew = apiUrl
                .Replace("{title}", title)
                .Replace("{message}", message)
                .Replace("{pwaUrl}", pwaUrl)
                .Replace("{userId}", userId);
            HttpClient client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(apiUrlNew).Result;
            var result = response.Content.ReadAsStringAsync().Result;
            var obj = JsonConvert.DeserializeObject<NVwebPushResponseDTO>(result);
            if (obj.Message == "success")
                return true;
            else
                throw new ApplicationException(obj.Message);
        }
    }

    public class NVwebPushResponseDTO
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }

}
