﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace sqy.beatsconnect.Helper
{
    public static class AmazonS3Helper
    {
        private const string BUCKET_NAME = "sqy";

        public static AWSKeys AWSKeys { get; set; }

        static AmazonS3Helper()
        {
            AWSKeys = AppSettingsConf.GetAWSKeys();
        }
        public static string GetFullPath(string bucketNameInS3, string fileName)
        {
            if (AWSKeys.TestMode)
            {
                bucketNameInS3 = AWSKeys.AWSPath_Testing;
            }
            return AWSKeys.AWSPath + bucketNameInS3 + fileName;
        }
        public static bool Upload(Stream fileStream, string bucketNameInS3, string fileName)
        {
            
            if (AWSKeys.TestMode)
            {
                bucketNameInS3 = AWSKeys.AWSPath_Testing;
            }

            var fileInS3 = bucketNameInS3 + fileName;
            // string S3_KEY = bucketNameInS3;
            using (var s3Client = new AmazonS3Client(AWSKeys.AccessKey, AWSKeys.SecretKey, RegionEndpoint.APSoutheast1))
            {
                // Setup request for putting an object in S3.
                PutObjectRequest Putrequest = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = fileInS3,
                    InputStream = fileStream
                };
                // Make service call and get back the response.
                Task<PutObjectResponse> response = s3Client.PutObjectAsync(Putrequest);
                var result = response.Result;
            }
            return true;
        }
    }
}
