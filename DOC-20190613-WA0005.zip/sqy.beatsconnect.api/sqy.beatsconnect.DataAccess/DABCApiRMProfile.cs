﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiRMProfile
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }

        public DABCApiRMProfile(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }

        public List<MySqlParameter> GetParametersList(DEBCApiRMProfile de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_CurrentUserId", MySqlDbType.Int32, de.CurrentUserId);
            mySqlHelper.SetParameters(paramList, "_HighestEducationId", MySqlDbType.Int32, de.HighestEducationId);
            mySqlHelper.SetParameters(paramList, "_CareerStartingDate", MySqlDbType.DateTime, de.CareerStartingDate);
            mySqlHelper.SetParameters(paramList, "_NativeCityId", MySqlDbType.Int32, de.NativeCityId);
            mySqlHelper.SetParameters(paramList, "_NativeStateId", MySqlDbType.Int32, de.NativeStateId);
            mySqlHelper.SetParameters(paramList, "_NativeCountryId", MySqlDbType.Int32, de.NativeCountryId);
            mySqlHelper.SetParameters(paramList, "_InterestIds", MySqlDbType.VarChar, de.InterestIds);
            mySqlHelper.SetParameters(paramList, "_NoOfDependents", MySqlDbType.Int32, de.NoOfDependents);
            mySqlHelper.SetParameters(paramList, "_NoOfDependentKids", MySqlDbType.Int32, de.NoOfDependentKids);
            mySqlHelper.SetParameters(paramList, "_AboutYourself", MySqlDbType.VarChar, de.AboutYourself);
            mySqlHelper.SetParameters(paramList, "_LanguageId", MySqlDbType.Int32, de.LanguageId);
            mySqlHelper.SetParameters(paramList, "_LanguageLevel", MySqlDbType.VarChar, de.LanguageLevel);
            mySqlHelper.SetParameters(paramList, "_ProfilePic", MySqlDbType.VarChar, de.ProfilePic);
            return paramList;
        }

        public List<List<BCApiRMProfileDBResponse>> GetLists(DEBCApiRMProfile de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<BCApiRMProfileDBResponse>("udsp_BCAppAPIRMProfile", paramList);
        }
    }
}
