﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiUser
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiUser(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }

        public List<MySqlParameter> GetParametersList(DEBCApiUser de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_Name", MySqlDbType.VarChar, de.Name);
            mySqlHelper.SetParameters(paramList, "_CountryCode", MySqlDbType.Int32, de.CountryCode);
            mySqlHelper.SetParameters(paramList, "_PhoneNumber", MySqlDbType.VarChar, de.PhoneNumber);
            mySqlHelper.SetParameters(paramList, "_Email", MySqlDbType.VarChar, de.Email);
            mySqlHelper.SetParameters(paramList, "_OrganizationName", MySqlDbType.Int32, de.OrganizationName);
            mySqlHelper.SetParameters(paramList, "_City", MySqlDbType.Int32, de.City);
            mySqlHelper.SetParameters(paramList, "_Password", MySqlDbType.VarChar, de.Password);

            return paramList;
        }

        public List<List<BCApiUserDBResponse>> GetLists(DEBCApiUser de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<BCApiUserDBResponse>("udsp_BCAppApiUser", paramList);
        }
    }
}
