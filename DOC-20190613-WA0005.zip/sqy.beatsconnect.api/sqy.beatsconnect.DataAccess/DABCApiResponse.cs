﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiResponse
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiResponse(string constr = "beatscrm")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }

        public List<MySqlParameter> GetParametersList(DEBCApiResponse de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_ResponseId", MySqlDbType.Int32, de.ResponseId);
            mySqlHelper.SetParameters(paramList, "_EmployeeID", MySqlDbType.Int32, de.EmployeeID);
            mySqlHelper.SetParameters(paramList, "_PhoneNumber", MySqlDbType.VarChar, de.PhoneNumber);
            mySqlHelper.SetParameters(paramList, "_CountryCode", MySqlDbType.VarChar, de.CountryCode);
            mySqlHelper.SetParameters(paramList, "_CallDuration", MySqlDbType.Int32, de.CallDuration);
            mySqlHelper.SetParameters(paramList, "_RingDuration", MySqlDbType.Int32, de.RingDuration);
            mySqlHelper.SetParameters(paramList, "_DispositionStatus", MySqlDbType.VarChar, de.DispositionStatus);
            mySqlHelper.SetParameters(paramList, "_CustomerName", MySqlDbType.Int32, de.CustomerName);
            mySqlHelper.SetParameters(paramList, "_Project", MySqlDbType.VarChar, de.Project);
            mySqlHelper.SetParameters(paramList, "_Comments", MySqlDbType.Int32, de.Comments);
            mySqlHelper.SetParameters(paramList, "_EventDetailId", MySqlDbType.Int32, de.EventDetailId);
            mySqlHelper.SetParameters(paramList, "_Email", MySqlDbType.VarChar, de.Email);
            mySqlHelper.SetParameters(paramList, "_City", MySqlDbType.VarChar, de.City);
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.VarChar, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_CampaignType", MySqlDbType.VarChar, de.CampaignType);
            mySqlHelper.SetParameters(paramList, "_CampaignDate", MySqlDbType.VarChar, de.CampaignDate);
            mySqlHelper.SetParameters(paramList, "_CallType", MySqlDbType.VarChar, de.CallType);
            mySqlHelper.SetParameters(paramList, "_NextActivityText", MySqlDbType.VarChar, de.NextActivityText);
            mySqlHelper.SetParameters(paramList, "_NextInteractionDate", MySqlDbType.DateTime, de.NextInteractionDate);
            mySqlHelper.SetParameters(paramList, "_ActivityType", MySqlDbType.Int32, de.ActivityType);
            mySqlHelper.SetParameters(paramList, "_OTPRequestId", MySqlDbType.Int32, de.OTPRequestId);
            mySqlHelper.SetParameters(paramList, "_Latitude", MySqlDbType.Decimal, de.Latitude);
            mySqlHelper.SetParameters(paramList, "_Longitude", MySqlDbType.Decimal, de.Longitude);
            return paramList;
        }
        public List<TEntity> GetList<TEntity>(DEBCApiResponse de)
        {
            List<MySqlParameter> paramList =  GetParametersList(de);
            return mySqlHelper.GetList<TEntity>("udsp_BCAppAPIResponse", paramList);
        }

        public async Task<List<TEntity>> GetListAsync<TEntity>(DEBCApiResponse de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return await mySqlHelper.GetListAsync<TEntity>("udsp_BCAppAPIResponse", paramList);
        }

        public List<List<BCApiResponseDBResponse>> GetLists(DEBCApiResponse de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<BCApiResponseDBResponse>("udsp_BCAppAPIResponse", paramList);
        }
        public int SaveCallDetails(DEBCApiResponse de)
        {
            var data = GetList<DEBCApiResponseDBResponse>(de);
            if (data.Count > 0)
                return data[0].ResponseId;
            return 0;
        }
        public async Task<int> SaveCallDetailsAsync(DEBCApiResponse de)
        {
            var data =await GetListAsync<DEBCApiResponseDBResponse>(de);
            if (data.Count > 0)
                return await Task.Run(() =>
                {
                    return data[0].ResponseId;
                });
            return 0;
        }

        public List<DEBCApiResponseDBResponse> CreateRSVP(DEBCApiResponse de)
        {
            var data = GetList<DEBCApiResponseDBResponse>(de);
            return data;
            /*
            if (data.Count > 0)
                return 1;
            return 0;
            */
        }

        public int CreateLead(DEBCApiResponse de)
        {
            var data =  GetList<DEBCApiResponseDBResponse>(de);
            if (data.Count > 0)
                return 1;
            return 0;
        }
        public List<DEBCApiEventListDBResponse> GetEventList(DEBCApiResponse de)
        {
            return  GetList<DEBCApiEventListDBResponse>(de);
        }
    }
}
