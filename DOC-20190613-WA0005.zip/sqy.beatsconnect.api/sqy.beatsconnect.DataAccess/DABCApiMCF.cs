﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiMCF
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiMCF(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }
        public List<MySqlParameter> GetList(DEBCApiMCF de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);          
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_Status", MySqlDbType.VarChar, de.Status);           
            mySqlHelper.SetParameters(paramList, "_IsAdmin", MySqlDbType.Int32, de.IsAdmin);
            mySqlHelper.SetParameters(paramList, "_PnLID", MySqlDbType.Int32, de.PnLID);            
            mySqlHelper.SetParameters(paramList, "_EmpID", MySqlDbType.Int32, de.EmpID);           
            mySqlHelper.SetParameters(paramList, "_DateType", MySqlDbType.Int32, de.DateType);
            mySqlHelper.SetParameters(paramList, "_FromDate", MySqlDbType.DateTime, de.FromDate);
            mySqlHelper.SetParameters(paramList, "_ToDate", MySqlDbType.DateTime, de.ToDate);
            mySqlHelper.SetParameters(paramList, "_PrefixText", MySqlDbType.VarChar, de.PrefixText);           
            mySqlHelper.SetParameters(paramList, "_PnLHeadID", MySqlDbType.Int32, de.PnLHeadID);
            mySqlHelper.SetParameters(paramList, "_MCFIDs", MySqlDbType.Int32, de.MCFIDs);
            return paramList;
        }
        public List<MySqlParameter> GetMCFParameters(DEBCApiMCF de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_Status", MySqlDbType.String, de.MCFStatus.ToString());
            mySqlHelper.SetParameters(paramList, "_IncludeTeam", MySqlDbType.Int32, (de.IncludeTeam ? 1 : 0));
            mySqlHelper.SetParameters(paramList, "_FromDate", MySqlDbType.DateTime, de.FromDate);
            mySqlHelper.SetParameters(paramList, "_ToDate", MySqlDbType.DateTime, de.ToDate);
            return paramList;
        }
        public List<TEntity> GetDateRange<TEntity>()
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            return mySqlHelper.GetList<TEntity>("udsp_GetDateRange", paramList);

        }
        public List<TEntity> GetMCFList<TEntity>(DEBCApiMCF de)
        {
            List<MySqlParameter> paramList = GetMCFParameters(de);
            return mySqlHelper.GetList<TEntity>("udsp_MCFrpt", paramList);
        }

        public List<TEntity> GetMCFStatus<TEntity>(DEBCApiMCF de)
        {
          List<MySqlParameter> paramList = GetList(de);

            return mySqlHelper.GetList<TEntity>("udsp_BCAppAPIMCF", paramList);
        }
    }
}
