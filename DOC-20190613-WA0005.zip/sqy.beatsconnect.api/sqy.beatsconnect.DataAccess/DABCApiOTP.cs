﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiOTP
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiOTP(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }
        public List<MySqlParameter> GetParametersList(DEBCApiOTP de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_LeadActivityRecNo", MySqlDbType.Int32, de.LeadActivityRecNo);
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_OTP", MySqlDbType.Int32, de.OTP);
            mySqlHelper.SetParameters(paramList, "_RequestID", MySqlDbType.Int32, de.RequestId);
            mySqlHelper.SetParameters(paramList, "_PhoneNumber", MySqlDbType.VarChar, de.PhoneNumber);
            mySqlHelper.SetParameters(paramList, "_CountryCode", MySqlDbType.VarChar, de.CountryCode);
            return paramList;
        }
        public List<TEntity> GetList<TEntity>(DEBCApiOTP de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);

            return mySqlHelper.GetList<TEntity>("udsp_BCAppApiLeadOTP", paramList);
        }
        public List<List<TEntity>> GetLists<TEntity>(DEBCApiOTP de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<TEntity>("udsp_BCAppApiLeadOTP", paramList);
        }
    }
}
