﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiTCF
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiTCF(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }
        public List<MySqlParameter> GetParametersList(DEBCApiTCF de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_DeletedRemarks", MySqlDbType.VarChar, de.DeletedRemarks);
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_Status", MySqlDbType.VarChar, de.Status);
            mySqlHelper.SetParameters(paramList, "_Developer", MySqlDbType.VarChar, de.Developer);
            mySqlHelper.SetParameters(paramList, "_City", MySqlDbType.Int32, de.City);
            mySqlHelper.SetParameters(paramList, "_IsAdmin", MySqlDbType.Int32, de.IsAdmin);
            mySqlHelper.SetParameters(paramList, "_PnLID", MySqlDbType.Int32, de.PnLID);
            mySqlHelper.SetParameters(paramList, "_Project", MySqlDbType.VarChar, de.Project);
            mySqlHelper.SetParameters(paramList, "_SegmentID", MySqlDbType.Int32, de.SegmentID);
            mySqlHelper.SetParameters(paramList, "_EmpID", MySqlDbType.Int32, de.EmpID);
            mySqlHelper.SetParameters(paramList, "_Mobile", MySqlDbType.VarChar, de.Mobile);
            mySqlHelper.SetParameters(paramList, "_CPID", MySqlDbType.Int32, de.CPID);
            mySqlHelper.SetParameters(paramList, "_DateType", MySqlDbType.Int32, de.DateType);
            mySqlHelper.SetParameters(paramList, "_FromDate", MySqlDbType.DateTime, de.FromDate);
            mySqlHelper.SetParameters(paramList, "_ToDate", MySqlDbType.DateTime, de.ToDate);
            mySqlHelper.SetParameters(paramList, "_PrefixText", MySqlDbType.VarChar, de.PrefixText);
            mySqlHelper.SetParameters(paramList, "_limit", MySqlDbType.Int32, de.limit);
            mySqlHelper.SetParameters(paramList, "_TCFIDs", MySqlDbType.Text, de.TCFIDs);
            mySqlHelper.SetParameters(paramList, "_PnLHeadID", MySqlDbType.Int32, de.PnLHeadID);
            mySqlHelper.SetParameters(paramList, "_RFStatusID", MySqlDbType.Int32, de.RFStatusID);
            mySqlHelper.SetParameters(paramList, "_offset", MySqlDbType.VarChar, de.offset);
            mySqlHelper.SetParameters(paramList, "_Email", MySqlDbType.VarChar, de.Email);
            mySqlHelper.SetParameters(paramList, "_Key", MySqlDbType.VarChar, de.Key);
            return paramList;
            //return mySqlHelper.GetLists<TEntity>("udsp_TCF_List", paramList);
        }
        public List<MySqlParameter> GetTCFParametersList(DEBCApiTCF de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_RegionIds", MySqlDbType.String, de.PrefixText);
            mySqlHelper.SetParameters(paramList, "_Status", MySqlDbType.String, de.TCFStatus.ToString());
            mySqlHelper.SetParameters(paramList, "_IncludeTeam", MySqlDbType.Int32, (de.IncludeTeam ? 1 : 0));
            mySqlHelper.SetParameters(paramList, "_FromDate", MySqlDbType.DateTime, de.FromDate);
            mySqlHelper.SetParameters(paramList, "_ToDate", MySqlDbType.DateTime, de.ToDate);
            mySqlHelper.SetParameters(paramList, "_IsShareHolder", MySqlDbType.Int32, (de.IsShareHolder ? 1 : 0));
            mySqlHelper.SetParameters(paramList, "_ProductTypeID", MySqlDbType.Int32, (de.ProductTypeID));

            return paramList;
            //return mh.fnMySqlRetriveDs("udsp_TCFrpt", paramList);
        }
        public List<TEntity> GetDateRange<TEntity>()
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            return mySqlHelper.GetList< TEntity>("udsp_GetDateRange", paramList);

        }
        public List<List<TEntity>> GetLists<TEntity>(DEBCApiTCF de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<TEntity>("udsp_BCAppAPITCF", paramList);
        }
        public List<TEntity> GetList<TEntity>(DEBCApiTCF de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);

            return mySqlHelper.GetList<TEntity>("udsp_BCAppAPITCF", paramList);
        }
        public List<TEntity> GetTCFListDetails<TEntity>(DEBCApiTCF de)
        {
            List<MySqlParameter> paramList = GetTCFParametersList(de);

            return mySqlHelper.GetList<TEntity>("udsp_TCFrpt", paramList);
        }
        public List<List<DEBCApiTCFResponse>> GetTCFList(DEBCApiTCF de)
        {
            return GetLists<DEBCApiTCFResponse>(de);
        }
    }
}
