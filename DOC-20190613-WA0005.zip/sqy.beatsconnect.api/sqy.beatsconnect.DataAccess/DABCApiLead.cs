﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiLead
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiLead(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }

        public List<MySqlParameter> GetParametersList(DEBCApiLead de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_PageNo", MySqlDbType.Int32, de.PageNo);
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_SearchKey", MySqlDbType.VarChar, de.SearchKey);
            mySqlHelper.SetParameters(paramList, "_Developer", MySqlDbType.VarChar, de.Developer);
            mySqlHelper.SetParameters(paramList, "_AssignedTo", MySqlDbType.Int32, de.AssignedTo);
            mySqlHelper.SetParameters(paramList, "_LeadStatus", MySqlDbType.Int32, de.LeadStatus);
            mySqlHelper.SetParameters(paramList, "_PnLID", MySqlDbType.Int32, de.PnlID);
            mySqlHelper.SetParameters(paramList, "_Project", MySqlDbType.VarChar, de.Project);
            mySqlHelper.SetParameters(paramList, "_SegmentID", MySqlDbType.Int32, de.SegmentID);
            mySqlHelper.SetParameters(paramList, "_SharedWith", MySqlDbType.Int32, de.SharedTo);
            mySqlHelper.SetParameters(paramList, "_Source", MySqlDbType.VarChar, de.Source);
            mySqlHelper.SetParameters(paramList, "_CPID", MySqlDbType.Int32, de.CPID);
            mySqlHelper.SetParameters(paramList, "_DateType", MySqlDbType.Int32, de.DateType);
            mySqlHelper.SetParameters(paramList, "_FromDate", MySqlDbType.DateTime, de.FromDate);
            mySqlHelper.SetParameters(paramList, "_ToDate", MySqlDbType.DateTime, de.ToDate);
            mySqlHelper.SetParameters(paramList, "_T2oPnL", MySqlDbType.Int32, de.T2oPnL);
            mySqlHelper.SetParameters(paramList, "_LeadID", MySqlDbType.Int32, de.LeadId);
            mySqlHelper.SetParameters(paramList, "_Key", MySqlDbType.VarChar, de.Key);
            mySqlHelper.SetParameters(paramList, "_LocationType", MySqlDbType.Int32, de.LocationType);
            mySqlHelper.SetParameters(paramList, "_ParentId", MySqlDbType.Int32, de.ParentId);

            mySqlHelper.SetParameters(paramList, "_Comments", MySqlDbType.Text, de.Comments);
            mySqlHelper.SetParameters(paramList, "_CurrentActivityID", MySqlDbType.Int32, de.CurrentActivityID);
            mySqlHelper.SetParameters(paramList, "_InteractionDate", MySqlDbType.DateTime, de.InteractionDate);
            mySqlHelper.SetParameters(paramList, "_Latitude", MySqlDbType.Decimal, de.Latitude);
            mySqlHelper.SetParameters(paramList, "_LeadStatusID", MySqlDbType.Int32, de.LeadStatusID);
            mySqlHelper.SetParameters(paramList, "_Longitude", MySqlDbType.Decimal, de.Longitude);
            mySqlHelper.SetParameters(paramList, "_NextActivityID", MySqlDbType.Int32, de.NextActivityID);

            if (de.NextInteractionDate.HasValue)
                mySqlHelper.SetParameters(paramList, "_NextInteractionDate", MySqlDbType.DateTime, de.NextInteractionDate.Value);
            else
                mySqlHelper.SetParameters(paramList, "_NextInteractionDate", MySqlDbType.DateTime, DBNull.Value);

            mySqlHelper.SetParameters(paramList, "_Reason", MySqlDbType.VarChar, de.Reason);
            mySqlHelper.SetParameters(paramList, "_SubReason", MySqlDbType.VarChar, de.SubReason);
            mySqlHelper.SetParameters(paramList, "_CallActivityID", MySqlDbType.Int32, de.CallActivityID);
            mySqlHelper.SetParameters(paramList, "_BudgetID", MySqlDbType.Int32, de.BudgetID);
            mySqlHelper.SetParameters(paramList, "_BudgetDesc", MySqlDbType.VarChar, de.BudgetDesc);

            mySqlHelper.SetParameters(paramList, "_InteractionType", MySqlDbType.Int32, de.InteractionType);

            mySqlHelper.SetParameters(paramList, "_CallDuration", MySqlDbType.Int32, de.CallDuration);
            mySqlHelper.SetParameters(paramList, "_RingDuration", MySqlDbType.Int32, de.RingDuration);
            mySqlHelper.SetParameters(paramList, "_PhoneNumber", MySqlDbType.VarChar, de.PhoneNumber);
            mySqlHelper.SetParameters(paramList, "_EmpID", MySqlDbType.VarChar, de.EmpId);
            mySqlHelper.SetParameters(paramList, "_SharedComments", MySqlDbType.VarChar, de.SharedComments);
            mySqlHelper.SetParameters(paramList, "_City", MySqlDbType.VarChar, de.City);
            mySqlHelper.SetParameters(paramList, "_CalledBy", MySqlDbType.Int32, de.CalledBy);

            mySqlHelper.SetParameters(paramList, "_CompanyName", MySqlDbType.VarChar, de.CompanyName);
            mySqlHelper.SetParameters(paramList, "_Title", MySqlDbType.VarChar, de.Title);
            mySqlHelper.SetParameters(paramList, "_Salutation", MySqlDbType.VarChar, de.Salutation);
            mySqlHelper.SetParameters(paramList, "_FirstName", MySqlDbType.VarChar, de.FirstName);
            mySqlHelper.SetParameters(paramList, "_Website", MySqlDbType.VarChar, de.Website);
            mySqlHelper.SetParameters(paramList, "_Industry", MySqlDbType.VarChar, de.Industry);
            mySqlHelper.SetParameters(paramList, "_Address", MySqlDbType.VarChar, de.Address);
            mySqlHelper.SetParameters(paramList, "_ZipCode", MySqlDbType.Int32, de.Zipcode);
            mySqlHelper.SetParameters(paramList, "_CityID", MySqlDbType.Int32, de.CityId);
            mySqlHelper.SetParameters(paramList, "_StateID", MySqlDbType.Int32, de.State);
            mySqlHelper.SetParameters(paramList, "_CountryID", MySqlDbType.Int32, de.Country);
            mySqlHelper.SetParameters(paramList, "_Status", MySqlDbType.Int32, de.Status);
            mySqlHelper.SetParameters(paramList, "_UtcTimeDiff", MySqlDbType.Int32, de.UtcTimeDiff);
            mySqlHelper.SetParameters(paramList, "_HasFilters", MySqlDbType.Int32, de.HasFilters);

            mySqlHelper.SetParameters(paramList, "_LeadActivityId", MySqlDbType.Int32, de.LeadActivityId);
            mySqlHelper.SetParameters(paramList, "_ProductId", MySqlDbType.Int32, de.ProductId);
            mySqlHelper.SetParameters(paramList, "_ProductName", MySqlDbType.VarChar, de.ProductName);
            mySqlHelper.SetParameters(paramList, "_NotificationId", MySqlDbType.Int32, de.NotificationId);
            mySqlHelper.SetParameters(paramList, "_CalledTo", MySqlDbType.Int32, de.CalledTo);
            mySqlHelper.SetParameters(paramList, "_CallType", MySqlDbType.Int32, de.CallType);
            return paramList;
        }
        public List<TEntity> GetList<TEntity>(DEBCApiLead de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);

            return mySqlHelper.GetList<TEntity>("udsp_BCAppAPILead", paramList);
        }
        public List<List<TEntity>> GetLists<TEntity>(DEBCApiLead de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<TEntity>("udsp_BCAppAPILead", paramList);
        }
        public List<List<DEBCApiLeadDBResponse>> GetMyLeads(DEBCApiLead de)
        {
            return GetLists<DEBCApiLeadDBResponse>(de);
        }
        public List<GetLocationByTypeResponseDTO> GetLocationByType(DEBCApiLead de)
        {
            return GetList<GetLocationByTypeResponseDTO>(de);
        }
        public List<GetEmpSharedEmployeeResponseDTO> GetEmpForReassignment(DEBCApiLead de)
        {
            return GetList<GetEmpSharedEmployeeResponseDTO>(de);
        }
        public List<List<GetLeadActivityresponse>> GetLeadActivity(DEBCApiLead de)
        {
            return GetLists<GetLeadActivityresponse>(de);
        }
        public List<GetLeadReturnActivityResponseDTO> GetLeadReturnActivity(DEBCApiLead de)
        {
            return GetList<GetLeadReturnActivityResponseDTO>(de);
        }

        public List<List<DEGetInteractionDetailResponseDTO>> GetInteractionDetails(DEBCApiLead de)
        {
            return GetLists<DEGetInteractionDetailResponseDTO>(de);
        }

        public List<GetCommentsResponseDTO> GetLeadComments(DEBCApiLead de)
        {
            return GetList<GetCommentsResponseDTO>(de);
        }
        public int SaveCallDetails(DEBCApiLead de)
        {
            var data = GetList<DEBCApiLeadDBResponse>(de);
            if (data.Count > 0)
                return data[0].CallActivityID;
            return 0;
        }
    }
}
