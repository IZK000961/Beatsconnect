﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiLogin
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiLogin(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }

        public List<TEntity> GetList<TEntity>(DEBCApiLogin de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_Username", MySqlDbType.Int32, de.Username);
            mySqlHelper.SetParameters(paramList, "_Password", MySqlDbType.Int32, de.Password);
            mySqlHelper.SetParameters(paramList, "_Token", MySqlDbType.Int32, de.Token);
            mySqlHelper.SetParameters(paramList, "_UserID", MySqlDbType.Int32, de.UserID);
            mySqlHelper.SetParameters(paramList, "_DeviceID", MySqlDbType.VarChar, de.DeviceID);
            mySqlHelper.SetParameters(paramList, "_DeviceType", MySqlDbType.VarChar, de.DeviceType);
            mySqlHelper.SetParameters(paramList, "_LoginType", MySqlDbType.VarChar, de.LoginType);
            return mySqlHelper.GetList<TEntity>("udsp_BCAppAPILogin", paramList);
        }

        public DEBCApiLoginResponse ValidateUser(DEBCApiLogin de)
        {
            var data = GetList<DEBCApiLoginResponse>(de);
            DEBCApiLoginResponse userInfo = null;
            if (data.Count > 0)
                userInfo = data[0];
            return userInfo;
        }
        public void UpdateToken(DEBCApiLogin de)
        {
            GetList<DEBCApiLoginResponse>(de);
        }
        public  ValidUserData ValidateToken(DEBCApiLogin de)
        {
            var data =  GetList<DEBCApiLoginResponse>(de);
            var userId = 0;
            var loginType = "Employee";
            var employeeCode = "";
            if (data.Count > 0)
            { 
                userId = data[0].UserID;
                loginType = data[0].LoginType;
                employeeCode = data[0].EmployeeCode;
            }

            return  new ValidUserData()
            {
                UserId = userId,
                LoginType = loginType,
                EmployeeCode = employeeCode
            };
        }

        public int ValidateUsername(DEBCApiLogin de)
        {
            var data = GetList<DEBCApiLoginResponse>(de);
            var userId = 0;
            if (data.Count > 0)
                userId = data[0].UserID;
            return userId;
        }

        public int LogOut(DEBCApiLogin de)
        {
            try
            {
                var data = GetList<DEBCApiLogOutResponse>(de);
                return 1;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}
