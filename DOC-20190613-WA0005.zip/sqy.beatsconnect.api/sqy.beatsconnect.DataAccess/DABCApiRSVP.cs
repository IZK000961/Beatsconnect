﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{




    public class DABCApiRSVP

    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiRSVP(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }
      

        public List<MySqlParameter> GetParametersList(DEBCApiRSVP de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_CPID", MySqlDbType.Int32, de.CPID);
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_Type", MySqlDbType.VarChar, de.Type);
            return paramList;
        }
        public List<TEntity> GetList<TEntity>(DEBCApiRSVP de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);

            return mySqlHelper.GetList<TEntity>("udsp_BCAppAPIRSVP", paramList);
        }
    }
}
