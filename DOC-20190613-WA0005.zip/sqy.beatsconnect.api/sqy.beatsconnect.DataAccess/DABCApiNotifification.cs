﻿using MySql.Data.MySqlClient;
using sqy.beatsconnect.DataEntities;
using sqy.beatsconnect.DBHelper;
using sqy.beatsconnect.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataAccess
{
    public class DABCApiNotification
    {
        public BeatsMySqlHelper mySqlHelper { get; set; }
        public DABCApiNotification(string constr = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(constr);
            mySqlHelper = new BeatsMySqlHelper(connectionString);
        }

        public List<MySqlParameter> GetParametersList(DEBCApiNotification de)
        {
            List<MySqlParameter> paramList = new List<MySqlParameter>();
            mySqlHelper.SetParameters(paramList, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlHelper.SetParameters(paramList, "_CurrentUser", MySqlDbType.Int32, de.CurrentUser);
            mySqlHelper.SetParameters(paramList, "_NotificationID", MySqlDbType.Int32, de.NotificationID);
            mySqlHelper.SetParameters(paramList, "_PageNo", MySqlDbType.Int32, de.PageNo);

            return paramList;
        }

        public List<List<TEntity>> GetLists<TEntity>(DEBCApiNotification de)
        {
            List<MySqlParameter> paramList = GetParametersList(de);
            return mySqlHelper.GetLists<TEntity>("udsp_BCAppAPINotification", paramList);
        }
        public List<List<DEBCApiNotificationDBResponse>> Execute(DEBCApiNotification de)
        {
            return GetLists<DEBCApiNotificationDBResponse>(de);
        }
    }
}
