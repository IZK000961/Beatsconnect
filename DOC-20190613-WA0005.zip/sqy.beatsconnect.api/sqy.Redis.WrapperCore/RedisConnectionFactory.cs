﻿using StackExchange.Redis;
using System;
using sqy.beatsconnect.Helper;
namespace sqy.Redis.WrapperCore
{
    class RedisConnectionFactory
    {

        private static readonly Lazy<ConnectionMultiplexer> Connection;

        static RedisConnectionFactory()
        {
            CacheKeys cacheKeys = AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS);

            var configurationOptions = new ConfigurationOptions
            {
                EndPoints = {
                     cacheKeys.Server + ":" + cacheKeys.Port
                },
                Password = cacheKeys.Password,
                AbortOnConnectFail = false,
                SyncTimeout = (AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).RedisSyncTimeout == 0 ? 1000 : AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).RedisSyncTimeout),
                ConnectTimeout = (AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).RedisConnectionTimeout == 0 ? 5000 : AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).RedisConnectionTimeout),
            };

            Connection = new Lazy<ConnectionMultiplexer>(() => ConnectionMultiplexer.Connect(configurationOptions));
        }

        public static ConnectionMultiplexer RedisCacheConnection
        {
            get
            {
                return Connection.Value;
            }
        }

        public static IDatabase RedisCacheDatabase
        {
            get
            {
                return RedisCacheConnection.GetDatabase();
            }
        }
    }
}
