﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using sqy.beatsconnect.Helper;
using StackExchange.Redis;

namespace sqy.Redis.WrapperCore
{
    public class RedisCache
    {
        private IDatabase _cache;
        private static object _lock = new object();

        #region"ctor"
        public RedisCache()
        {
            _cache = RedisConnectionFactory.RedisCacheDatabase;
        }
        #endregion

        #region"String Get & Set Functions"

        public bool IsKeyExist(string key)
        {
            if (string.IsNullOrEmpty(key)) throw new ArgumentNullException("key");
            return _cache.KeyExists(key);
        }

        public T TryGet<T>(string key, int expireOn)
        {
            //Argument.CheckIfNull(ifCacheMissAction, "ifCacheMissAction");

            if (string.IsNullOrEmpty(key)) throw new ArgumentNullException("key");
            RedisValue redisValue = _cache.StringGet(key);
                   
            if (redisValue.HasValue && redisValue != "{}")
            {
                var redisVal = default(T);
                JsonExceptionWrapper(() => redisVal = JsonConvert.DeserializeObject<T>(redisValue.ToString()), redisValue, key);
                return redisVal;
            }
          
            return default(T);
        }

        public IEnumerable<T> TryGetList<T>(string key, Func<IEnumerable<T>> ifCacheMissAction, int expireOn)
        {
            //Argument.CheckIfNull(ifCacheMissAction, "ifCacheMissAction");
            if (string.IsNullOrEmpty(key)) throw new ArgumentNullException("key");

            RedisValue redisValue = _cache.StringGet(key);

            if (redisValue.HasValue && redisValue != "{}")
            {
                var list = Enumerable.Empty<T>();
                JsonExceptionWrapper(() => list = JsonConvert.DeserializeObject<IEnumerable<T>>(redisValue), redisValue, key);
                return list;
            }

            IEnumerable<T> item = ifCacheMissAction();
            SetValue(key, item, expireOn);
            return item;
        }

        public void SetValue(string key, object value, int expireOn)
        {

            if (string.IsNullOrEmpty(key)) throw new ArgumentNullException("key");
            //Argument.CheckIfNull(value, "value");

            string serializeObject = string.Empty;
            JsonExceptionWrapper(() => serializeObject = JsonConvert.SerializeObject(value), value, key);

            //Cache.StringSet(key, serializeObject, new TimeSpan(expireOn.Ticks - DateTime.UtcNow.Ticks), When.NotExists, CommandFlags.FireAndForget);
            _cache.StringSet(key, serializeObject, new TimeSpan(0, 0, expireOn), When.NotExists, CommandFlags.FireAndForget);
        }

        public void DeleteItem(string key)
        {
            if (key == null) throw new ArgumentNullException("key");
            _cache.KeyDelete(key);
        }

        public void ClearCache()
        {

            EndPoint[] endPoints = _cache.Multiplexer.GetEndPoints();
            foreach (EndPoint point in endPoints)
            {
                IServer server = _cache.Multiplexer.GetServer(point);
                server.FlushDatabase();
            }
        }

        public bool IsRedisAvailable
        {
            get
            {
                try
                {
                    return _cache.Multiplexer.IsConnected;
                }
                catch
                {
                    return false;
                }
            }
        }

        #endregion

        #region"Helper Methods"

        public static bool IsCacheEnabled()
        {
            int _cachingEnabled = AppSettingsConf.CacheSetting(CacheServer.BEATSREDIS).IsCachingEnabled;            
            return (_cachingEnabled == 1);
        }

        private static void JsonExceptionWrapper(Action action, object value, string key)
        {
            try
            {
                action.Invoke();
            }
            catch (ArgumentNullException ex)
            {
                throw new Exception(
                    $"Redis Cache: There was an issue deserializing / serializing the object {value.GetType().FullName} with the key {key}. "
                       , ex);
            }
            catch (JsonException ex)
            {
                throw new Exception($"Redis Cache: There was an issue deserializing / serializing the object {value.GetType().FullName} with the key {key}. Check inner exception for more information.", ex);
            }
        }
        public static string DataTableToJSONWithJSONNet(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);

            return JSONString;
        }
        #endregion

    }

    public class CacheParameters
    {
        public bool CacheRequired { get; set; }
        public CacheKeyPrefix Prefix { get; set; }
        public int TTL { get; set; } = 10800;
        public string AdditionalKey { get; set; }
    }

    public enum CacheKeyPrefix
    {
        Beats,
        DotCom,
        ConnectAPI
    }

}