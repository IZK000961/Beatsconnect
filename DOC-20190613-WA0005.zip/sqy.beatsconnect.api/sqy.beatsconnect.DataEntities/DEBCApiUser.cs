﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiUserCallValues
    {
        RegisterUser = 1,
        SetPassword = 2
    }
    public class DEBCApiUser
    {
        public DEBCApiUserCallValues CallValue { get; set; }
        public string Name { get; set; }
        public int CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string OrganizationName { get; set; }
        public string City { get; set; }
        public string Password { get; set; }
    }

    public class BCApiUserDBResponse
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string ToMail { get; set; }
        public string CcMail { get; set; }
        public string BccMail { get; set; }
    }
}
