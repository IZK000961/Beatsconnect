﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiLeadCallValues
    {
        GetMyLeads = 1,
        GetLeadReturnActivity = 2,
        GetLeadActivity = 3,
        GetSharedWithEmployee = 4,
        GetAssignedToEmployee = 5,
        GetAllPNL = 6,
        GetAllSource = 7,
        GetAllDeveloper = 8,
        GetAllProject = 9,
        GetFilteredTeam = 10,
        GetEmpForReassignment = 11,
        GetLocationByType = 12,
        GetMyTeam = 13,
        GetTeamForPnlId = 14,
        UpdateActivity = 15,
        GetInteractionDetails = 16,
        LeadShareToEmployee = 17,
        SaveCallDetails = 18,
        GetBudgetList = 20,
        GetReasonList = 21,
        GetActivityList = 22,
        GetClientInteraction = 23,
        UpdateLeadDetails = 24,
        UpdateLeadBasicInfo = 25,
        UpdateLeadAllowedStatus = 26,
        GetLeadActivityComments = 27,
        GetActivityProjects = 28,
        AddProjectForLeadActivity = 29,
        GetLeadInformation = 30,
        GetLeadInfoByPhoneNumber = 31,
        UpdateCallInitiated = 32,
        GetUnclaimedLeads = 33,
        UpdateUnclaimedLead = 34
    }
    public class DEBCApiLead
    {
        public DEBCApiLeadCallValues CallValue { get; set; }
        public int PageNo { get; set; }
        public int CurrentUser { get; set; }
        public string FirstName { get; set; }
        public string SearchKey { get; set; }
        public string Developer { get; set; }
        public int AssignedTo { get; set; }
        public int LeadStatus { get; set; }
        public int PnlID { get; set; }
        public string Project { get; set; }
        public int SegmentID { get; set; }
        public int SharedTo { get; set; }
        public string SharedComments { get; set; }
        public string Source { get; set; }
        public int CPID { get; set; }
        public int DateType { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int T2oPnL { get; set; }
        public int LeadId { get; set; } = 1;
        public string Key { get; set; }
        public int LocationType { get; set; } = -1;
        public int ParentId { get; set; } = -1;

        public string Comments { get; set; }
        public int CurrentActivityID { get; set; }
        public DateTime InteractionDate { get; set; }
        public double Latitude { get; set; }
        public int LeadStatusID { get; set; }
        public double Longitude { get; set; }
        public int NextActivityID { get; set; }
        public DateTime? NextInteractionDate { get; set; }
        public string Reason { get; set; }
        public string SubReason { get; set; }
        public int CallActivityID { get; set; }
        public int BudgetID { get; set; }
        public string BudgetDesc { get; set; }

        public int InteractionType { get; set; } = -1;

        public int CallDuration { get; set; }
        public int RingDuration { get; set; }
        public string PhoneNumber { get; set; }
        public int CalledBy { get; set; }
        public string EmpId { get; set; }
        public string City { get; set; }

        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Website { get; set; }
        public int CityId { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public string Address { get; set; }
        public string Zipcode { get; set; }
        public string Industry { get; set; }
        public string Salutation { get; set; }
        public string CompanyName { get; set; }
        public string Title { get; set; }
        public int UtcTimeDiff { get; set; }
        public int Status { get; set; }

        public int HasFilters { get; set; }
        public int LeadActivityId { get; set; }

        public int ProductId { get; set; }
        public string ProductName { get; set; }

        public int NotificationId { get; set; }
        public int CalledTo { get; set; }
        public string CallType { get; set; }
        public int requestTestimonialCnt { get; set; }
        public int customerTestimonialCnt { get; set; }
        public bool IsEligibleTestimonial { get; set; }
    }

    public class DEBCApiLeadDBResponse
    {
        public int LeadID { get; set; }
        public string Project { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string LeadDate { get; set; }
        public string AssignedTo { get; set; }
        public string Status { get; set; }
        public string SharedWith { get; set; }
        public string FilterInfo { get; set; }
        public string Source { get; set; }
        public string Developer { get; set; }
        public string Budget { get; set; }
        public string CountryCode { get; set; }
        public int MaxNumberOfPages { get; set; }
        public int CurrentPage { get; set; }
        public string Segment { get; set; }
        public int CallActivityID { get; set; }
        public string ClientName { get; set; }
        public string ClientNo { get; set; }
        public string ClientEmail { get; set; }
        public string ProjectName { get; set; }
        public string LeadStatusText { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public int PHEmployeeId { get; set; }
        public string PHEmployeeCode { get; set; }
        public string PHEmployeeName { get; set; }
        public string ToEmails { get; set; }
        public string CCEmails { get; set; }
        public string BCCEmails { get; set; }
        public string LeadStatus { get; set; }
        //   public string Email { get; set; }
        //  public string Segment { get; set; }
        public string FirstName { get; set; }
        public string NextInteractionDate { get; set; }
        public string NextActivity { get; set; }
        public string date { get; set; }
        public string isPlanned { get; set; }
        public int activityId { get; set; }
        public bool updateEnabled { get; set; }
        public int CalledTo { get; set; }
        public string CallType { get; set; }
    }

    public class GetLocationByTypeRequestDTO
    {
        public int LocationType { get; set; }
        public int LocationId { get; set; }
    }

    public class GetLocationByTypeResponseDTO
    {

        public int LocationId { get; set; }
        public string LocationName { get; set; } = string.Empty;
        public int ParentId { get; set; }
    }
    public class GetEmpSharedEmployeeRequestDTO
    {
        public string key { get; set; } = string.Empty;
    }
    public class GetEmpSharedEmployeeResponseDTO
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
        //  public string EmployeeCode { get; set; } = string.Empty;
    }

    public class GetTeamForPnlIdRequestDTO
    {
        public int PnlID { get; set; }
    }

    public class GetTeamForPnlIdResponseDTO
    {
        public int empId { get; set; }
        public string empName { get; set; } = string.Empty;
    }

    public class GetMyTeamRequestDTO
    {
        public string empId { get; set; }
    }
    public class GetMyTeamResponseDTO
    {
        public string EmployeeName { get; set; } = string.Empty;
        public int EmployeeId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string Level { get; set; } = string.Empty;
        public string PnlName { get; set; } = string.Empty;
        public bool LeadAllowed { get; set; }
        public bool HasTeam { get; set; }
        public bool LeadStatus { get; set; }
        public bool isLeadEditable { get; set; }

    }

    public class DEGetInteractionDetailsRequestDTO
    {
        public int InteractionType { get; set; }
        public int PageNo { get; set; }
        public DateTime date { get; set; }
        public string TimeZone { get; set; } = "+05:30";
    }


    public class DEGetInteractionDetailResponseDTO
    {
        public int LeadID { get; set; }
        public string LeadStatus { get; set; }
        public string PhoneNumber { get; set; }
        //   public string Email { get; set; }
        //  public string Segment { get; set; }
        public string FirstName { get; set; }
        public string NextInteractionDate { get; set; }
        public string NextActivity { get; set; }
        public string date { get; set; }
        public string isPlanned { get; set; }
    }




    public class DELeadShareToEmployeeResponseDTO
    {
        public int LeadID { get; set; }
        public string MailTo { get; set; }
        public string MailCc { get; set; }
        public string MailBcc { get; set; }
        public string MailSubject { get; set; }
        public string SharedByName { get; set; }
        public string SharedWithName { get; set; }
        public string SharedComments { get; set; }
        public int SendEmail { get; set; }
        public string Message { get; set; }

    }

    public class DEUpdateLeadAllowedStatusResponseDTO
    {

        public string Message { get; set; }

    }

    public class GetLeadActivityRequestDTO
    {
        public int LeadId { get; set; }
        public string TimeZone { get; set; } = "+05:30";
        public int NotificationId { get; set; } = 0;
    }
    public class GetLeadActivityresponse
    {
        public int LeadID { get; set; }
        public string LeadName { get; set; }
        public string Leaddate { get; set; }
        public DateTime LeadGenerationDate { get; set; }
        public string LeadReassignmentDate { get; set; }
        public string Project { get; set; }
        public string Source { get; set; }
        public string LeadPhoneNum { get; set; }
        public string LeadAssignedTo { get; set; }
        public string LeadEmailId { get; set; }
        public string LeadStatus { get; set; }
        public string LeadSharedWith { get; set; }
        public string Developer { get; set; }
        public string BudgetDesc { get; set; }
        public string ddlText { get; set; }
        public string City { get; set; }
        public string LeadActivity { get; set; }
        public int SegmentID { get; set; }

        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Website { get; set; }
        public string Industry { get; set; }
        public string Address { get; set; }
        public string ZipCode { get; set; }
        public int CityID { get; set; }
        public int StateID { get; set; }
        public int CountryID { get; set; }
        public string Salutation { get; set; }
        public string CompanyName { get; set; }
        public string Title { get; set; }
        public bool updateEnabled { get; set; }
        public int AssignedTo { get; set; }
        public int SharedWith { get; set; }

        public int CPID { get; set; }
        public string CPCode { get; set; }
        public string CPDisplayName { get; set; }
        public string CPMobileNo { get; set; }
        public string Segment { get; set; }
        public string LeadHash { get; set; }
        public int requestTestimonialCnt { get; set; }
        public int customerTestimonialCnt { get; set; }
        public bool IsEligibleTestimonial { get; set; }
    }
    //public class GetLeadActivityresponseDTO
    //{
    //    public GetLeadBasicDetailsResponseDTO leadDetails { get; set; }
    //    public GetLeadDetailsResponseDTO Details { get; set; }
    //}
    //public class GetLeadBasicDetailsResponseDTO
    //{
    //    //public int RecNo { get; set; }
    //    public int LeadID { get; set; }
    //    public string LeadName { get; set; }
    //    public DateTime InteractionDate { get; set; }
    //    public string Project { get; set; }
    //    public string Source { get; set; }
    //    public string LeadPhoneNum { get; set; }
    //    public string LeadAssignedTo { get; set; }
    //    public string LeadEmailId { get; set; }
    //    public string LeadStatus { get; set; }
    //    public string LeadSharedWith { get; set; }
    //}
    //public class GetLeadDetailsResponseDTO
    //{
    //    public string Developer { get; set; }
    //    public string Project { get; set; }
    //    public string Budget { get; set; }
    //    public List<GetBudgetList> BudgetList { get; set; }
    //    public string City { get; set; }
    //}
    public class GetLeadActivityResponse
    {
        public List<GetBudgetList> BudgetList { get; set; }
    }
    public class GetBudgetList
    {
        public int ddlValue { get; set; }
        public string ddlText { get; set; }
    }
    public class GetResionList
    {
        public string RefType { get; set; }
        public int RefID { get; set; }
        public string RefName { get; set; }
        public int RefParentId { get; set; }
    }
    public class GetActivityList
    {
        public string ActivityId { get; set; }
        public string ActivityName { get; set; }
        public int MaxProjects { get; set; }
        public bool ProjectsRequired { get; set; }
    }

    public class GetLeadReturnActivityResponseDTO
    {
        public int LeadID { get; set; }
        public string SageCRMID { get; set; }
        public string InterestType { get; set; }
        public string Source { get; set; } = string.Empty;
        public string SourceDetails { get; set; } = string.Empty;
        public string Developer { get; set; } = string.Empty;
        public string Project { get; set; } = string.Empty;
        public string Unit { get; set; } = string.Empty;
        public string Budget { get; set; } = string.Empty;
        public string Salutation { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string BudgetDesc { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string LeadDate { get; set; }
        public DateTime LeadGenerationDate { get; set; }
        public string LeadReassignmentDate { get; set; }
        public int SegmentID { get; set; }
        public string StatusDesc { get; set; } = string.Empty;
        public string Activity { get; set; } = string.Empty;
        public string AssignedToCode { get; set; } = string.Empty;
        public string SharedWith { get; set; } = string.Empty;
        public int AssignedTo { get; set; }
        public int SharedWithId { get; set; }
    }
    public class GetFiltersRequestDTO
    {
        public string key { get; set; } = "%%";
    }

    public class GetFiltersResponseDTO
    {
        public List<DateRangeDTO> dateRange { get; set; }
        public List<SegmentDTO> segment { get; set; }
        //public List<LeadSourceDTO> leadSource { get; set; }
        public List<LeadStatusDTO> leadStatus { get; set; }
        public List<SourceDTO> source { get; set; }
        //public List<DeveloperDTO> developer { get; set; }
        //public List<ProjectDTO> project { get; set; }
        public List<EmpListDTO> empList { get; set; }
        public List<PnlListDTO> pnlList { get; set; }
        public List<sharedToDTO> sharedTo { get; set; }

    }
    public class DateRangeDTO
    {
        public int dateRangeId { get; set; }
        public string dateRangeValue { get; set; } = string.Empty;
    }
    public class StatusListDTO
    {
        public string statusId { get; set; }
        public string statusName { get; set; } = string.Empty;
    }
    public class SegmentDTO
    {
        public int segmentId { get; set; }
        public string segmentName { get; set; } = string.Empty;
    }
    public class LeadSourceDTO
    {
        public int dateRangeId { get; set; }
        public string dateRangeValue { get; set; } = string.Empty;
    }
    public class LeadStatusDTO
    {
        public int statusId { get; set; }
        public string statusName { get; set; } = string.Empty;
    }
    public class SourceDTO
    {
        public string sourceName { get; set; } = string.Empty;
    }
    public class DeveloperDTO
    {
        public string developerName { get; set; } = string.Empty;
    }
    public class ProjectDTO
    {
        public string projectName { get; set; } = string.Empty;
    }
    public class EmpListDTO
    {
        public int empId { get; set; }
        public string empName { get; set; } = string.Empty;
    }
    public class PnlListDTO
    {
        public int pnlId { get; set; }
        public string pnlName { get; set; } = string.Empty;
    }
    public class sharedToDTO
    {
        public int empId { get; set; }
        public string empName { get; set; } = string.Empty;
    }
    public class GetCommentsResponseDTO
    {
        public string Comments { get; set; } = string.Empty;
    }


    #region client interaction


    public class ClientInteractionDTO
    {
        public string InteractionDate { get; set; }
        public string NextInteractionDate { get; set; }
        public string Comments { get; set; }
        public string StatusDesc { get; set; }
        public string NextActivity { get; set; }
        public string LastActivity { get; set; }
        public string UpdatedBy { get; set; }
        public int ActivityId { get; set; }
        public bool FeedbackStatus { get; set; }
        public bool ActivityUpdateAllowed { get; set; }
        public List<ProductDTO> Products { get; set; }
    }

    public class ProductDTO
    {
        public int ProductId { get; set; }
        public string DisplayName { get; set; }
        public string OtherStr { get; set; }
    }

    public class ActivityProjectDTO
    {
        public int ProductId { get; set; }
        public string DisplayName { get; set; }
        public string OtherStr { get; set; }
    }

    public class BCApiLeadDBResponse
    {
        public string InteractionDate { get; set; }
        public string NextInteractionDate { get; set; }
        public string Comments { get; set; }
        public string StatusDesc { get; set; }
        public string NextActivity { get; set; }
        public string LastActivity { get; set; }
        public string UpdatedBy { get; set; }
        public int ActivityId { get; set; }
        public bool FeedbackStatus { get; set; }
        public bool ActivityUpdateAllowed { get; set; }

        public int ProductId { get; set; }
        public string ProductName { get; set; }

        public string DisplayName { get; set; }
        public string OtherStr { get; set; }

        public string PhoneNumber { get; set; }
        public int CountryCode { get; set; }
        public string Email { get; set; }
        public string City { get; set; }
        public string EmployeeCode { get; set; }
        public string CustomerName { get; set; }

        public int LeadId { get; set; }
        public string ProjectName { get; set; }

        public bool HasMeeting { get; set; }
        public string MeetingVenue { get; set; }
        public DateTime MeetingTime { get; set; }
        public string LeadStatus { get; set; }
        public int ClaimedBy { get; set; }
        public string ErrorMessage { get; set; }
    }
    #endregion
}
