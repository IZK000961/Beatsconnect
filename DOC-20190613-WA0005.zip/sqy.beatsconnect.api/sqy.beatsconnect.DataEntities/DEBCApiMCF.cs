﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiMCFCallValues
    {
        GetShareHolder = 6,
        GetPL = 5,
        GetMCFStatus = 1
    }
    public class DEBCApiMCF
    {
        public DEBCApiMCFCallValues CallValue { get; set; }
        public int PageNo { get; set; }
        public int DateType { get; set; } 
        public string Status { get; set; } 
        public int PnLID { get; set; } 
        public int EmpID { get; set; } 
        public int CurrentUser { get; set; } 
        public int IsAdmin { get; set; } 
        public string MCFIDs { get; set; } 
        public int PnLHeadID { get; set; }
        public string MCFStatus { get; set; }
        private string _PrefixText { get; set; }
        public string PrefixText
        {
            get { return string.Concat("%", _PrefixText, "%"); }
            set { _PrefixText = value; }
        }
        //public MCFReportStatus MCFStatus { get; set; }
        public bool IncludeTeam { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public bool IsShareHolder { get; set; }
    }
    public enum MCFReportStatus
    {
        DRAFT, PREAPPROVAL, LOANAPPROVAL, HOLD, RESUBMIT, ALLY2BL, LOANPENDING, NOTCOUNTED, SOS,
        COUNTED, DELETED, CANCELLED, COLLECTED, CLIENTACK,
        BUSINESSALERT, SHARETRANSFER, TPL_PENDING, RESUBMIT_CRM, RESUBMIT_LOAN, RESUBMIT_OPS, CANCELLED_DATE
    }
    public class DEBCApiMCFResponse
    {
        public int MCFID { get; set; }
        public string MCFRefrenceId { get; set; }
        public string MCFStatus { get; set; }
        public string ClientName { get; set; }
        public string LoanAmount { get; set; }
        public string SanctionedAmount { get; set; }
        public string SubmittedOn { get; set; }
        public string SubmittedBy { get; set; }
        public string NR { get; set; }
        public int ShareHolder { get; set; }
        public string PnLName { get; set; }
        public string SharePercentage { get; set; }
    }
    public class DateRangeResponses
    {
        public string RangeType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
    public class GetMCFFilterResponseDTO
    {
        public List<DateRangeResponses> dateRange { get; set; }
        public List<string> mcfStatus { get; set; }

    }
}
