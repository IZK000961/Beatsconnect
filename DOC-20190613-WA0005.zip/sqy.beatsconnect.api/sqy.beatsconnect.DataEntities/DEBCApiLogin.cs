﻿using System;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiLoginCallValues
    {
        ValidateUser = 1,
        ValidateToken = 2,
        UpdateToken = 3,
        LogOutUser = 4,
        UpdateDeviceDetails = 5,
        ValidateUsername = 6
    }

    public class DEBCApiLogin
    {
        public DEBCApiLoginCallValues CallValue { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Token { get; set; }
        public int UserID { get; set; }
        public string DeviceID { get; set; }
        public string DeviceType { get; set; }
        public string LoginType { get; set; }
    }

    public class DEBCApiLoginResponse
    {
        public int UserID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeCode { get; set; }
        public string DepartmentName { get; set; }
        public string LocationName { get; set; }
        public string DesignationName { get; set; }
        public string ContactNo { get; set; }
        public string EmailIDOfficial { get; set; }
        public string ApiAccessToken { get; set; }
        public string PnlName { get; set; }
        public string PnlHeadName { get; set; }
        public string ProfilePictureUrl { get; set; }
        public string ProfilePictureFileName { get; set; }
        public string UserRoles { get; set; }
        public bool IsProfileUpdated { get; set; }
        public string LoginType { get; set; }
        public int EmployeeId { get; set; }
        public string Level { get; set; }
    }
    public class DEBCApiLogOutResponse
    {
        public int Message { get; set; }
    }

    public class ValidUserData
    {
        public int UserId { get; set; }
        public string LoginType { get; set; }
        public string EmployeeCode { get; set; }
        public string ApiAccessToken { get; set; }
    }
}
