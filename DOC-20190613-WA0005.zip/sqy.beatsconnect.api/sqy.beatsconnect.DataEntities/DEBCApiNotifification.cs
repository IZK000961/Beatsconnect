﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiNotificationCallValues
    {
        GetNotifications = 1,
        ReadNotification = 2
    }
    public class DEBCApiNotification
    {
        public DEBCApiNotificationCallValues CallValue { get; set; }
        public int CurrentUser { get; set; }
        public int NotificationID { get; set; }
        public int PageNo { get; set; }
    }

    public class ReadNotificationRequestDTO
    {
        [Required]
        public int NotificationID { get; set; }
    }

    public class DEBCApiNotificationDBResponse
    {
        public int NotificationID { get; set; }
        public int SentBy { get; set; }
        public string SentByName { get; set; }
        public DateTime SentOn { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int IsRead { get; set; }
        public int MaxNoOfPages { get; set; }
    }
    public class GetNotificationsRequestDTO
    {
        [Required]
        public int PageNo { get; set; }
    }
    public class GetNotificationsResponseDTO
    {
        public int NotificationID { get; set; }
        public int SentBy { get; set; }
        public string SentByName { get; set; }
        public DateTime SentOn { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsRead { get; set; }
    }
}
