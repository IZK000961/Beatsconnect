﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    class Class1
    {

    }
}
