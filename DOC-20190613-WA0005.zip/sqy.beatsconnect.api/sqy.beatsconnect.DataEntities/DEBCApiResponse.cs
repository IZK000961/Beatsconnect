﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiResponseCallValues
    {
        SaveResponse = 1,
        EventList = 2,
        CreateRSVP = 3,
        CreateLead = 4,
        GetCampaigns = 5,
        GetNumbersForCampaign = 6,
        DNDCheck = 7,
        GetCCLeadInfo = 8,
        CreateBroker = 9,
        UpdateWhatsappSent=10,
        GetDNDNumber=11

    }
    public enum DEDespositionType
    {
        Lead = 1,
        RSVP = 2,
        Not_Interested = 3,
        Not_Connected = 4,
        LeadCumRSVP = 6,
        Broker = 7,
        Call_Back=8,
        DND=9
       
    }
    public class DEBCApiResponse
    {
        public DEBCApiResponseCallValues CallValue { get; set; }
        public string EmployeeID { get; set; }
        public int ResponseId { get; set; }
        public int CountryCode { get; set; }

        public string PhoneNumber { get; set; }

        public int CallDuration { get; set; }

        public int RingDuration { get; set; }

        public string CalledAt { get; set; }

        public int DispositionStatus { get; set; }
        public string CustomerName { get; set; }
        public string Project { get; set; }
        public string Comments { get; set; }
        public string CallType { get; set; }
        public int EventDetailId { get; set; }
        public string Email { get; set; }
        public string City { get; set; }

        public int CurrentUser { get; set; }

        public string CampaignType { get; set; }
        public string CampaignDate { get; set; }

        public string NextActivityText { get; set; }
        public DateTime NextInteractionDate { get; set; }

        public int ActivityType { get; set; }
        public int OTPRequestId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
    public class DEBCApiResponseDBResponse
    {
        public int ResponseId { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public  string SmsText { get; set; }
        public bool SendSms { get; set;}
    }
    public class DEBCApiEventListDBResponse
    {
        public int EventDetailId { get; set; }
        public string EventName { get; set; }
    }

    public class BCApiResponseDBResponse
    {
        public int ResponseId { get; set; }
        public string CustomerName { get; set; }
        public string PhoneNumber { get; set; }
        public string CountryCode { get; set; }

        public string CampaignDate { get; set; }
        public string CampaignType { get; set; }
        public string CampaignName { get; set; }
        public int NumbersCount { get; set; }

        public string DisplayDate { get; set; }
        public bool IsDND { get; set; }

        public int EventDetailId { get; set; }
        public string EventName { get; set; }

        public int ActivityId { get; set; }
        public string ActivityName { get; set; }

        public bool CallEnabled { get; set; }
        public bool WhatsAppEnabled { get; set; }
        public string WhatsAppText { get; set; }

        public string HelpText { get; set; }
        public bool IsWhatsappSent { get; set; }
    }
}
