﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiOTPCallValues
    {
        GenrateOTP = 1,
        VerifyOTP = 2,
        GenerateOTPRequest = 3,
        VerifyOTPRequest = 4
    }
    public class DEBCApiOTP
    {
        public DEBCApiOTPCallValues CallValue { get; set; }
        public int CurrentUser { get; set; }
        public int LeadActivityRecNo { get; set; }
        public int OTP { get; set; }
        public string PhoneNumber { get; set; }
        public string CountryCode { get; set; }
        public int RequestId { get; set; }
    }
    public class DEBCApiOTPDBResponse
    {
        public int LeadID { get; set; }
        public int RecNo { get; set; }
        public int HappyOTP { get; set; }
        public int UnhappyOTP { get; set; }
        public string CustomerName { get; set; }
        public string FOSName { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string LeadDate { get; set; }
        public string MailCc { get; set; }
        public string MailBcc { get; set; }
        public bool SendOTPSMS { get; set; }
        public int RequestId { get; set; }

        public string ActivityName { get; set; }
        public string RMName { get; set; }
        public bool PWAExists { get; set; }
        public string PWAUrl { get; set; }
        public int TryCount { get; set; } = 1;
        public bool NVWebPush { get; set; }
        public string UserId { get; set; }
        public string RMShortName
        {
            get
            {
                var name = "";
                var splits = RMName.Split(' ');
                if (splits[0].Length < 3)
                    name = splits[splits.Length - 1]; 
                else
                    name = splits[0];
                return name;
            }
        }
        public int UnHappy { get; set; }
        public string SupervisorName { get; set; }
        public string LeaderName { get; set; }

    }
}
