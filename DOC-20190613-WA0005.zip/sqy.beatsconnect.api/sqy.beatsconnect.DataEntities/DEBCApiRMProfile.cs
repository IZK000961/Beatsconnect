﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiRMProfileCallValues
    {
        GetRMProfileDetails = 1,
        UpdateRMProfile = 2,
        GetLocations = 3,
        AddLanguage = 4,
        GetRMPRofileSummary = 5,
        UpdateProfilePic = 6
    }
    public class DEBCApiRMProfile
    {
        public DEBCApiRMProfileCallValues CallValue { get; set; }
        public int CurrentUserId { get; set; }
        public int HighestEducationId { get; set; }
        public DateTime CareerStartingDate { get; set; }
        public int NativeCityId { get; set; }
        public int NativeStateId { get; set; }
        public int NativeCountryId { get; set; }
        public string InterestIds { get; set; }
        public int NoOfDependents { get; set; }
        public int NoOfDependentKids { get; set; }
        public string AboutYourself { get; set; }
        public int LanguageId { get; set; }
        public string LanguageLevel { get; set; }
        public bool Selected { get; set; }
        public string ProfilePic { get; set; }
    }

    public class BCApiRMProfileDBResponse
    {
        public int EmployeeId { get; set; }
        public int Id { get; set; }
        public string DisplayName { get; set; }
        public bool Selected { get; set; }
        public string LanguageLevel { get; set; }
        public int CareerStartingMonth { get; set; }
        public int CareerStartingYear { get; set; }
        public int NativeCityId { get; set; }
        public int NativeStateId { get; set; }
        public int NativeCountryId { get; set; }
        public int NoOfDependents { get; set; }
        public int NoOfDependentKids { get; set; }
        public string AboutYourself { get; set; }
        public int ParentId { get; set; }
        public int Type { get; set; }

        public bool IsProfileUpdated { get; set; }
        public string CareerStarting { get; set; }
        public string NativeCity { get; set; }
        public string NativeState { get; set; }
        public string NativeCountry { get; set; }
        public string Interests { get; set; }
        public string LanguagesKnown { get; set; }
        public string HighestEducation { get; set; }
    }

    public class LocationVM
    {
        public int Id { get; set; }
        public string DisplayName { get; set; }
        public int ParentId { get; set; }
        public int Type { get; set; }
    }
}
