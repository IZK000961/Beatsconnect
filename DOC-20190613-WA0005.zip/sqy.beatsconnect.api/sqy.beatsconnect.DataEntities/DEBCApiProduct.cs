﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiProductCallValues
    {
        GetProducts = 1
    }

    public class DEBCApiProduct
    {
        public DEBCApiProductCallValues CallValue { get; set; }
    }

    public class DEBCApiProductDBResponse
    {
        public int ProductId { get; set; }
        public string DisplayName { get; set; }
        public bool MktCollateral { get; set; }
        public int ProjectId { get; set; }
    }
}
