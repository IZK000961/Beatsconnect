﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{
    public enum DEBCApiTCFCallValues
    {
        GetDeveloper =2,
        GetProject=3,
        GetCity = 4,
        GetPnL =5,
        GetShareHolder= 6,
        GetTCFStatus=7,
        GetCP=11,
        GetTCFList = 12,
        GetTCF = 13
    }
    public enum TCFReportStatus
    {
        DRAFT, PREAPPROVAL, LOANAPPROVAL, HOLD, RESUBMIT, ALLY2BL, LOANPENDING, NOTCOUNTED, SOS,
        COUNTED, DELETED, CANCELLED, COLLECTED, CLIENTACK,
        BUSINESSALERT, SHARETRANSFER, TPL_PENDING, RESUBMIT_CRM, RESUBMIT_LOAN, RESUBMIT_OPS, CANCELLED_DATE
    }
    public class DEBCApiTCF
    {
        public DEBCApiTCFCallValues CallValue { get; set; }
        public int PageNo { get; set; }
        public int DateType { get; set; } 
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Status { get; set; } 
        public int Developer { get; set; }
        public int Project { get; set; }
        public int City { get; set; } 
        public int PnLID { get; set; } 
        public int EmpID { get; set; } 
        public string PrefixText { get; set; } 
        public int CurrentUser { get; set; } 
        public int IsAdmin { get; set; } 
        public string TCFIDs { get; set; } 
        public int PnLHeadID { get; set; } 
        public string DeletedRemarks { get; set; }
        public int CPID { get; set; }
        public string DealNo { get; set; }
        public int RFStatusID { get; set; } 
        public int SegmentID { get; set; }
        public int limit { get; set; }
        public int Key { get; set; }
        public int offset { get; set; } 
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string TCFStatus { get; set; }
        public bool IncludeTeam { get; set; }
        public bool IsShareHolder { get; set; }
        public int ProductTypeID { get; set; }
    }
    public class DEBCApiTCFResponse
    {
        public int TCFId { get; set; }
        public string TCFRefrenceId { get; set; }
        public string Status { get; set; }
        public string Month { get; set; }
        public string NetRevenueINR { get; set; }
        public string ShareHolder { get; set; }
        public string SharePercentage { get; set; }
        public string CustomerName { get; set; }
        public string Builder { get; set; }
        public string ProductName { get; set; }
        public string rstatus { get; set; }
        public string UnitNumber { get; set; }
        public int MaxNumberOfPages { get; set; }
        public int CurrentPage { get; set; }
    }
    public class DEBCApiTCFDetailsResponse
    {
        public int TCFID { get; set; }
        public string TCFRefrenceId { get; set; }
        public string TCFStatus { get; set; }
        public string RFStatus { get; set; }
        public string Project { get; set; }
        public string ClientName { get; set; }
        public string SubmittedOn { get; set; }
        public string SubmittedBy { get; set; }
        public string NR { get; set; }
        public string ShareHolder { get; set; }
        public string PnLName { get; set; }
        public string SharePercentage { get; set; }
        public string T2 { get; set; }
        public string PnL { get; set; }
        public string PnLRegion { get; set; }
        public string Remarks { get; set; }
        public string TAT { get; set; }
        //public int MaxNumberOfPages { get; set; }
        //public int CurrentPage { get; set; }
    }
    public class GetTCFFilterResponseDTO
    {
        public List<DateRangeResponse> dateRange { get; set; }
        public List<GetShareHolderResponse> shareHolder { get; set; }
        public List<GetPnlResponse> pnlName { get; set; }
        public List<GetTCFStatusResponse> tcfStatus { get; set; }
        public List<GetDeveloperResponse> developer { get; set; }
        public List<GetProjectResponse> project { get; set; }
        public List<GetCityResponse> city { get; set; }
        public List<GetCPResponse> channelPartner { get; set; }
        public List<GetRfStatusResponse> rfStatus { get; set; }
        public List<GetSegmentResponse> segment { get; set; }

    }
    public class GetTCFFilterDetailsResponseDTO
    {
        public List<DateRangeResponse> dateRange { get; set; }
        public List<string> tcfStatus { get; set; }
    }
    public class DateRangeResponse
    {
        public string RangeType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
    public class GetShareHolderResponse
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
    }
    public class GetPnlResponse
    {
        public int PnlId { get; set; }
        public string PnlName { get; set; }
    }
    public class GetTCFStatusResponse
    {
        //public string StatusId { get; set; }
        public string StatusName { get; set; }
    }
    
    public class GetDeveloperResponse
    {
        public string DeveloperId { get; set; }
        public string DeveloperName { get; set; }
    }
    public class GetProjectResponse
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
    }
    public class GetCityResponse
    {
        public string CityId { get; set; }
        public string CityName { get; set; }
    }
    public class GetCPResponse
    {
        public string CpId { get; set; }
        public string CpName { get; set; }
    }
    public class GetRfStatusResponse
    {
        public string StatusId { get; set; }
        public string StatusName { get; set; }
    }
    public class GetSegmentResponse
    {
        public string segmentId { get; set; }
        public string segmentName { get; set; }
    }
}
