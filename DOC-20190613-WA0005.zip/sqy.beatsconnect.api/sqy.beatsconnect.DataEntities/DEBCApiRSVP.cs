﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.beatsconnect.DataEntities
{


 

    public class DEGetChannelPartnerListByRMResponse
    {
        public int cpId { get; set; }
        public string cpCode { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string mobileNo { get; set; }
        public decimal mcfBussinessAmount { get; set; }
        public decimal tcfBussinessAmount { get; set; }
    }

    public enum DEBCApiRSVPCallValues
    {
        GetChannelPartnerListByRM = 1,
        GetSummaryByChannelPartner = 2,
        GetTCFMCFByChannelPartner = 3
    }
    public class DEBCApiRSVP
    {
        public DEBCApiRSVPCallValues CallValue { get; set; }
        public int CPID { get; set; }
        public int CurrentUser { get; set; }
        public string Type { get; set; }
    }

    public class DEBCApiRSVPDBResponse
    {
        public int CPID { get; set; }

        public decimal TotalSubmitted { get; set; }
        public decimal TotalAccrued { get; set; }
        public decimal TotalConfirmed { get; set; }
        public decimal TotalCollected { get; set; }
        public decimal LoanAccruedAmount { get; set; }
        public decimal LoanCollectedAmount { get; set; }

        public int MCFID { get; set; }
        public DateTime MCFDate { get; set; }
        public string Status { get; set; }
        public string LoanType { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal SanctionedAmount { get; set; }
        public decimal DisbursementAmount { get; set; }
        public string BankName { get; set; }
        public int ClientID { get; set; }
        public string ClientName { get; set; }
        public string ClientContact { get; set; }
        public string ClientEmail { get; set; }

        public int TCFID { get; set; }
        public int ProductID { get; set; }
        public DateTime TCFCreationDate { get; set; }
        public decimal Amount { get; set; }
        public string ProjectName { get; set; }
        public string ProjectAddress { get; set; }
        public string BHKName { get; set; }

    }


}
